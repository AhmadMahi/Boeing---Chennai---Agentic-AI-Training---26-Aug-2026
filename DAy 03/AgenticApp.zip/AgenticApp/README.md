# Autonomous Task Desk

Upload an Excel sheet of tasks. Five agents plan, research, analyse, write and
review each one, then the finished work is emailed and pushed to Telegram.

Built on LangGraph, FastAPI, SQLite and ChromaDB. Runs on either OpenAI or
Boeing BCAI with a single switch.

---

## Quick start

```bash
cd AgenticApp
python3 -m venv .venv
./.venv/bin/pip install -r requirements.txt
./.venv/bin/python run.py
```

Opens on http://127.0.0.1:8100

1. Go to **Settings**, choose a provider, paste the key, click **Test connection**.
2. Go to **Run tasks**, click **Download sample sheet**.
3. Drop the sheet back into the page and click **Start run**.

Email and Telegram are optional. Everything works without them; delivery is
just skipped and the run says so in the trace.

---

## How a task flows

```
guard_input ─▶ plan ─▶ research ─▶ analyze ─▶ write ─▶ review
     │                                  ▲                │
     │                                  └──── revise ────┘
     │                                                   │
     └────────────▶ halt ◀──────────────────────── guard_output
                     │                                   │
                    END                             deliver ─▶ END
```

Guardrails are graph nodes, not helper calls, so screening sits on the
execution path rather than being something a later edit can forget to invoke.

| Agent | What it does | Tools |
|---|---|---|
| Guardian | Screens input, tool results and output. Six checks, three boundaries | none |
| Planner | Breaks the row into 2 to 6 steps, picks the deliverable | none |
| Researcher | Web search, page fetch, internal document retrieval | `web_search` `web_fetch` `rag_search` |
| Analyst | Comparisons, rubrics, scored tables | `write_xlsx` |
| Writer | Produces the PDF, Excel or Markdown deliverable | `write_pdf` `write_xlsx` `write_file` |
| Reviewer | Checks the draft against the plan's success criteria | none |

A task blocked by a guardrail gets status `blocked`: the work stays on disk for
inspection, and nothing is emailed or posted.

A failed review sends the draft back to the Writer once, with the specific
problems attached. The retry count is configurable in Settings.

Research and analysis skip themselves when the plan says they are not needed,
so a simple task does not pay for a research pass it never uses.

---

## The task sheet

One task per row. Column order does not matter, unknown columns are ignored,
and header spellings are matched loosely (`due date`, `due_date` and `deadline`
all work). `samples/sample_tasks.xlsx` carries four worked examples plus a
second sheet documenting every column.

| Column | Required | Meaning |
|---|---|---|
| `task_id` | no | Your reference, e.g. T001. Generated if blank. |
| `title` | **yes** | Short name. A row with no title is skipped. |
| `description` | **yes** | The actual instruction. The Planner reads only this. |
| `priority` | no | high, medium, low. High runs first. |
| `due_date` | no | Reported, not enforced. |
| `skill_hint` | no | Force a skill by name. Blank means auto discovery. |
| `tools_allowed` | no | Comma separated tool names. Blank means the skill's own list. |
| `output_format` | no | `pdf`, `xlsx`, `md` or `all`. Default `pdf`. |
| `notify_email` | no | Per-task recipient. Blank uses the Settings default. |
| `notify_telegram` | no | Per-task chat id. |
| `depends_on` | no | `task_id` that must finish first. |

Dependencies are resolved topologically, then by priority inside each wave. A
dependant task receives the full output of the tasks it depends on as context.
A circular or missing dependency cannot deadlock the run: those tasks run last
and are told the dependency was unresolved.

---

## Skills

A skill is a folder, not code:

```
skills/market_research/
├── skill.yaml   name, version, description, keywords, tools_allowed
└── SKILL.md     the instructions injected into the agent prompt
```

Five ship built in: `market_research`, `document_analysis`, `data_analysis`,
`training_design`, `report_writing`.

Each skill's description is embedded into ChromaDB at startup, so the Planner
finds the right skill by meaning rather than by keyword. A `skill_hint` in the
sheet always overrides that.

**Adding skills.** Drop a `.zip` on the Skills tab, or install from a URL, or
browse a registry index (a JSON list of `{name, description, url}`). Any
installed skill can be downloaded back out as a zip.

**Security.** Downloaded skills are untrusted content, so:

- Zip entries are path-checked. No absolute paths, no `..`, no symlinks.
- Archives are capped at 5 MB and 200 entries.
- `.py` files are stripped unless `ALLOW_SKILL_CODE=true`, and even then this
  app never imports or executes them.
- Skill text reaches the model as data. Tool permissions are enforced in
  `app/tools.build()`, so a skill cannot grant itself a tool it was not given.

---

## Guardrails

Six checks run at three boundaries. Every check reports a verdict on every
pass, **including when the content is clean**, so a run shows what was
inspected rather than only what was caught.

| Check | Catches | Can block? |
|---|---|---|
| `pii` | Emails, phones, SSNs, card numbers (Luhn-verified), IPs, IBANs, passports | no, redacts |
| `toxicity` | Threats, harassment, demeaning language, profanity | **yes**, on threats |
| `injection` | Instruction-override attempts in untrusted content | no, neutralizes |
| `secrets` | API keys, tokens, private keys, this app's own credentials | no, redacts |
| `overclaim` | Guaranteed jobs, certifications, ROI and other promises | no, flags |
| `semantic` | LLM review for what pattern matching cannot see | only via toxicity |

### The three boundaries

| Stage | Where | What happens on a finding |
|---|---|---|
| `guard_input` | Before the Planner, before any model spend | PII redacted in the description; threats halt the task |
| tool screening | Inside the agent loop, before the model reads a tool result | Untrusted content is redacted and injection-neutralized |
| `guard_output` | After review, before email or Telegram | Redactions applied to the draft **and rewritten into the files on disk** |

### Design decisions worth knowing

**Only toxicity can block.** Personal data is redacted before the model ever
sees it, injection in retrieved content is neutralized by framing, and an
overclaim is a wording problem for the Reviewer. Letting any of those stop a
task would kill work that has already been made safe.

**The semantic layer can raise a severity but never lower one.** A model that
answers unhelpfully cannot downgrade a hard block. Each category also has a
ceiling, so semantic PII maxes out at FLAG.

**Output redaction rewrites the artifacts.** Without that, the email body would
be clean while the attached PDF still carried the original text, which is what
makes output guardrails theatre rather than protection.

**Untrusted content is framed, not trusted.** Web pages, retrieved documents
and downloaded skills are wrapped in an `<untrusted_content>` block telling the
model to treat the contents as data. Instructions inside them are content, not
commands.

### Showing it working

The **Guardrails** tab has a live tester: paste any text, see all five
deterministic checks report, and see the exact text the model would have
received. No model call, so it is instant and free.

Per task, the results view shows a badge (`guardrails passed` / `flagged` /
`blocked`) and a full per-check table for both stages. The run report PDF and
summary spreadsheet carry a guardrails column, and blocked tasks are counted
separately in the run summary.

Everything is configurable in Settings, including a master switch and a
per-stage toggle.

---

## Provider switch

| | OpenAI | BCAI |
|---|---|---|
| Chat model | `gpt-4o-mini` | `gpt-4.1-mini` |
| Embedding model | `text-embedding-3-small` | `text-embedding-3-small` |
| Chat class | `ChatOpenAI` | `BoeingChatModel` (vendored in `app/bcai/`) |
| Embedding class | `OpenAIEmbeddings` | `BoeingEmbeddings` |
| Tool calling | native | `bind_tools()` against `/conversation` |

Both branches return real LangChain runnables, so every agent calls the same
`.bind_tools(...).invoke(...)` surface and nothing downstream knows which is live.

Both sides embed with **text-embedding-3-small**, which BCAI serves under the
same name. Vectors are therefore 1536-wide on either backend, so a single
ChromaDB collection stays valid across a provider switch and nothing has to be
re-ingested.

---

## Email

Defaults to Resend SMTP. Any SMTP provider works by changing the host, port
and credentials in Settings.

| Service | Host and port | Notes |
|---|---|---|
| Resend | `smtp.resend.com:587` | Username is literally `resend`, password is the API key |
| Brevo | `smtp-relay.brevo.com:587` | No domain needed, verify one sender |
| Mailjet | `in-v3.mailjet.com:587` | API key and secret as username and password |
| SMTP2GO | `mail.smtp2go.com:2525` | Useful when port 587 is blocked |
| Mailtrap | `sandbox.smtp.mailtrap.io:2525` | Catches everything. Best while testing |

Free tier limits change. Confirm the current allowance when you sign up.

Two emails are sent per run: one per completed task with its artifacts
attached, and one run summary with the report PDF and summary spreadsheet.

---

## Telegram

Long polling, so no public URL, tunnel or TLS certificate is needed. Create a
bot with @BotFather, paste the token in Settings, click **Start polling**, then
message the bot. Your chat id is captured automatically on the first message.

| Command | Does |
|---|---|
| `/status` | Progress of the current run |
| `/runs` | The last five runs |
| `/report [id]` | Summary plus the PDF |
| `/skills` | Installed skills |
| `/task <instruction>` | Create and run one ad-hoc task now |
| `/cancel` | Stop after the task in flight finishes |

A `/task` message becomes the description of a normal task row and travels the
same reviewed pipeline, with the same tool permissions. Incoming message text
is treated as data, never as instructions to the app.

---

## Knowledge base

Files dropped on the Knowledge base tab are chunked, embedded and stored in
ChromaDB. The Researcher reaches them through `rag_search`. Supported: pdf,
txt, md, csv, json, xlsx, yaml, log. PDF ingestion needs `pypdf`, which is
optional.

---

## Layout

```
AgenticApp/
├── app/
│   ├── main.py           FastAPI routes, SSE trace stream
│   ├── config.py         settings, .env, runtime overrides
│   ├── providers.py      OpenAI | BCAI switch
│   ├── db.py             SQLite: runs, tasks, events, deliveries, skills
│   ├── vectorstore.py    ChromaDB: documents + skills collections
│   ├── graph.py          the LangGraph state machine
│   ├── orchestrator.py   run ordering, dependencies, run report
│   ├── skills.py         discover, install, export, select
│   ├── telegram_bot.py   long-polling worker
│   ├── agents/           planner researcher analyst writer reviewer base
│   ├── tools/            web office files notify + the tool registry
│   └── bcai/             vendored Boeing wrappers
├── skills/               five built-in skill folders
├── frontend/             index.html styles.css app.js
├── samples/              sample_tasks.xlsx
└── data/                 app.db, chroma/, uploads/, outputs/run_<id>/
```

Artifacts land in `data/outputs/run_<id>/`. Every path an agent supplies is
resolved inside that folder and rejected if it escapes.

---

## Operational notes

- One run executes at a time, in a background thread. The API stays responsive
  and the browser follows over server-sent events.
- The trace is stored in SQLite, not held in memory, so a page reload resumes
  from any event id without losing history.
- Secrets entered in Settings live in server memory for the session only. They
  are never written back to `.env`.
- Email and Telegram failures are logged and never fail the task that produced
  the work.
- `python run.py --reload` is available for development, but avoid it during a
  run: a reload abandons the background thread.
