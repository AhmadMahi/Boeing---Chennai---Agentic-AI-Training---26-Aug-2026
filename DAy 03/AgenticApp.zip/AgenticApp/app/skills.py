"""
Skill discovery, install, export and selection.

A skill is a folder, not a program:

    skills/market_research/
        skill.yaml   name, version, description, keywords, tools_allowed
        SKILL.md     the instructions injected into the agent prompt

Security posture, deliberately conservative because skills can be downloaded
from arbitrary URLs:

  * Zip entries are path-checked, so no archive can write outside its own
    skill folder (no absolute paths, no .. traversal, no symlinks).
  * Total archive size and entry count are capped.
  * .py files are stripped on install unless ALLOW_SKILL_CODE is enabled, and
    even then this app never imports or executes them. Skill content reaches
    the model as data only.
  * The manifest is shown to the user before install so the requested tool
    permissions are visible.

Instructions inside a skill are untrusted text. They shape how an agent
approaches a task, but tool permissions are enforced in code by the executor,
not by anything the skill file claims about itself.
"""

from __future__ import annotations

import io
import json
import re
import shutil
import zipfile
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import requests
import yaml

from . import db
from .config import SKILLS_DIR, settings

MANIFEST_NAMES = ("skill.yaml", "skill.yml", "skill.json")
MAX_ZIP_BYTES = 5 * 1024 * 1024
MAX_ZIP_ENTRIES = 200
MAX_INSTRUCTION_CHARS = 12_000
NAME_RE = re.compile(r"^[a-z0-9][a-z0-9_-]{1,48}$")


class SkillError(ValueError):
    """Raised when a skill folder or archive is invalid or unsafe."""


# ------------------------------------------------------------ manifests ----

def _read_manifest(folder: Path) -> Dict[str, Any]:
    for candidate in MANIFEST_NAMES:
        path = folder / candidate
        if not path.exists():
            continue
        raw = path.read_text(encoding="utf-8", errors="replace")
        data = json.loads(raw) if path.suffix == ".json" else yaml.safe_load(raw)
        if not isinstance(data, dict):
            raise SkillError(f"{path.name} must contain a mapping.")
        return data
    raise SkillError("No skill.yaml, skill.yml or skill.json found.")


def _normalize(meta: Dict[str, Any], folder: Path) -> Dict[str, Any]:
    name = str(meta.get("name") or folder.name).strip().lower().replace(" ", "_")
    if not NAME_RE.match(name):
        raise SkillError(
            f"Invalid skill name {name!r}. Use lowercase letters, digits, - and _."
        )

    keywords = meta.get("keywords") or []
    if isinstance(keywords, str):
        keywords = [k.strip() for k in keywords.split(",") if k.strip()]

    tools = meta.get("tools_allowed") or meta.get("tools") or []
    if isinstance(tools, str):
        tools = [t.strip() for t in tools.split(",") if t.strip()]

    return {
        "name": name,
        "version": str(meta.get("version", "1.0")),
        "description": str(meta.get("description", "")).strip()[:1000],
        "keywords": [str(k)[:40] for k in keywords][:20],
        "tools_allowed": [str(t)[:40] for t in tools][:20],
        "output_format": str(meta.get("output_format", "") or ""),
        "author": str(meta.get("author", "") or ""),
        "path": str(folder),
    }


def _instructions(folder: Path) -> str:
    for candidate in ("SKILL.md", "skill.md", "instructions.md", "README.md"):
        path = folder / candidate
        if path.exists():
            return path.read_text(encoding="utf-8", errors="replace")[:MAX_INSTRUCTION_CHARS]
    return ""


def load(name: str) -> Optional[Dict[str, Any]]:
    """Load one installed skill: manifest plus instruction text."""
    folder = SKILLS_DIR / name
    if not folder.is_dir():
        return None
    try:
        meta = _normalize(_read_manifest(folder), folder)
    except SkillError:
        return None
    meta["instructions"] = _instructions(folder)
    return meta


# ------------------------------------------------------------ discovery ----

def discover(reindex: bool = True) -> List[Dict[str, Any]]:
    """
    Scan skills/, refresh the SQLite registry, and embed each description
    into ChromaDB so the Planner can retrieve skills semantically.

    Vector indexing is best-effort: with no provider credentials configured
    the registry still loads and selection falls back to keyword matching.
    """
    found: List[Dict[str, Any]] = []
    for folder in sorted(p for p in SKILLS_DIR.iterdir() if p.is_dir()):
        if folder.name.startswith((".", "_")):
            continue
        try:
            meta = _normalize(_read_manifest(folder), folder)
        except (SkillError, Exception):
            continue
        meta["source"] = meta.get("source", "local")
        db.upsert_skill(meta)
        found.append(meta)

        if reindex:
            try:
                from .vectorstore import index_skill

                index_skill(meta["name"], meta["description"], meta["keywords"])
            except Exception:
                pass

    installed = {m["name"] for m in found}
    for row in db.list_skills():
        if row["name"] not in installed:
            db.delete_skill(row["name"])
    return found


def select(task_text: str, hint: str = "", limit: int = 2) -> List[Dict[str, Any]]:
    """
    Choose the skills to apply to a task.

    An explicit skill_hint from the spreadsheet always wins. Otherwise the
    task text is matched against the skill vectors, with a keyword overlap
    fallback when no vector index is available.
    """
    enabled = {r["name"]: r for r in db.list_skills(enabled_only=True)}
    chosen: List[str] = []

    for want in [h.strip().lower() for h in (hint or "").split(",") if h.strip()]:
        if want in enabled and want not in chosen:
            chosen.append(want)

    if len(chosen) < limit:
        try:
            from .vectorstore import discover_skills

            for hit in discover_skills(task_text, k=limit + 2):
                if hit["name"] in enabled and hit["name"] not in chosen and hit["score"] > 0.15:
                    chosen.append(hit["name"])
                if len(chosen) >= limit:
                    break
        except Exception:
            words = set(re.findall(r"[a-z]{4,}", (task_text or "").lower()))
            scored = []
            for name, row in enabled.items():
                keywords = set(json.loads(row["keywords"] or "[]"))
                overlap = len(words & {k.lower() for k in keywords})
                if overlap:
                    scored.append((overlap, name))
            for _, name in sorted(scored, reverse=True):
                if name not in chosen:
                    chosen.append(name)
                if len(chosen) >= limit:
                    break

    return [s for s in (load(n) for n in chosen[:limit]) if s]


# -------------------------------------------------------------- install ----

def _safe_extract(archive: zipfile.ZipFile, dest: Path) -> None:
    """Extract with path, size and count checks. Raises SkillError on anything odd."""
    entries = archive.infolist()
    if len(entries) > MAX_ZIP_ENTRIES:
        raise SkillError(f"Archive has {len(entries)} entries, limit is {MAX_ZIP_ENTRIES}.")
    if sum(e.file_size for e in entries) > MAX_ZIP_BYTES:
        raise SkillError("Archive expands to more than 5 MB.")

    dest_root = dest.resolve()
    for entry in entries:
        if entry.is_dir():
            continue
        name = entry.filename
        if name.startswith("/") or ".." in Path(name).parts or "\\" in name:
            raise SkillError(f"Unsafe path in archive: {name}")
        if (entry.external_attr >> 16) & 0o120000 == 0o120000:
            raise SkillError(f"Symlink in archive: {name}")
        if name.endswith(".py") and not settings.allow_skill_code:
            continue   # code is stripped unless explicitly allowed, never executed

        target = (dest_root / name).resolve()
        if dest_root not in target.parents:
            raise SkillError(f"Entry escapes the skill folder: {name}")
        target.parent.mkdir(parents=True, exist_ok=True)
        with archive.open(entry) as src, target.open("wb") as out:
            shutil.copyfileobj(src, out, length=64 * 1024)


def _flatten_single_root(folder: Path) -> Path:
    """If the zip wrapped everything in one top folder, lift its contents up."""
    children = [p for p in folder.iterdir() if not p.name.startswith("__MACOSX")]
    if len(children) == 1 and children[0].is_dir():
        inner = children[0]
        for item in list(inner.iterdir()):
            shutil.move(str(item), str(folder / item.name))
        shutil.rmtree(inner, ignore_errors=True)
    return folder


def install_zip(data: bytes, source: str = "upload") -> Dict[str, Any]:
    """Install a skill from zip bytes. Returns the normalized manifest."""
    if len(data) > MAX_ZIP_BYTES:
        raise SkillError("Archive is larger than 5 MB.")

    staging = SKILLS_DIR / "_staging"
    shutil.rmtree(staging, ignore_errors=True)
    staging.mkdir(parents=True, exist_ok=True)

    try:
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            _safe_extract(archive, staging)
        _flatten_single_root(staging)

        meta = _normalize(_read_manifest(staging), staging)
        if not _instructions(staging):
            raise SkillError("Skill has no SKILL.md instruction file.")

        final = SKILLS_DIR / meta["name"]
        shutil.rmtree(final, ignore_errors=True)
        shutil.move(str(staging), str(final))

        meta["path"] = str(final)
        meta["source"] = source
        db.upsert_skill(meta)
        try:
            from .vectorstore import index_skill

            index_skill(meta["name"], meta["description"], meta["keywords"])
        except Exception:
            pass
        return meta
    except zipfile.BadZipFile as exc:
        raise SkillError(f"Not a valid zip archive: {exc}") from exc
    finally:
        shutil.rmtree(staging, ignore_errors=True)


def install_from_url(url: str) -> Dict[str, Any]:
    """Download a skill zip over https and install it."""
    if not url.startswith(("http://", "https://")):
        raise SkillError("Skill URL must start with http:// or https://")
    try:
        resp = requests.get(url, timeout=45, stream=True)
        resp.raise_for_status()
        data = resp.content
    except Exception as exc:
        raise SkillError(f"Download failed: {exc}") from exc
    if len(data) > MAX_ZIP_BYTES:
        raise SkillError("Downloaded archive is larger than 5 MB.")
    return install_zip(data, source=url)


def registry(url: str = "") -> List[Dict[str, Any]]:
    """
    Fetch a skill registry index.

    The index is a JSON list of {name, description, url, version}. It is data
    for the user to choose from, never something the app installs on its own.
    """
    url = (url or settings.skill_registry_url or "").strip()
    if not url:
        return []
    try:
        data = requests.get(url, timeout=30).json()
    except Exception as exc:
        raise SkillError(f"Registry fetch failed: {exc}") from exc

    items = data.get("skills", data) if isinstance(data, dict) else data
    if not isinstance(items, list):
        raise SkillError("Registry must be a JSON list, or an object with a 'skills' list.")

    out: List[Dict[str, Any]] = []
    for item in items[:100]:
        if isinstance(item, dict) and item.get("url"):
            out.append({
                "name": str(item.get("name", ""))[:60],
                "description": str(item.get("description", ""))[:400],
                "version": str(item.get("version", "")),
                "url": str(item["url"])[:500],
            })
    return out


def export_zip(name: str) -> Tuple[str, bytes]:
    """Package an installed skill as a zip for download."""
    folder = SKILLS_DIR / name
    if not folder.is_dir():
        raise SkillError(f"No installed skill named {name!r}.")

    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(folder.rglob("*")):
            if path.is_file():
                archive.write(path, path.relative_to(folder).as_posix())
    return f"{name}.zip", buffer.getvalue()


def remove(name: str) -> None:
    folder = SKILLS_DIR / name
    if folder.is_dir():
        shutil.rmtree(folder, ignore_errors=True)
    db.delete_skill(name)
    try:
        from .vectorstore import unindex_skill

        unindex_skill(name)
    except Exception:
        pass
