"""
ChromaDB wrapper. Two persistent collections, one embedding path.

    documents   the RAG corpus the Researcher agent can search
    skills      one vector per installed skill, so the Planner discovers
                relevant skills semantically instead of by keyword match

Embeddings are always computed here through app.providers and handed to Chroma
explicitly. Chroma never calls an embedding function of its own, which keeps
the OpenAI / BCAI switch honest: change the provider and both collections use
the new model on the next write.

Both providers are configured for text-embedding-3-small, which BCAI serves
under the same name. Vectors are therefore 1536-wide on either backend, so a
single collection stays valid across a provider switch and nothing has to be
re-ingested.
"""

from __future__ import annotations

import re
from typing import Any, Dict, List, Optional

import chromadb
from chromadb.config import Settings as ChromaSettings

from .config import CHROMA_DIR
from .providers import get_embeddings

_client: Optional[chromadb.ClientAPI] = None


def client() -> chromadb.ClientAPI:
    global _client
    if _client is None:
        _client = chromadb.PersistentClient(
            path=str(CHROMA_DIR),
            settings=ChromaSettings(anonymized_telemetry=False, allow_reset=True),
        )
    return _client


def _collection(base: str):
    """
    Get or create one of the two collections.

    Not namespaced by provider: both backends embed with
    text-embedding-3-small, so the vectors are interchangeable and a provider
    switch does not invalidate what is already indexed.
    """
    return client().get_or_create_collection(
        name=base, metadata={"hnsw:space": "cosine"},
    )


def chunk_text(text: str, size: int = 1000, overlap: int = 150) -> List[str]:
    """
    Paragraph-aware chunking.

    Splits on blank lines first so a chunk rarely cuts a sentence in half,
    then packs paragraphs up to `size` characters with a small overlap tail
    carried into the next chunk for context continuity.
    """
    text = re.sub(r"\n{3,}", "\n\n", (text or "").strip())
    if not text:
        return []

    paragraphs = [p.strip() for p in text.split("\n\n") if p.strip()]
    chunks: List[str] = []
    buf = ""

    for para in paragraphs:
        if len(buf) + len(para) + 2 <= size:
            buf = f"{buf}\n\n{para}" if buf else para
            continue
        if buf:
            chunks.append(buf)
            buf = buf[-overlap:] + "\n\n" + para if overlap else para
        else:
            # Single paragraph longer than the window: hard-split it.
            for i in range(0, len(para), size - overlap):
                chunks.append(para[i:i + size])
            buf = ""

    if buf.strip():
        chunks.append(buf.strip())
    return chunks


# ------------------------------------------------------------ documents ----

def add_document(filename: str, text: str) -> int:
    """Chunk, embed, and upsert one document. Returns the chunk count."""
    chunks = chunk_text(text)
    if not chunks:
        return 0

    vectors = get_embeddings().embed_documents(chunks)
    col = _collection("documents")
    col.upsert(
        ids=[f"{filename}::{i}" for i in range(len(chunks))],
        documents=chunks,
        embeddings=vectors,
        metadatas=[{"source": filename, "chunk": i} for i in range(len(chunks))],
    )
    return len(chunks)


def search_documents(query: str, k: int = 4) -> List[Dict[str, Any]]:
    """Semantic search over the ingested corpus."""
    col = _collection("documents")
    if col.count() == 0:
        return []

    vector = get_embeddings().embed_query(query)
    res = col.query(query_embeddings=[vector], n_results=min(k, col.count()))

    hits: List[Dict[str, Any]] = []
    for doc, meta, dist in zip(
        res.get("documents", [[]])[0],
        res.get("metadatas", [[]])[0],
        res.get("distances", [[]])[0],
    ):
        hits.append({
            "text": doc,
            "source": (meta or {}).get("source", "unknown"),
            "chunk": (meta or {}).get("chunk", 0),
            "score": round(1.0 - float(dist), 4),
        })
    return hits


def document_count() -> int:
    return _collection("documents").count()


def delete_document(filename: str) -> None:
    _collection("documents").delete(where={"source": filename})


# --------------------------------------------------------------- skills ----

def index_skill(name: str, description: str, keywords: List[str]) -> None:
    """Store one vector per skill so the Planner can retrieve by meaning."""
    blob = f"{name}. {description}. Keywords: {', '.join(keywords or [])}"
    vector = get_embeddings().embed_query(blob)
    _collection("skills").upsert(
        ids=[name],
        documents=[blob],
        embeddings=[vector],
        metadatas=[{"name": name}],
    )


def unindex_skill(name: str) -> None:
    try:
        _collection("skills").delete(ids=[name])
    except Exception:
        pass


def discover_skills(query: str, k: int = 3) -> List[Dict[str, Any]]:
    """Return the skill names most relevant to a task description."""
    col = _collection("skills")
    if col.count() == 0:
        return []

    vector = get_embeddings().embed_query(query)
    res = col.query(query_embeddings=[vector], n_results=min(k, col.count()))

    out: List[Dict[str, Any]] = []
    for meta, dist in zip(res.get("metadatas", [[]])[0], res.get("distances", [[]])[0]):
        out.append({"name": (meta or {}).get("name", ""), "score": round(1.0 - float(dist), 4)})
    return out


def reset() -> None:
    """Drop both collections."""
    for base in ("documents", "skills"):
        try:
            client().delete_collection(base)
        except Exception:
            pass
