"""
Run orchestration.

The graph handles one task. This module handles a sheet of them: ordering,
dependencies, per-task setup, the run-level summary report, and cancellation.

Ordering rules
    1. A task never starts before the tasks named in its depends_on column.
    2. Among ready tasks, high priority runs before medium before low.
    3. A dependency that failed does not block its dependants forever; the
       dependant runs and is told the dependency failed.

Runs execute in a background thread so the API stays responsive. Only one run
is active at a time, which keeps provider rate limits predictable.
"""

from __future__ import annotations

import json
import threading
import traceback
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from . import db, skills as skills_mod, tools as tool_registry
from .config import settings
from .graph import build_graph
from .tools import notify, office

PRIORITY_ORDER = {"high": 0, "critical": 0, "medium": 1, "normal": 1, "low": 2}

_lock = threading.Lock()
_current: Dict[str, Any] = {"run_id": None, "cancel": False, "thread": None}


# ------------------------------------------------------------- run state --

def active_run() -> Optional[int]:
    return _current["run_id"]


def is_busy() -> bool:
    thread = _current.get("thread")
    return bool(thread and thread.is_alive())


def cancel() -> bool:
    """Ask the current run to stop after the task in flight finishes."""
    if not is_busy():
        return False
    _current["cancel"] = True
    db.log_event(_current["run_id"], None, "orchestrator", "warn",
                 "Cancellation requested. Finishing the current task, then stopping.")
    return True


def start(run_id: int) -> bool:
    """Launch a run in the background. Returns False if one is already active."""
    with _lock:
        if is_busy():
            return False
        _current.update({"run_id": run_id, "cancel": False})
        thread = threading.Thread(target=_execute_run, args=(run_id,),
                                  name=f"run-{run_id}", daemon=True)
        _current["thread"] = thread
        thread.start()
        return True


# ---------------------------------------------------------------- intake --

def ingest_sheet(path: str, name: str) -> Dict[str, Any]:
    """Parse an uploaded task sheet into a pending run. Does not execute it."""
    rows = office.read_task_sheet(path)
    if not rows:
        raise ValueError(
            "No tasks found. The sheet needs a header row with at least a "
            "'title' and 'description' column."
        )

    from .providers import provider_label

    run_id = db.create_run(name, str(path), provider_label(), len(rows))
    for row in rows:
        db.create_task(run_id, row)

    db.log_event(run_id, None, "orchestrator", "info",
                 f"Loaded {len(rows)} tasks from {name}")
    return {"run_id": run_id, "tasks": len(rows)}


# ------------------------------------------------------------- execution --

def _execute_run(run_id: int) -> None:
    started = datetime.now(timezone.utc)
    db.update_run(run_id, status="running")
    db.log_event(run_id, None, "orchestrator", "start", "Run started")

    try:
        skills_mod.discover(reindex=False)
        tasks = db.list_tasks(run_id)
        graph = build_graph()

        for task in _ordered(tasks):
            if _current["cancel"]:
                db.update_task(task["id"], status="cancelled")
                continue
            _execute_task(run_id, task, graph)

        _finish_run(run_id, started)
    except Exception as exc:
        db.log_event(run_id, None, "orchestrator", "error",
                     f"Run failed: {exc}", {"trace": traceback.format_exc()[:4000]})
        db.update_run(run_id, status="failed", finished_at=db.now())
    finally:
        _current.update({"run_id": None, "cancel": False, "thread": None})


def _ordered(tasks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Topological order by depends_on, then by priority within each wave.

    A cycle or a reference to a task that does not exist cannot deadlock the
    run: once no task is ready, the remaining tasks are appended in priority
    order and each is told its dependency was unresolved.
    """
    remaining = list(tasks)
    done: set[str] = set()
    ordered: List[Dict[str, Any]] = []

    def deps_of(task: Dict[str, Any]) -> List[str]:
        raw = (task.get("depends_on") or "").replace(";", ",")
        return [d.strip() for d in raw.split(",") if d.strip()]

    while remaining:
        ready = [t for t in remaining if all(d in done for d in deps_of(t))]
        if not ready:
            ready = sorted(remaining, key=_priority_key)
            ordered.extend(ready)
            break
        ready.sort(key=_priority_key)
        for task in ready:
            ordered.append(task)
            done.add(task["task_key"])
            remaining.remove(task)

    return ordered


def _priority_key(task: Dict[str, Any]) -> tuple:
    priority = str(task.get("priority") or "medium").strip().lower()
    return (PRIORITY_ORDER.get(priority, 1), task["id"])


def _execute_task(run_id: int, task: Dict[str, Any], graph: Any) -> None:
    task_id = task["id"]
    db.update_task(task_id, status="running", started_at=db.now())
    db.log_event(run_id, task_id, "orchestrator", "task_start",
                 f"{task['task_key']}: {task['title']}")

    tool_registry.set_context(run_id, task_id)

    task_text = f"{task.get('title', '')}. {task.get('description', '')}"
    selected = skills_mod.select(task_text, task.get("skill_hint") or "")
    skill_tools: List[str] = []
    for skill in selected:
        skill_tools.extend(skill.get("tools_allowed", []))

    allowed = tool_registry.normalize_allowed(task.get("tools_allowed"), skill_tools)

    if selected:
        db.log_event(run_id, task_id, "orchestrator", "skills",
                     "Skills applied: " + ", ".join(s["name"] for s in selected))
    db.log_event(run_id, task_id, "orchestrator", "tools", "Tools: " + ", ".join(allowed))

    state = {
        "run_id": run_id,
        "task_id": task_id,
        "task": dict(task),
        "skills": selected,
        "tools_allowed": allowed,
        "dependency_context": _dependency_context(run_id, task),
        "artifacts": [],
        "attempts": 0,
        "tokens": 0,
    }

    try:
        graph.invoke(state, config={"recursion_limit": 40})
        db.update_task(task_id, skills_used=json.dumps([s["name"] for s in selected]))
    except Exception as exc:
        db.log_event(run_id, task_id, "orchestrator", "error", f"Task failed: {exc}",
                     {"trace": traceback.format_exc()[:4000]})
        db.update_task(task_id, status="failed", error=str(exc)[:2000], finished_at=db.now())
    finally:
        db.bump_run_progress(run_id)


def _dependency_context(run_id: int, task: Dict[str, Any]) -> str:
    """Summarize the outputs of the tasks this one depends on."""
    raw = (task.get("depends_on") or "").replace(";", ",")
    wanted = {d.strip() for d in raw.split(",") if d.strip()}
    if not wanted:
        return ""

    blocks: List[str] = []
    for other in db.list_tasks(run_id):
        if other["task_key"] not in wanted:
            continue
        if other["status"] not in ("done", "done_with_issues"):
            blocks.append(
                f"### {other['task_key']} ({other['status']})\n"
                f"This dependency did not complete, so its output is unavailable."
            )
            continue
        body = (other.get("result_md") or other.get("findings_md") or "")[:4000]
        blocks.append(f"### {other['task_key']}: {other['title']}\n{body}")
    return "\n\n".join(blocks)


# ---------------------------------------------------------- run summary ---

def _finish_run(run_id: int, started: datetime) -> None:
    """Build the run report, then send the run-level completion notice."""
    tasks = db.list_tasks(run_id)
    run = db.get_run(run_id) or {}
    cancelled = _current["cancel"]

    rows = [{
        "task": t["task_key"],
        "title": t["title"],
        "status": t["status"],
        "priority": t.get("priority", ""),
        "skills": ", ".join(json.loads(t.get("skills_used") or "[]")),
        "score": (json.loads(t["review_json"]).get("score", "")
                  if t.get("review_json") else ""),
        "guardrails": _guardrail_cell(t),
        "artifacts": ", ".join(
            p.split("/")[-1] for p in json.loads(t.get("artifacts_json") or "[]")
        ),
        "tokens": t.get("tokens", 0),
    } for t in tasks]

    done = sum(1 for t in tasks if t["status"] in ("done", "done_with_issues"))
    failed = sum(1 for t in tasks if t["status"] == "failed")
    blocked = sum(1 for t in tasks if t["status"] == "blocked")
    minutes = (datetime.now(timezone.utc) - started).total_seconds() / 60
    total_tokens = sum(int(t.get("tokens") or 0) for t in tasks)

    summary_md = _run_summary_markdown(run, tasks, done, failed, minutes, total_tokens, blocked)
    artifacts: List[str] = []
    try:
        artifacts.append(office.write_xlsx(
            "run_summary.xlsx", "Run Summary", rows, run_id=run_id))
        artifacts.append(office.write_pdf(
            "run_report.pdf",
            f"Run Report: {run.get('name', run_id)}",
            summary_md,
            subtitle=f"{done} of {len(tasks)} tasks completed | "
                     f"{run.get('provider', '')} | {minutes:.1f} minutes",
            run_id=run_id,
        ))
    except Exception as exc:
        db.log_event(run_id, None, "orchestrator", "warn", f"Report build failed: {exc}")

    status = "cancelled" if cancelled else ("completed" if failed == 0 else "completed_with_failures")
    db.update_run(run_id, status=status, finished_at=db.now())
    db.log_event(run_id, None, "orchestrator", "done",
                 f"Run {status}: {done} done, {failed} failed, {blocked} blocked, "
                 f"{total_tokens} tokens")

    recipient = (settings.notify_email or "").strip()
    if recipient:
        ok, detail = notify.send_email(
            recipient,
            f"Run {status}: {run.get('name', run_id)} ({done}/{len(tasks)} tasks)",
            summary_md,
            artifacts,
        )
        db.log_delivery(run_id, None, "email", recipient, "sent" if ok else "failed", detail)
        db.log_event(run_id, None, "orchestrator", "email" if ok else "warn", f"Run email: {detail}")

    if settings.telegram_token and settings.telegram_chat_id:
        ok, detail = notify.send_telegram(
            f"Run {status}: {run.get('name', run_id)}\n{done} of {len(tasks)} tasks completed, "
            f"{failed} failed."
        )
        db.log_delivery(run_id, None, "telegram", settings.telegram_chat_id,
                        "sent" if ok else "failed", detail)
        for path in artifacts:
            notify.send_telegram_document(path, f"Run report: {run.get('name', run_id)}")


def _guardrail_cell(task: Dict[str, Any]) -> str:
    """One-line guardrail outcome for the summary sheet and report table."""
    raw = task.get("guardrails_json")
    if not raw:
        return "not screened"
    try:
        data = json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        return "unreadable"

    parts = []
    for stage in ("input", "output"):
        report = data.get(stage)
        if report:
            parts.append(f"{stage}: {report.get('verdict', '?')}")
    return ", ".join(parts) or "not screened"


def _run_summary_markdown(run: Dict[str, Any], tasks: List[Dict[str, Any]],
                          done: int, failed: int, minutes: float, tokens: int,
                          blocked: int = 0) -> str:
    lines = [
        "## Summary",
        "",
        f"- Tasks completed: **{done} of {len(tasks)}**",
        f"- Failed: **{failed}**",
        f"- Blocked by a guardrail: **{blocked}**",
        f"- Model provider: {run.get('provider', 'unknown')}",
        f"- Elapsed: {minutes:.1f} minutes",
        f"- Tokens used: {tokens:,}",
        "",
        "## Tasks",
        "",
        "| Task | Title | Status | Score | Guardrails | Files |",
        "|---|---|---|---|---|---|",
    ]
    for task in tasks:
        review = json.loads(task["review_json"]) if task.get("review_json") else {}
        files = ", ".join(
            p.split("/")[-1] for p in json.loads(task.get("artifacts_json") or "[]")
        )
        lines.append(
            f"| {task['task_key']} | {task['title'][:60]} | {task['status']} | "
            f"{review.get('score', '')} | {_guardrail_cell(task)} | {files or 'none'} |"
        )

    lines += ["", "## Task detail", ""]
    for task in tasks:
        review = json.loads(task["review_json"]) if task.get("review_json") else {}
        lines += [f"### {task['task_key']}: {task['title']}", ""]
        if task.get("error"):
            lines += [f"Failed: {task['error']}", ""]
            continue
        if review.get("summary"):
            lines += [review["summary"], ""]
        if review.get("problems"):
            lines += ["Open issues:"] + [f"- {p}" for p in review["problems"][:5]] + [""]
    return "\n".join(lines)
