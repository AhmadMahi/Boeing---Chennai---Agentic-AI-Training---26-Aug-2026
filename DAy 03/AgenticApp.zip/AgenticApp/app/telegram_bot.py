"""
Telegram long-polling worker.

Long polling (getUpdates) rather than webhooks, so the app needs no public
URL, no tunnel and no TLS certificate. The worker runs in a daemon thread and
is started or stopped from the Settings panel.

Commands
    /help                 list commands
    /status               current run progress
    /runs                 last five runs
    /report [run_id]      summary of a run
    /skills               installed skills
    /task <instruction>   create and execute a single ad-hoc task
    /cancel               stop after the task currently in flight

Incoming message text is data, never instruction. A /task body becomes the
description field of a normal task row and travels the same reviewed pipeline
as a spreadsheet task, with the same tool permissions.
"""

from __future__ import annotations

import json
import threading
import time
from typing import Any, Dict, List, Optional

from . import db, orchestrator, skills as skills_mod
from .config import settings
from .tools import notify

_state: Dict[str, Any] = {"thread": None, "stop": False, "offset": 0, "error": ""}
POLL_TIMEOUT = 25


def status() -> Dict[str, Any]:
    thread = _state.get("thread")
    return {
        "running": bool(thread and thread.is_alive()),
        "error": _state.get("error", ""),
        "configured": bool(settings.telegram_token),
    }


def start() -> Dict[str, Any]:
    if not settings.telegram_token:
        return {"ok": False, "detail": "Telegram bot token is not set."}
    if status()["running"]:
        return {"ok": True, "detail": "Polling is already running."}

    _state.update({"stop": False, "error": ""})
    thread = threading.Thread(target=_loop, name="telegram-poll", daemon=True)
    _state["thread"] = thread
    thread.start()
    return {"ok": True, "detail": "Polling started."}


def stop() -> Dict[str, Any]:
    _state["stop"] = True
    return {"ok": True, "detail": "Polling will stop within a few seconds."}


def _loop() -> None:
    db.log_event(None, None, "telegram", "info", "Long polling started")
    while not _state["stop"]:
        updates, error = notify.get_updates(_state["offset"], POLL_TIMEOUT)
        if error:
            _state["error"] = error
            db.log_event(None, None, "telegram", "warn", f"Poll error: {error}")
            time.sleep(5)
            continue

        _state["error"] = ""
        for update in updates:
            _state["offset"] = int(update.get("update_id", 0)) + 1
            try:
                _handle(update)
            except Exception as exc:
                db.log_event(None, None, "telegram", "error", f"Handler failed: {exc}")

    db.log_event(None, None, "telegram", "info", "Long polling stopped")
    _state["thread"] = None


def _handle(update: Dict[str, Any]) -> None:
    message = update.get("message") or update.get("edited_message") or {}
    text = (message.get("text") or "").strip()
    chat_id = str((message.get("chat") or {}).get("id", ""))
    if not text or not chat_id:
        return

    # First contact also captures the chat id, so the user never has to look it up.
    if not settings.telegram_chat_id:
        settings.telegram_chat_id = chat_id
        db.log_event(None, None, "telegram", "info", f"Default chat id set to {chat_id}")

    db.log_event(None, None, "telegram", "message", f"{chat_id}: {text[:120]}")

    command, _, argument = text.partition(" ")
    command = command.lower().lstrip("/").split("@")[0]
    argument = argument.strip()

    handler = {
        "start": _cmd_help, "help": _cmd_help, "status": _cmd_status,
        "runs": _cmd_runs, "report": _cmd_report, "skills": _cmd_skills,
        "task": _cmd_task, "cancel": _cmd_cancel,
    }.get(command)

    if handler is None:
        notify.send_telegram(
            "Unrecognized command. Send /help for the list.", chat_id
        )
        return
    handler(argument, chat_id)


# ------------------------------------------------------------- commands ----

def _cmd_help(_: str, chat_id: str) -> None:
    notify.send_telegram(
        "Autonomous Task Desk\n\n"
        "/status - progress of the current run\n"
        "/runs - the last five runs\n"
        "/report [run_id] - summary of a run\n"
        "/skills - installed skills\n"
        "/task <instruction> - run one ad-hoc task now\n"
        "/cancel - stop after the current task finishes",
        chat_id,
    )


def _cmd_status(_: str, chat_id: str) -> None:
    run_id = orchestrator.active_run()
    if not run_id:
        stats = db.stats()
        notify.send_telegram(
            f"Idle. {stats['tasks_done']} of {stats['tasks']} tasks completed to date across "
            f"{stats['runs']} runs.", chat_id)
        return

    run = db.get_run(run_id) or {}
    tasks = db.list_tasks(run_id)
    running = next((t["title"] for t in tasks if t["status"] == "running"), "none")
    notify.send_telegram(
        f"Run {run_id}: {run.get('name', '')}\n"
        f"Progress: {run.get('tasks_done', 0)} of {run.get('tasks_total', 0)}\n"
        f"In flight: {running}", chat_id)


def _cmd_runs(_: str, chat_id: str) -> None:
    runs = db.list_runs(5)
    if not runs:
        notify.send_telegram("No runs yet. Upload a task sheet in the web app.", chat_id)
        return
    lines = [f"{r['id']}. {r['name']} - {r['status']} ({r['tasks_done']}/{r['tasks_total']})"
             for r in runs]
    notify.send_telegram("Recent runs:\n" + "\n".join(lines), chat_id)


def _cmd_report(argument: str, chat_id: str) -> None:
    runs = db.list_runs(1)
    run_id = int(argument) if argument.isdigit() else (runs[0]["id"] if runs else 0)
    if not run_id:
        notify.send_telegram("No run to report on.", chat_id)
        return

    run = db.get_run(run_id)
    if not run:
        notify.send_telegram(f"No run with id {run_id}.", chat_id)
        return

    tasks = db.list_tasks(run_id)
    lines = [f"Run {run_id}: {run['name']} - {run['status']}", ""]
    for task in tasks:
        review = json.loads(task["review_json"]) if task.get("review_json") else {}
        score = f" ({review['score']}/10)" if review.get("score") != "" and review.get("score") is not None else ""
        lines.append(f"{task['task_key']} {task['status']}{score}: {task['title'][:60]}")
    notify.send_telegram("\n".join(lines), chat_id)

    from .tools.files import workspace

    report = workspace(run_id) / "run_report.pdf"
    if report.exists():
        notify.send_telegram_document(str(report), f"Run {run_id} report", chat_id)


def _cmd_skills(_: str, chat_id: str) -> None:
    rows = db.list_skills(enabled_only=True)
    if not rows:
        notify.send_telegram("No skills installed.", chat_id)
        return
    lines = [f"- {r['name']} v{r['version']}: {(r['description'] or '')[:90]}" for r in rows]
    notify.send_telegram("Installed skills:\n" + "\n".join(lines), chat_id)


def _cmd_cancel(_: str, chat_id: str) -> None:
    ok = orchestrator.cancel()
    notify.send_telegram(
        "Cancellation requested. The task in flight will finish first."
        if ok else "Nothing is running.", chat_id)


def _cmd_task(argument: str, chat_id: str) -> None:
    """Create a one-row run from a chat message and execute it."""
    if not argument:
        notify.send_telegram("Usage: /task research X and send me a PDF", chat_id)
        return
    if orchestrator.is_busy():
        notify.send_telegram("A run is already in progress. Try again when it finishes.", chat_id)
        return

    from .providers import check_ready, provider_label

    ready, reason = check_ready()
    if not ready:
        notify.send_telegram(f"Cannot run: {reason}", chat_id)
        return

    title = argument[:80]
    run_id = db.create_run(f"Telegram: {title}", "telegram", provider_label(), 1)
    db.create_task(run_id, {
        "task_key": "T001",
        "title": title,
        "description": argument,
        "priority": "high",
        "output_format": "pdf",
        "notify_telegram": chat_id,
    })

    if orchestrator.start(run_id):
        notify.send_telegram(f"Started run {run_id}. I will message you when it is done.", chat_id)
    else:
        notify.send_telegram("Could not start the run, something else is executing.", chat_id)
