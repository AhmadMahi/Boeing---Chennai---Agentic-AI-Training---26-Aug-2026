"""Vendored BCAI LangChain wrappers, copied verbatim from the Boeing folder."""
