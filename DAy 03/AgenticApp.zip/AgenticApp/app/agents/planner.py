"""
Planner agent.

Reads one spreadsheet row and decides how the task will be executed: the
steps, which of the executor agents are needed, and what the deliverable is.
Everything downstream reads this plan, so it is stored as JSON on the task row
and is visible in the UI.
"""

from __future__ import annotations

import json
from typing import Any, Dict

from .base import call_json, emit, skill_block, task_block

SYSTEM = """You are the Planner in a multi-agent task execution system.

You receive one task from a task sheet and produce an execution plan. You do
not perform the work and you do not call tools.

Available executor agents:
  researcher  gathers evidence from the web and the internal document corpus
  analyst     structures, compares and scores what the researcher gathered
  writer      produces the final deliverable

Respond with a single JSON object and nothing else:

{
  "objective": "one sentence describing what done looks like",
  "steps": [
    {"n": 1, "agent": "researcher", "action": "what to do", "why": "why it is needed"}
  ],
  "needs_research": true,
  "needs_analysis": true,
  "deliverable": "pdf" | "xlsx" | "md" | "all",
  "success_criteria": ["checkable statement", "checkable statement"],
  "risks": ["what could make this answer wrong"]
}

Rules:
- Between two and six steps. Fewer steps for simple tasks.
- Set needs_research to false only when the task needs no external facts.
- Set needs_analysis to true when the output involves comparison, scoring,
  ranking or any table.
- success_criteria must be checkable by reading the final deliverable.
"""


def run(state: Dict[str, Any]) -> Dict[str, Any]:
    task = state.get("task", {})
    emit(state, "planner", "start", f"Planning: {task.get('title', '')[:80]}")

    fallback = {
        "objective": task.get("title", "Complete the task"),
        "steps": [
            {"n": 1, "agent": "researcher", "action": "Gather the facts the task needs",
             "why": "The deliverable must be grounded in evidence."},
            {"n": 2, "agent": "writer", "action": "Write the deliverable",
             "why": "The task requires a written output."},
        ],
        "needs_research": True,
        "needs_analysis": False,
        "deliverable": task.get("output_format", "pdf") or "pdf",
        "success_criteria": ["The instruction is answered in full."],
        "risks": ["Plan generation failed, so this is a generic fallback plan."],
    }

    user = "\n\n".join(filter(None, [
        task_block(state),
        skill_block(state),
        f"Tools available to the executors: {', '.join(state.get('tools_allowed', []))}",
        "Produce the execution plan as JSON.",
    ]))

    plan, tokens = call_json(state, "planner", SYSTEM, user, fallback)

    # Normalize so downstream nodes never guard against missing keys.
    plan.setdefault("objective", fallback["objective"])
    plan.setdefault("steps", fallback["steps"])
    plan.setdefault("success_criteria", fallback["success_criteria"])
    plan["needs_research"] = bool(plan.get("needs_research", True))
    plan["needs_analysis"] = bool(plan.get("needs_analysis", False))
    requested = (task.get("output_format") or "").strip().lower()
    plan["deliverable"] = requested or str(plan.get("deliverable", "pdf")).lower()

    emit(state, "planner", "plan", f"{len(plan['steps'])} steps, deliverable {plan['deliverable']}",
         plan)
    return {"plan": plan, "tokens": state.get("tokens", 0) + tokens}
