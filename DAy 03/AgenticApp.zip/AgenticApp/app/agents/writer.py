"""
Writer agent.

Produces the deliverable and the artifact files. This is the only agent that
writes PDF and Excel output, so every finished file in a run workspace came
through here (or through the analyst's optional spreadsheet).
"""

from __future__ import annotations

import re
from typing import Any, Dict, List

from .base import call_model, emit, skill_block, task_block

SYSTEM = """You are the Writer in a multi-agent task execution system.

You turn evidence and analysis into the finished deliverable. You do not
research. If a fact is not in the material you were given, it does not go in
the document.

Process:
1. Write the document body in Markdown.
2. Save it with the file tools, matching the requested output format:
   - pdf  -> write_pdf
   - xlsx -> write_xlsx
   - md   -> write_file
   - all  -> write_pdf and write_file, plus write_xlsx if there is tabular data
3. After saving, reply with the full Markdown body as your final message so
   the reviewer can check it.

Document standards:
- Open with an executive summary of three to five bullets a busy reader can act on.
- Short paragraphs. Use tables and bullets over walls of prose.
- Separate confirmed fact from interpretation, and label the interpretation.
- Carry the researcher's source markers through into the document, and end
  with the Sources section.
- State uncertainty where it exists instead of smoothing it over.
- Plain professional English. No filler opening, no restating the prompt, no
  hype, no invented figures.
"""


def run(state: Dict[str, Any]) -> Dict[str, Any]:
    plan = state.get("plan", {})
    task = state.get("task", {})
    attempt = int(state.get("attempts", 0))
    emit(state, "writer", "start", "Drafting deliverable" + (f" (revision {attempt})" if attempt else ""))

    deliverable = str(plan.get("deliverable", "pdf")).lower()
    base_name = _safe_stem(task.get("task_key", "task"), task.get("title", ""))

    guidance = {
        "pdf": f"Call write_pdf with filename '{base_name}.pdf'.",
        "xlsx": f"Call write_xlsx with filename '{base_name}.xlsx'.",
        "md": f"Call write_file with filename '{base_name}.md'.",
        "all": (f"Call write_pdf with '{base_name}.pdf' and write_file with "
                f"'{base_name}.md'. Add write_xlsx with '{base_name}.xlsx' if the "
                f"content contains a table worth having as a spreadsheet."),
    }.get(deliverable, f"Call write_pdf with filename '{base_name}.pdf'.")

    review_note = ""
    if state.get("review") and not state["review"].get("passed", True):
        problems = "\n".join(f"- {p}" for p in state["review"].get("problems", []))
        review_note = (
            "## Reviewer feedback on your previous draft\n"
            f"{problems}\n\nFix every point above in this revision, then save the "
            "corrected file again under the same filename."
        )

    user = "\n\n".join(filter(None, [
        task_block(state),
        skill_block(state),
        f"## Objective\n{plan.get('objective', '')}",
        f"## Success criteria\n" + "\n".join(f"- {c}" for c in plan.get("success_criteria", [])),
        f"## Evidence brief\n{state.get('findings', '')}",
        f"## Analysis\n{state['analysis']}" if state.get("analysis") else "",
        review_note,
        f"## Output instruction\n{guidance}\nUse the exact filename given. "
        f"Then reply with the full Markdown body.",
    ]))

    allowed = [t for t in state.get("tools_allowed", []) + ["write_file", "write_pdf", "write_xlsx"]]
    draft, tokens = call_model(
        state, "writer", SYSTEM, user,
        tools=sorted(set(t for t in allowed if t.startswith(("write", "read")))),
        max_iterations=5,
    )

    draft = _unfence(draft)
    emit(state, "writer", "done", f"Draft: {len(draft)} characters")
    return {"draft": draft, "tokens": state.get("tokens", 0) + tokens}


def _unfence(text: str) -> str:
    """
    Strip a code fence wrapping the whole document.

    Models often return the body inside ```markdown ... ```, which would print
    the fence markers into the PDF. Only an outermost fence is removed, so
    genuine code blocks inside the document survive.
    """
    body = (text or "").strip()
    if not body.startswith("```"):
        return body

    first_newline = body.find("\n")
    if first_newline == -1:
        return body

    opener = body[:first_newline].strip("` ").lower()
    if opener and opener not in ("markdown", "md", "text"):
        return body   # a real code block, not a wrapper

    inner = body[first_newline + 1:]
    if inner.rstrip().endswith("```"):
        inner = inner.rstrip()[:-3]
    return inner.strip()


def _safe_stem(task_key: str, title: str) -> str:
    """Filesystem-safe basename built from the task key and title."""
    slug = re.sub(r"[^a-zA-Z0-9]+", "_", f"{task_key}_{title}").strip("_").lower()
    return (slug[:60] or "task_output")
