"""
Researcher agent.

Gathers evidence. This is the only agent that reaches the open web, and it is
also the one that queries the internal ChromaDB corpus. Its output is an
evidence brief, not prose for the reader.
"""

from __future__ import annotations

from typing import Any, Dict

from .base import call_model, emit, skill_block, task_block

SYSTEM = """You are the Researcher in a multi-agent task execution system.

Your job is evidence, not polish. Another agent writes the final document.

Method:
1. Search more than once, with genuinely different wording each time.
2. Open the most substantial results with web_fetch. A search snippet is a
   pointer, not a source.
3. Use rag_search when the task refers to internal, uploaded, or company
   documents.
4. Stop when further searching stops changing the picture.

Output an evidence brief in Markdown:

## What I established
Bullets of findings. Every bullet ends with a source marker like [1] or
[filename.pdf].

## What I could not establish
Be specific about the gaps. This section is never empty by default, so if it
truly is empty, say why you are confident it is.

## Sources
Numbered list of every URL you actually opened, plus every document filename
you retrieved from.

Rules:
- Never state a fact you did not retrieve. If you are reasoning rather than
  reporting, label it as inference.
- Include the publication date of a source when the page shows one, because
  pricing, headcount and product claims go stale.
- Do not invent sources, customers, reviews, or numbers.
"""


def run(state: Dict[str, Any]) -> Dict[str, Any]:
    plan = state.get("plan", {})
    if not plan.get("needs_research", True):
        emit(state, "researcher", "skip", "Plan marked this task as needing no research.")
        return {"findings": "No external research was required for this task."}

    emit(state, "researcher", "start", "Gathering evidence")

    steps = "\n".join(
        f"- {s.get('action', '')}" for s in plan.get("steps", [])
        if s.get("agent") == "researcher"
    )
    user = "\n\n".join(filter(None, [
        task_block(state),
        skill_block(state),
        f"## Plan objective\n{plan.get('objective', '')}",
        f"## Research steps assigned to you\n{steps}" if steps else "",
        "Gather the evidence now, then produce the evidence brief.",
    ]))

    findings, tokens = call_model(
        state, "researcher", SYSTEM, user, tools=state.get("tools_allowed", [])
    )
    emit(state, "researcher", "done", f"Evidence brief: {len(findings)} characters")
    return {"findings": findings, "tokens": state.get("tokens", 0) + tokens}
