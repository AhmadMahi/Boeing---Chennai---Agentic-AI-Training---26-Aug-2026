"""
Analyst agent.

Turns the researcher's evidence into structure: comparisons, scored rubrics,
ranked options. Runs only when the plan asks for it, so simple narrative tasks
skip straight from research to writing.
"""

from __future__ import annotations

from typing import Any, Dict

from .base import call_model, emit, skill_block, task_block

SYSTEM = """You are the Analyst in a multi-agent task execution system.

You receive an evidence brief and turn it into structure. You do not gather
new evidence, and you never add facts that are not in the brief.

Method:
1. State the criteria and the scale before scoring anything.
2. One row per entity, one column per criterion, consistent units per column.
3. Unknowns are marked n/a. Never substitute a middle value for missing data,
   because that fabricates a measurement.
4. Say what the structure shows, including anything that contradicts the
   obvious reading.

Output in Markdown:

## Rubric
What each criterion means and how it is scored.

## Analysis
The table, as a Markdown table.

## What this shows
Two to four bullets.

## Caveats
Every place the evidence was thin or the score is inferred.
"""


def run(state: Dict[str, Any]) -> Dict[str, Any]:
    plan = state.get("plan", {})
    if not plan.get("needs_analysis", False):
        emit(state, "analyst", "skip", "Plan marked this task as needing no analysis step.")
        return {"analysis": ""}

    emit(state, "analyst", "start", "Structuring findings")

    user = "\n\n".join(filter(None, [
        task_block(state),
        skill_block(state),
        f"## Objective\n{plan.get('objective', '')}",
        f"## Evidence brief from the researcher\n{state.get('findings', '')}",
        "Produce the analysis now.",
    ]))

    # write_xlsx is offered so a spreadsheet deliverable can be produced here.
    allowed = [t for t in state.get("tools_allowed", []) if t in ("write_xlsx", "read_file")]
    analysis, tokens = call_model(
        state, "analyst", SYSTEM, user, tools=allowed or None, max_iterations=4
    )
    emit(state, "analyst", "done", f"Analysis: {len(analysis)} characters")
    return {"analysis": analysis, "tokens": state.get("tokens", 0) + tokens}
