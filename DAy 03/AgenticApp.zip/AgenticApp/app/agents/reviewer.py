"""
Reviewer agent.

Checks the draft against the plan's success criteria before anything is
delivered. A failed review sends the task back to the writer once, which is
where most "the agent answered a different question" failures get caught.
"""

from __future__ import annotations

from typing import Any, Dict

from .base import call_json, emit, task_block

SYSTEM = """You are the Reviewer in a multi-agent task execution system.

You check a finished draft against the task instruction and the plan's success
criteria. You are the last check before delivery, so hold a high bar for
substance, and none at all for taste.

Fail the draft ONLY when one of these is true:
- It answers a materially different question than the instruction asked.
- A success criterion is genuinely unmet, not merely phrased differently.
- It asserts facts that do not appear anywhere in the evidence it was given.
- It contains figures, names, customers, or citations that were invented.
- The requested output file was not produced.

The following are NOT defects. Never list them as problems:
- Extra sections, context, caveats or sources beyond what was asked for.
- Ordering, headings, tone, length or formatting you would have done differently.
- A point that is present but worded less directly than you would word it.
- Hedging or stated uncertainty where the evidence really was thin.

Respond with a single JSON object and nothing else:

{
  "passed": true,
  "score": 0-10,
  "problems": ["specific, actionable, substantive failure"],
  "strengths": ["what the draft does well"],
  "summary": "two sentences a human can read in the run log"
}

problems must be empty unless a real failure from the first list is present.
A draft that fully answers the instruction passes even if you can imagine a
better version of it.
"""


def run(state: Dict[str, Any]) -> Dict[str, Any]:
    emit(state, "reviewer", "start", "Reviewing draft against success criteria")
    plan = state.get("plan", {})

    fallback = {
        "passed": True, "score": 6, "problems": [],
        "strengths": [], "summary": "Review could not be parsed, so the draft was accepted as is.",
    }

    user = "\n\n".join(filter(None, [
        task_block(state),
        f"## Success criteria\n" + "\n".join(f"- {c}" for c in plan.get("success_criteria", [])),
        f"## Evidence the writer was given\n{(state.get('findings') or '')[:4000]}",
        f"## Files produced\n" + ("\n".join(f"- {a}" for a in state.get("artifacts", []))
                                  or "None recorded."),
        f"## Draft\n{state.get('draft', '')[:12000]}",
        "Review the draft and respond with the JSON object.",
    ]))

    review, tokens = call_json(state, "reviewer", SYSTEM, user, fallback)
    review["passed"] = bool(review.get("passed", True)) and not review.get("problems")

    verdict = "passed" if review["passed"] else "needs revision"
    emit(state, "reviewer", "review",
         f"Review {verdict} (score {review.get('score', '?')}/10)", review)

    return {
        "review": review,
        "attempts": int(state.get("attempts", 0)) + 1,
        "tokens": state.get("tokens", 0) + tokens,
    }
