"""
Central configuration for the Autonomous Task Desk.

Every setting has a safe default so the app boots with zero configuration.
Secrets are read from .env at import time, but the UI can also push them in
at runtime via set_runtime() so nothing has to be written to disk.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Dict

try:
    from dotenv import load_dotenv
except ImportError:  # dotenv is optional
    def load_dotenv(*_a: Any, **_k: Any) -> bool:
        return False

BASE_DIR = Path(__file__).resolve().parent.parent

# Load AgenticApp/.env first, then fall back to the shared Boeing/.env so an
# existing UDAL_PAT or OPENAI_API_KEY is picked up without being copied around.
load_dotenv(BASE_DIR / ".env")
load_dotenv(BASE_DIR.parent / ".env")

DATA_DIR = BASE_DIR / "data"
UPLOAD_DIR = DATA_DIR / "uploads"
OUTPUT_DIR = DATA_DIR / "outputs"
CHROMA_DIR = DATA_DIR / "chroma"
SKILLS_DIR = BASE_DIR / "skills"
SAMPLES_DIR = BASE_DIR / "samples"
FRONTEND_DIR = BASE_DIR / "frontend"
DB_PATH = DATA_DIR / "app.db"

for _d in (DATA_DIR, UPLOAD_DIR, OUTPUT_DIR, CHROMA_DIR, SKILLS_DIR, SAMPLES_DIR):
    _d.mkdir(parents=True, exist_ok=True)


def _env(key: str, default: str = "") -> str:
    return (os.getenv(key) or default).strip()


@dataclass
class Settings:
    """Mutable runtime settings. The UI edits these in memory."""

    # ---- Model provider -------------------------------------------------
    provider: str = field(default_factory=lambda: _env("PROVIDER", "openai"))

    openai_api_key: str = field(default_factory=lambda: _env("OPENAI_API_KEY"))
    openai_chat_model: str = field(default_factory=lambda: _env("OPENAI_CHAT_MODEL", "gpt-4o-mini"))
    openai_embed_model: str = field(
        default_factory=lambda: _env("OPENAI_EMBED_MODEL", "text-embedding-3-small")
    )

    udal_pat: str = field(default_factory=lambda: _env("UDAL_PAT"))
    bcai_chat_url: str = field(
        default_factory=lambda: _env(
            "BCAI_CHAT_URL", "https://bcai-test.web.boeing.com/bcai-public-api/conversation"
        )
    )
    bcai_embed_url: str = field(
        default_factory=lambda: _env(
            "BCAI_EMBED_URL", "https://bcai-test.web.boeing.com/bcai-public-api/embedding"
        )
    )
    bcai_chat_model: str = field(default_factory=lambda: _env("BCAI_CHAT_MODEL", "gpt-4.1-mini"))
    # Both providers use text-embedding-3-small deliberately. BCAI serves the
    # same model, so the vectors are 1536-wide on either backend and one
    # ChromaDB collection stays valid across a provider switch.
    bcai_embed_model: str = field(
        default_factory=lambda: _env("BCAI_EMBED_MODEL", "text-embedding-3-small")
    )

    temperature: float = field(default_factory=lambda: float(_env("TEMPERATURE", "0.2")))

    # ---- Email (Resend SMTP by default) ---------------------------------
    smtp_host: str = field(default_factory=lambda: _env("SMTP_HOST", "smtp.resend.com"))
    smtp_port: int = field(default_factory=lambda: int(_env("SMTP_PORT", "587")))
    smtp_user: str = field(default_factory=lambda: _env("SMTP_USER", "resend"))
    smtp_password: str = field(default_factory=lambda: _env("SMTP_PASSWORD"))
    smtp_from: str = field(default_factory=lambda: _env("SMTP_FROM", "onboarding@resend.dev"))
    smtp_starttls: bool = field(default_factory=lambda: _env("SMTP_STARTTLS", "true") == "true")
    notify_email: str = field(default_factory=lambda: _env("NOTIFY_EMAIL"))

    # ---- Telegram --------------------------------------------------------
    telegram_token: str = field(default_factory=lambda: _env("TELEGRAM_BOT_TOKEN"))
    telegram_chat_id: str = field(default_factory=lambda: _env("TELEGRAM_CHAT_ID"))
    telegram_polling: bool = field(
        default_factory=lambda: _env("TELEGRAM_POLLING", "false") == "true"
    )

    # ---- Agent limits ----------------------------------------------------
    max_tool_iterations: int = field(default_factory=lambda: int(_env("MAX_TOOL_ITERATIONS", "8")))
    max_review_retries: int = field(default_factory=lambda: int(_env("MAX_REVIEW_RETRIES", "1")))
    search_results: int = field(default_factory=lambda: int(_env("SEARCH_RESULTS", "5")))

    # ---- Guardrails ------------------------------------------------------
    guardrails_enabled: bool = field(
        default_factory=lambda: _env("GUARDRAILS_ENABLED", "true") == "true"
    )
    guard_input: bool = field(default_factory=lambda: _env("GUARD_INPUT", "true") == "true")
    guard_tools: bool = field(default_factory=lambda: _env("GUARD_TOOLS", "true") == "true")
    guard_output: bool = field(default_factory=lambda: _env("GUARD_OUTPUT", "true") == "true")
    guard_llm_check: bool = field(
        default_factory=lambda: _env("GUARD_LLM_CHECK", "true") == "true"
    )
    guard_redact_pii: bool = field(
        default_factory=lambda: _env("GUARD_REDACT_PII", "true") == "true"
    )
    guard_block_on_toxicity: bool = field(
        default_factory=lambda: _env("GUARD_BLOCK_ON_TOXICITY", "true") == "true"
    )

    # ---- Skills ----------------------------------------------------------
    allow_skill_code: bool = field(
        default_factory=lambda: _env("ALLOW_SKILL_CODE", "false") == "true"
    )
    skill_registry_url: str = field(default_factory=lambda: _env("SKILL_REGISTRY_URL"))

    def public(self) -> Dict[str, Any]:
        """Settings safe to send to the browser. Secrets are masked."""
        data = asdict(self)
        for key in ("openai_api_key", "udal_pat", "smtp_password"):
            data[key] = mask(data[key])
        return data


def mask(secret: str) -> str:
    """Render a credential for display without leaking it."""
    secret = (secret or "").strip()
    if not secret:
        return ""
    if len(secret) <= 8:
        return "*" * len(secret)
    return f"{secret[:4]}{'*' * 6}{secret[-4:]}"


settings = Settings()

# Fields the UI is allowed to overwrite at runtime.
EDITABLE = {
    "provider", "openai_api_key", "openai_chat_model", "openai_embed_model",
    "udal_pat", "bcai_chat_url", "bcai_embed_url", "bcai_chat_model", "bcai_embed_model",
    "temperature", "smtp_host", "smtp_port", "smtp_user", "smtp_password", "smtp_from",
    "smtp_starttls", "notify_email", "telegram_token", "telegram_chat_id",
    "max_tool_iterations", "max_review_retries", "search_results", "allow_skill_code",
    "skill_registry_url", "guardrails_enabled", "guard_input", "guard_tools",
    "guard_output", "guard_llm_check", "guard_redact_pii", "guard_block_on_toxicity",
}


def set_runtime(updates: Dict[str, Any]) -> None:
    """
    Apply UI edits to the live settings object.

    Blank strings are ignored for secret fields so that submitting the form
    with a masked placeholder never wipes a working credential.
    """
    secret_fields = {"openai_api_key", "udal_pat", "smtp_password"}
    for key, value in (updates or {}).items():
        if key not in EDITABLE:
            continue
        if key in secret_fields and (not value or "*" in str(value)):
            continue
        current = getattr(settings, key)
        if isinstance(current, bool):
            value = str(value).lower() in ("1", "true", "yes", "on")
        elif isinstance(current, int) and not isinstance(current, bool):
            value = int(value)
        elif isinstance(current, float):
            value = float(value)
        setattr(settings, key, value)
