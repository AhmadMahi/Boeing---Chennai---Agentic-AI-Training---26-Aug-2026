"""
Workspace file tools.

Every path an agent supplies is resolved inside data/outputs/ and rejected if
it escapes. Agents get to name their own deliverables without being able to
touch anything outside the workspace.
"""

from __future__ import annotations

from pathlib import Path
from typing import List

from ..config import OUTPUT_DIR


class UnsafePath(ValueError):
    """Raised when a requested path escapes the workspace."""


def workspace(run_id: int | str | None = None) -> Path:
    """Directory for one run's artifacts, created on demand."""
    path = OUTPUT_DIR if run_id is None else OUTPUT_DIR / f"run_{run_id}"
    path.mkdir(parents=True, exist_ok=True)
    return path


def safe_path(name: str, run_id: int | str | None = None) -> Path:
    """Resolve `name` inside the run workspace, or raise UnsafePath."""
    root = workspace(run_id).resolve()
    candidate = (root / Path(name).name).resolve() if "/" not in name else (root / name).resolve()
    if root not in candidate.parents and candidate != root:
        raise UnsafePath(f"Path {name!r} escapes the workspace.")
    candidate.parent.mkdir(parents=True, exist_ok=True)
    return candidate


def write_file(name: str, content: str, run_id: int | str | None = None) -> str:
    path = safe_path(name, run_id)
    path.write_text(content, encoding="utf-8")
    return str(path)


def read_file(name: str, run_id: int | str | None = None) -> str:
    path = safe_path(name, run_id)
    if not path.exists():
        return f"No such file: {name}"
    return path.read_text(encoding="utf-8", errors="replace")


def list_files(run_id: int | str | None = None) -> List[str]:
    root = workspace(run_id)
    return sorted(p.name for p in root.iterdir() if p.is_file())


def read_upload(path: Path, max_chars: int = 200_000) -> str:
    """
    Extract text from an uploaded file for RAG ingestion.

    Plain text, markdown, csv and json are read directly. PDF support is
    optional: without pypdf installed the caller gets a clear message instead
    of a traceback.
    """
    suffix = path.suffix.lower()

    if suffix in (".txt", ".md", ".csv", ".json", ".log", ".yaml", ".yml"):
        return path.read_text(encoding="utf-8", errors="replace")[:max_chars]

    if suffix == ".pdf":
        try:
            from pypdf import PdfReader
        except ImportError:
            return "[pypdf is not installed, so PDF ingestion is unavailable. pip install pypdf]"
        reader = PdfReader(str(path))
        return "\n\n".join((page.extract_text() or "") for page in reader.pages)[:max_chars]

    if suffix in (".xlsx", ".xlsm"):
        from openpyxl import load_workbook

        wb = load_workbook(path, read_only=True, data_only=True)
        parts: List[str] = []
        for sheet in wb.worksheets:
            parts.append(f"# Sheet: {sheet.title}")
            for row in sheet.iter_rows(values_only=True):
                cells = [str(c) for c in row if c is not None]
                if cells:
                    parts.append(" | ".join(cells))
        wb.close()
        return "\n".join(parts)[:max_chars]

    return f"[Unsupported file type {suffix!r} for text extraction]"
