"""
Delivery tools: SMTP email and Telegram.

Email defaults to Resend SMTP (smtp.resend.com:587, username literally
"resend", password is the API key). Any other SMTP provider works by changing
the host, port and credentials in Settings, so Brevo, Mailjet, SMTP2GO and
Mailtrap all drop in without a code change.

Telegram uses the plain Bot API over HTTPS. Receiving uses long polling
(getUpdates) rather than webhooks, so no public URL, tunnel, or certificate
is needed for the bot to accept commands.

Both functions return (ok, detail) instead of raising. A failed notification
must never fail the task that produced the work.
"""

from __future__ import annotations

import mimetypes
import smtplib
import ssl
from email.message import EmailMessage
from html import escape
from pathlib import Path
from typing import Iterable, List, Sequence, Tuple

import requests

from ..config import settings

MAX_ATTACHMENT_BYTES = 8 * 1024 * 1024   # keep well under typical SMTP limits
TELEGRAM_TEXT_LIMIT = 4000               # Bot API hard limit is 4096


def _ssl_context() -> ssl.SSLContext:
    """
    TLS context with a CA bundle that actually exists on this machine.

    A python.org framework build on macOS ships no system trust store until
    "Install Certificates.command" has been run, so ssl.create_default_context()
    fails STARTTLS with CERTIFICATE_VERIFY_FAILED even though the credentials
    are correct. certifi is already present as a requests dependency and
    carries the Mozilla root bundle, so prefer it and fall back to the system
    store when it is not installed.
    """
    try:
        import certifi

        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        return ssl.create_default_context()


# ---------------------------------------------------------------- email ----

def send_email(
    to: str,
    subject: str,
    body_markdown: str,
    attachments: Sequence[str] = (),
) -> Tuple[bool, str]:
    """Send one email with optional file attachments over SMTP."""
    to = (to or settings.notify_email or "").strip()
    if not to:
        return False, "No recipient address configured."
    if not settings.smtp_password:
        return False, "SMTP password (Resend API key) is not set."

    msg = EmailMessage()
    msg["Subject"] = subject[:200]
    msg["From"] = settings.smtp_from
    msg["To"] = to
    msg.set_content(body_markdown)
    msg.add_alternative(_html_wrap(subject, body_markdown), subtype="html")

    skipped: List[str] = []
    for item in attachments or ():
        path = Path(item)
        if not path.exists() or not path.is_file():
            continue
        if path.stat().st_size > MAX_ATTACHMENT_BYTES:
            skipped.append(f"{path.name} (too large)")
            continue
        ctype, _ = mimetypes.guess_type(path.name)
        maintype, _, subtype = (ctype or "application/octet-stream").partition("/")
        msg.add_attachment(
            path.read_bytes(), maintype=maintype, subtype=subtype, filename=path.name
        )

    try:
        if settings.smtp_port == 465:
            with smtplib.SMTP_SSL(
                settings.smtp_host, settings.smtp_port,
                timeout=30, context=_ssl_context(),
            ) as smtp:
                smtp.login(settings.smtp_user, settings.smtp_password)
                smtp.send_message(msg)
        else:
            with smtplib.SMTP(settings.smtp_host, settings.smtp_port, timeout=30) as smtp:
                smtp.ehlo()
                if settings.smtp_starttls:
                    smtp.starttls(context=_ssl_context())
                    smtp.ehlo()
                smtp.login(settings.smtp_user, settings.smtp_password)
                smtp.send_message(msg)
    except smtplib.SMTPAuthenticationError as exc:
        return False, f"SMTP auth rejected: {exc}"
    except Exception as exc:
        return False, f"SMTP send failed: {exc}"

    note = f" (skipped {', '.join(skipped)})" if skipped else ""
    return True, f"Sent to {to}{note}"


def _html_wrap(subject: str, body: str) -> str:
    """Minimal, email-client-safe HTML rendering of the plain body."""
    paragraphs = "".join(
        f"<p style='margin:0 0 12px;line-height:1.55'>{escape(block).replace(chr(10), '<br>')}</p>"
        for block in body.split("\n\n") if block.strip()
    )
    return f"""<!doctype html><html><body style="margin:0;background:#f4f6f9;padding:24px;
font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;color:#22303f">
<div style="max-width:640px;margin:0 auto;background:#fff;border:1px solid #dfe6ee;border-radius:10px;overflow:hidden">
<div style="background:#1F3A5F;color:#fff;padding:16px 22px;font-size:15px;font-weight:600">
{escape(subject)}</div>
<div style="padding:22px;font-size:14px">{paragraphs}</div>
<div style="padding:12px 22px;background:#f7f9fc;border-top:1px solid #e7edf4;font-size:11px;color:#7a8b9c">
Sent automatically by the Autonomous Task Desk.</div></div></body></html>"""


def smtp_test() -> Tuple[bool, str]:
    """Connect and authenticate without sending, for the Settings test button."""
    if not settings.smtp_password:
        return False, "SMTP password is not set."
    try:
        if settings.smtp_port == 465:
            smtp = smtplib.SMTP_SSL(settings.smtp_host, settings.smtp_port, timeout=20)
        else:
            smtp = smtplib.SMTP(settings.smtp_host, settings.smtp_port, timeout=20)
            smtp.ehlo()
            if settings.smtp_starttls:
                smtp.starttls(context=_ssl_context())
                smtp.ehlo()
        with smtp:
            smtp.login(settings.smtp_user, settings.smtp_password)
        return True, f"Authenticated with {settings.smtp_host}:{settings.smtp_port}"
    except Exception as exc:
        return False, str(exc)


# ------------------------------------------------------------- telegram ----

def _api(method: str) -> str:
    return f"https://api.telegram.org/bot{settings.telegram_token}/{method}"


def send_telegram(text: str, chat_id: str = "") -> Tuple[bool, str]:
    """Send a plain-text message to a Telegram chat."""
    chat_id = (chat_id or settings.telegram_chat_id or "").strip()
    if not settings.telegram_token:
        return False, "Telegram bot token is not set."
    if not chat_id:
        return False, "No Telegram chat id configured."

    try:
        resp = requests.post(
            _api("sendMessage"),
            json={
                "chat_id": chat_id,
                "text": text[:TELEGRAM_TEXT_LIMIT],
                "disable_web_page_preview": True,
            },
            timeout=20,
        )
        data = resp.json()
    except Exception as exc:
        return False, f"Telegram request failed: {exc}"

    if not data.get("ok"):
        return False, str(data.get("description", data))[:300]
    return True, f"Delivered to chat {chat_id}"


def send_telegram_document(path: str, caption: str = "", chat_id: str = "") -> Tuple[bool, str]:
    """Upload one artifact to a Telegram chat."""
    chat_id = (chat_id or settings.telegram_chat_id or "").strip()
    if not settings.telegram_token or not chat_id:
        return False, "Telegram is not configured."

    file_path = Path(path)
    if not file_path.exists():
        return False, f"No such file: {path}"

    try:
        with file_path.open("rb") as fh:
            resp = requests.post(
                _api("sendDocument"),
                data={"chat_id": chat_id, "caption": caption[:1000]},
                files={"document": (file_path.name, fh)},
                timeout=60,
            )
        data = resp.json()
    except Exception as exc:
        return False, f"Telegram upload failed: {exc}"

    if not data.get("ok"):
        return False, str(data.get("description", data))[:300]
    return True, f"Uploaded {file_path.name}"


def get_updates(offset: int = 0, timeout: int = 25) -> Tuple[List[dict], str]:
    """
    Long-poll for incoming messages.

    Returns (updates, error). The HTTP timeout is deliberately longer than the
    poll timeout so the connection is closed by Telegram, not by requests.
    """
    if not settings.telegram_token:
        return [], "Telegram bot token is not set."
    try:
        resp = requests.get(
            _api("getUpdates"),
            params={"offset": offset, "timeout": timeout},
            timeout=timeout + 10,
        )
        data = resp.json()
    except Exception as exc:
        return [], str(exc)

    if not data.get("ok"):
        return [], str(data.get("description", data))[:300]
    return data.get("result", []), ""


def telegram_test() -> Tuple[bool, str]:
    """Verify the bot token with getMe, for the Settings test button."""
    if not settings.telegram_token:
        return False, "Telegram bot token is not set."
    try:
        data = requests.get(_api("getMe"), timeout=15).json()
    except Exception as exc:
        return False, str(exc)
    if not data.get("ok"):
        return False, str(data.get("description", data))[:300]
    bot = data.get("result", {})
    return True, f"Connected as @{bot.get('username', '?')}"
