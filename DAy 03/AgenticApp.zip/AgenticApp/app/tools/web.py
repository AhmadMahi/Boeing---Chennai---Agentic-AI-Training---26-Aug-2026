"""
Web tools: DuckDuckGo search and page text extraction.

DuckDuckGo needs no API key and no account, which is why it is the default
research backend. The `ddgs` package handles the HTML endpoint and rate
limiting; a failed search returns a readable message rather than raising, so
one flaky lookup never kills a task run.
"""

from __future__ import annotations

import re
from typing import Any, Dict, List

import requests

USER_AGENT = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"
)


def search(query: str, max_results: int = 5) -> List[Dict[str, str]]:
    """Run a DuckDuckGo text search. Returns [] on failure."""
    try:
        from ddgs import DDGS

        with DDGS() as ddgs:
            raw = ddgs.text(query, max_results=max_results) or []
    except Exception as exc:  # network down, rate limited, package missing
        return [{"title": "search_error", "href": "", "body": str(exc)[:300]}]

    results: List[Dict[str, str]] = []
    for item in raw[:max_results]:
        results.append({
            "title": str(item.get("title", ""))[:200],
            "href": str(item.get("href") or item.get("url") or ""),
            "body": str(item.get("body") or item.get("description") or "")[:600],
        })
    return results


def fetch(url: str, max_chars: int = 6000) -> str:
    """
    Download one page and return readable text.

    Scripts, styles, navigation and footers are stripped before the text is
    collapsed, so the agent sees article content rather than chrome.
    """
    if not url.startswith(("http://", "https://")):
        return "Refused: only http and https URLs are allowed."

    try:
        resp = requests.get(
            url, headers={"User-Agent": USER_AGENT}, timeout=20, verify=True
        )
        resp.raise_for_status()
    except Exception as exc:
        return f"Fetch failed for {url}: {exc}"

    ctype = resp.headers.get("content-type", "")
    if "html" not in ctype and "text" not in ctype:
        return f"Skipped {url}: unsupported content type {ctype!r}."

    try:
        from bs4 import BeautifulSoup

        soup = BeautifulSoup(resp.text, "html.parser")
        for tag in soup(["script", "style", "nav", "footer", "header", "form", "noscript"]):
            tag.decompose()
        main = soup.find("article") or soup.find("main") or soup.body or soup
        text = main.get_text(separator="\n")
    except Exception:
        text = re.sub(r"<[^>]+>", " ", resp.text)

    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text).strip()
    return text[:max_chars]


def search_and_summarize(query: str, max_results: int = 5) -> str:
    """Search, then format the hits as a compact numbered evidence block."""
    hits = search(query, max_results)
    if not hits:
        return f"No results for {query!r}."

    lines = [f"Search results for {query!r}:"]
    for i, hit in enumerate(hits, 1):
        lines.append(f"{i}. {hit['title']}\n   {hit['href']}\n   {hit['body']}")
    return "\n".join(lines)
