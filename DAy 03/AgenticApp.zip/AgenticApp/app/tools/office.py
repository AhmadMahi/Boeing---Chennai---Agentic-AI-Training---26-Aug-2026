"""
Document tools: read the task sheet, write Excel and PDF deliverables.

    read_task_sheet   openpyxl, tolerant column matching
    write_xlsx        openpyxl, styled result workbook
    write_pdf         ReportLab platypus, headed and paginated report

The PDF writer understands a small Markdown subset (# headings, - bullets,
| tables |, **bold**) because that is what the Writer agent naturally emits.
"""

from __future__ import annotations

import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from .files import safe_path

# Canonical task-sheet columns and the header spellings accepted for each.
COLUMN_ALIASES: Dict[str, List[str]] = {
    "task_key":        ["task_id", "task key", "id", "ref", "task"],
    "title":           ["title", "task title", "name", "subject"],
    "description":     ["description", "details", "instruction", "instructions", "notes"],
    "priority":        ["priority", "importance"],
    "due_date":        ["due_date", "due date", "deadline", "due"],
    "skill_hint":      ["skill_hint", "skill", "skills", "skill hint"],
    "tools_allowed":   ["tools_allowed", "tools", "allowed tools"],
    "output_format":   ["output_format", "output", "format", "deliverable"],
    "notify_email":    ["notify_email", "email", "notify email", "recipient"],
    "notify_telegram": ["notify_telegram", "telegram", "notify telegram", "chat_id"],
    "depends_on":      ["depends_on", "depends on", "dependency", "after"],
}

BRAND = "1F3A5F"      # header navy
ACCENT = "E8EEF6"     # banded row tint


def _normalize(header: Any) -> str:
    return re.sub(r"[^a-z0-9 _]", "", str(header or "").strip().lower())


def read_task_sheet(path: str | Path) -> List[Dict[str, Any]]:
    """
    Parse an .xlsx task list into normalized task dicts.

    The first row is the header. Column order does not matter and unknown
    columns are ignored, so a sheet with extra project columns still loads.
    Rows with no title are skipped rather than failing the whole upload.
    """
    wb = load_workbook(path, read_only=True, data_only=True)
    sheet = wb.worksheets[0]
    rows = sheet.iter_rows(values_only=True)

    try:
        header = next(rows)
    except StopIteration:
        wb.close()
        return []

    # header index -> canonical field name
    mapping: Dict[int, str] = {}
    for idx, cell in enumerate(header):
        norm = _normalize(cell)
        for field, aliases in COLUMN_ALIASES.items():
            if norm == field or norm in aliases:
                mapping[idx] = field
                break

    tasks: List[Dict[str, Any]] = []
    for i, row in enumerate(rows, start=2):
        record: Dict[str, Any] = {}
        for idx, value in enumerate(row):
            field = mapping.get(idx)
            if field and value is not None:
                record[field] = str(value).strip() if not isinstance(value, str) else value.strip()

        if not record.get("title"):
            continue

        record.setdefault("task_key", f"T{i - 1:03d}")
        record.setdefault("priority", "medium")
        record.setdefault("output_format", "pdf")
        tasks.append(record)

    wb.close()
    return tasks


def write_task_template(path: str | Path) -> str:
    """Generate the sample task sheet shipped in samples/."""
    wb = Workbook()
    ws = wb.active
    ws.title = "Tasks"

    headers = list(COLUMN_ALIASES.keys())
    ws.append(headers)

    examples = [
        ["T001", "Competitor scan: enterprise AI training vendors",
         "Identify the five most visible vendors offering enterprise AI upskilling in 2026. "
         "For each, capture positioning, target buyer, and delivery format. Cite every source.",
         "high", "2026-09-05", "market_research", "web_search,web_fetch", "pdf",
         "", "", ""],
        ["T002", "Summarize the uploaded policy documents",
         "Search the internal corpus for retention and approval requirements, then produce a "
         "one page summary with citations to the source document names.",
         "medium", "2026-09-06", "document_analysis", "rag_search", "md", "", "", ""],
        ["T003", "Build a comparison table from T001",
         "Turn the vendor findings into a scored comparison table across price transparency, "
         "hands on labs, and enterprise readiness. Explain the scoring rubric.",
         "medium", "2026-09-08", "data_analysis", "web_search", "xlsx", "", "", "T001"],
        ["T004", "Draft a 6 week SAP FICO learning roadmap",
         "Research the standard SAP FICO curriculum, then produce a week by week roadmap with "
         "objectives, lab exercises, and a checkpoint per week.",
         "low", "2026-09-12", "training_design", "web_search,web_fetch", "all", "", "", ""],
    ]
    for row in examples:
        ws.append(row)

    _style_sheet(ws, len(headers))

    # Second sheet documents every column so the user is never guessing.
    doc = wb.create_sheet("How to fill this in")
    doc.append(["Column", "Required", "What to put in it"])
    guide = [
        ("task_key", "no", "Your own reference, e.g. T001. Generated automatically if blank."),
        ("title", "YES", "Short name for the task. A row without a title is skipped."),
        ("description", "YES", "The actual instruction. Be specific: the Planner reads only this."),
        ("priority", "no", "high, medium, or low. High priority tasks run first."),
        ("due_date", "no", "Free text or YYYY-MM-DD. Shown in the report, not enforced."),
        ("skill_hint", "no", "Name of a skill in the skills folder. Blank means auto discovery."),
        ("tools_allowed", "no", "Comma separated tool names. Blank means every enabled tool."),
        ("output_format", "no", "pdf, xlsx, md, or all. Defaults to pdf."),
        ("notify_email", "no", "Email address to notify on completion. Blank uses the app default."),
        ("notify_telegram", "no", "Telegram chat id. Blank uses the app default."),
        ("depends_on", "no", "task_key of a task that must finish first, e.g. T001."),
    ]
    for row in guide:
        doc.append(list(row))
    _style_sheet(doc, 3)

    out = Path(path)
    out.parent.mkdir(parents=True, exist_ok=True)
    wb.save(out)
    return str(out)


def _style_sheet(ws: Any, ncols: int) -> None:
    """Header fill, freeze panes, banded rows, sane column widths."""
    thin = Side(style="thin", color="C7D2E0")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)

    for col in range(1, ncols + 1):
        cell = ws.cell(row=1, column=col)
        cell.font = Font(bold=True, color="FFFFFF", size=11)
        cell.fill = PatternFill("solid", fgColor=BRAND)
        cell.alignment = Alignment(vertical="center", horizontal="left")
        cell.border = border

    for row in range(2, ws.max_row + 1):
        for col in range(1, ncols + 1):
            cell = ws.cell(row=row, column=col)
            cell.alignment = Alignment(vertical="top", wrap_text=True)
            cell.border = border
            if row % 2 == 0:
                cell.fill = PatternFill("solid", fgColor=ACCENT)

    widths = [14, 34, 60, 10, 12, 18, 22, 14, 22, 18, 12]
    for col in range(1, ncols + 1):
        ws.column_dimensions[get_column_letter(col)].width = (
            widths[col - 1] if col - 1 < len(widths) else 24
        )
    ws.freeze_panes = "A2"
    ws.row_dimensions[1].height = 22


def write_xlsx(filename: str, title: str, rows: List[Dict[str, Any]],
               run_id: Any = None) -> str:
    """Write a list of dicts as a styled worksheet. Keys of row 0 are the header."""
    path = safe_path(filename if filename.endswith(".xlsx") else f"{filename}.xlsx", run_id)

    wb = Workbook()
    ws = wb.active
    ws.title = title[:31] or "Report"

    if not rows:
        ws.append(["No data"])
    else:
        headers = list(rows[0].keys())
        ws.append([h.replace("_", " ").title() for h in headers])
        for row in rows:
            ws.append([_flatten(row.get(h, "")) for h in headers])
        _style_sheet(ws, len(headers))

    wb.save(path)
    return str(path)


def _flatten(value: Any) -> str:
    if isinstance(value, (list, tuple)):
        return ", ".join(str(v) for v in value)
    if isinstance(value, dict):
        return "; ".join(f"{k}={v}" for k, v in value.items())
    return "" if value is None else str(value)


# --------------------------------------------------------------- PDF ------

def write_pdf(filename: str, title: str, markdown: str,
              subtitle: str = "", run_id: Any = None) -> str:
    """Render a Markdown-ish report body to a paginated PDF via ReportLab."""
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_LEFT
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import mm
    from reportlab.platypus import (
        HRFlowable, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle,
    )

    path = safe_path(filename if filename.endswith(".pdf") else f"{filename}.pdf", run_id)
    navy = colors.HexColor("#1F3A5F")
    slate = colors.HexColor("#5A6B7F")

    base = getSampleStyleSheet()
    styles = {
        "title": ParagraphStyle("t", parent=base["Title"], fontSize=20, leading=25,
                                textColor=navy, alignment=TA_LEFT, spaceAfter=2),
        "subtitle": ParagraphStyle("st", parent=base["Normal"], fontSize=9.5, leading=13,
                                   textColor=slate, spaceAfter=10),
        "h1": ParagraphStyle("h1", parent=base["Heading1"], fontSize=15, leading=19,
                             textColor=navy, spaceBefore=14, spaceAfter=6),
        "h2": ParagraphStyle("h2", parent=base["Heading2"], fontSize=12.5, leading=16,
                             textColor=navy, spaceBefore=11, spaceAfter=4),
        "h3": ParagraphStyle("h3", parent=base["Heading3"], fontSize=11, leading=14,
                             textColor=slate, spaceBefore=9, spaceAfter=3),
        "body": ParagraphStyle("b", parent=base["BodyText"], fontSize=10, leading=14.5,
                               spaceAfter=6),
        "bullet": ParagraphStyle("bu", parent=base["BodyText"], fontSize=10, leading=14.5,
                                 leftIndent=12, bulletIndent=3, spaceAfter=3),
        "code": ParagraphStyle("c", parent=base["Code"], fontSize=8.5, leading=11,
                               backColor=colors.HexColor("#F2F5F9"), leftIndent=8),
    }

    story: List[Any] = [
        Paragraph(_inline(title), styles["title"]),
        Paragraph(
            _inline(subtitle
                    or f"Generated {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}"),
            styles["subtitle"],
        ),
        HRFlowable(width="100%", thickness=1.2, color=navy, spaceAfter=10),
    ]
    story.extend(_markdown_to_flowables(markdown, styles, navy))

    def footer(canvas: Any, doc: Any) -> None:
        canvas.saveState()
        canvas.setFont("Helvetica", 7.5)
        canvas.setFillColor(slate)
        canvas.drawString(18 * mm, 12 * mm, "Autonomous Task Desk")
        canvas.drawRightString(A4[0] - 18 * mm, 12 * mm, f"Page {canvas.getPageNumber()}")
        canvas.restoreState()

    SimpleDocTemplate(
        str(path), pagesize=A4,
        leftMargin=18 * mm, rightMargin=18 * mm, topMargin=18 * mm, bottomMargin=20 * mm,
        title=title, author="Autonomous Task Desk",
    ).build(story, onFirstPage=footer, onLaterPages=footer)

    return str(path)


def _inline(text: str) -> str:
    """Convert **bold**, *italic*, `code` and bare URLs to ReportLab markup."""
    text = (text or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    text = re.sub(r"\[([^\]]+)\]\((https?://[^)]+)\)", r'<link href="\2" color="#1F6FEB">\1</link>', text)
    text = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", text)
    text = re.sub(r"(?<!\*)\*([^*\n]+?)\*(?!\*)", r"<i>\1</i>", text)
    text = re.sub(r"`([^`]+?)`", r'<font face="Courier" size="9">\1</font>', text)
    return text


def _markdown_to_flowables(md: str, styles: Dict[str, Any], navy: Any) -> List[Any]:
    """Small Markdown subset to platypus flowables: headings, bullets, tables, rules."""
    from reportlab.lib import colors
    from reportlab.platypus import HRFlowable, PageBreak, Paragraph, Spacer, Table, TableStyle

    flow: List[Any] = []
    table_buffer: List[List[str]] = []
    in_code = False
    code_lines: List[str] = []

    def flush_table() -> None:
        if not table_buffer:
            return
        header, *body = table_buffer
        data = [[Paragraph(_inline(c), styles["body"]) for c in row] for row in [header] + body]
        table = Table(data, repeatRows=1, hAlign="LEFT")
        table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), navy),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#C7D2E0")),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1),
             [colors.white, colors.HexColor("#F2F5F9")]),
            ("LEFTPADDING", (0, 0), (-1, -1), 5),
            ("RIGHTPADDING", (0, 0), (-1, -1), 5),
            ("TOPPADDING", (0, 0), (-1, -1), 4),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ]))
        flow.extend([table, Spacer(1, 8)])
        table_buffer.clear()

    for raw in (md or "").splitlines():
        line = raw.rstrip()

        if line.strip().startswith("```"):
            if in_code:
                flow.append(Paragraph("<br/>".join(
                    l.replace("&", "&amp;").replace("<", "&lt;") for l in code_lines
                ), styles["code"]))
                flow.append(Spacer(1, 6))
                code_lines.clear()
            in_code = not in_code
            continue
        if in_code:
            code_lines.append(line)
            continue

        if line.strip().startswith("|") and line.strip().endswith("|"):
            cells = [c.strip() for c in line.strip().strip("|").split("|")]
            if all(set(c) <= set("-: ") for c in cells):   # separator row
                continue
            table_buffer.append(cells)
            continue
        flush_table()

        if not line.strip():
            flow.append(Spacer(1, 4))
        elif line.startswith("#### ") or line.startswith("### "):
            flow.append(Paragraph(_inline(line.lstrip("# ").strip()), styles["h3"]))
        elif line.startswith("## "):
            flow.append(Paragraph(_inline(line[3:].strip()), styles["h2"]))
        elif line.startswith("# "):
            flow.append(Paragraph(_inline(line[2:].strip()), styles["h1"]))
        elif line.strip() in ("---", "***", "___"):
            flow.append(HRFlowable(width="100%", thickness=0.6,
                                   color=colors.HexColor("#C7D2E0"), spaceAfter=6))
        elif re.match(r"^\s*[-*+]\s+", line):
            flow.append(Paragraph(_inline(re.sub(r"^\s*[-*+]\s+", "", line)),
                                  styles["bullet"], bulletText="•"))
        elif re.match(r"^\s*\d+[.)]\s+", line):
            num = re.match(r"^\s*(\d+)", line).group(1)
            flow.append(Paragraph(_inline(re.sub(r"^\s*\d+[.)]\s+", "", line)),
                                  styles["bullet"], bulletText=f"{num}."))
        else:
            flow.append(Paragraph(_inline(line.strip()), styles["body"]))

    flush_table()
    return flow
