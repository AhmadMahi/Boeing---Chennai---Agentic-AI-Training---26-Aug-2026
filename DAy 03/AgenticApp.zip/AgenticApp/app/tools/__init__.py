"""
Tool registry.

Every tool is a LangChain StructuredTool with a typed argument schema, so both
ChatOpenAI and BoeingChatModel can bind them through the same
`convert_to_openai_tool` path.

Run context (which run and task is executing) travels in a ContextVar rather
than in the tool arguments. The model therefore never chooses where a file is
written, which keeps artifacts inside the correct run workspace no matter what
the model asks for.

Email and Telegram are intentionally NOT agent tools. Delivery happens in the
graph's deliver node after a task is reviewed, so an agent cannot decide to
message anyone mid-reasoning.
"""

from __future__ import annotations

import contextvars
from typing import Any, Dict, List, Optional

from langchain_core.tools import StructuredTool
from pydantic import BaseModel, Field

from ..config import settings
from . import files as files_tool
from . import office, web

# ---- run context ---------------------------------------------------------

_ctx: contextvars.ContextVar[Dict[str, Any]] = contextvars.ContextVar(
    "task_ctx", default={"run_id": None, "task_id": None, "artifacts": []}
)


def set_context(run_id: Any, task_id: Any) -> None:
    _ctx.set({"run_id": run_id, "task_id": task_id, "artifacts": []})


def context() -> Dict[str, Any]:
    return _ctx.get()


def artifacts() -> List[str]:
    return list(_ctx.get().get("artifacts", []))


def _record(path: str) -> None:
    ctx = _ctx.get()
    if path not in ctx["artifacts"]:
        ctx["artifacts"].append(path)


# ---- argument schemas ----------------------------------------------------

class SearchArgs(BaseModel):
    query: str = Field(description="Search phrase. Be specific and use distinct wording per call.")
    max_results: int = Field(default=5, ge=1, le=10, description="How many results to return.")


class FetchArgs(BaseModel):
    url: str = Field(description="Full http or https URL of the page to read.")


class RagArgs(BaseModel):
    query: str = Field(description="What to look for in the uploaded document corpus.")
    k: int = Field(default=4, ge=1, le=10, description="Number of passages to retrieve.")


class WriteFileArgs(BaseModel):
    filename: str = Field(description="File name only, for example findings.md")
    content: str = Field(description="Full text content of the file.")


class ReadFileArgs(BaseModel):
    filename: str = Field(description="Name of a file previously written in this run.")


class WriteXlsxArgs(BaseModel):
    filename: str = Field(description="File name ending in .xlsx")
    title: str = Field(description="Worksheet title, 31 characters or fewer.")
    rows: List[Dict[str, Any]] = Field(
        description="Flat list of row objects. Keys of the first row become the header."
    )


class WritePdfArgs(BaseModel):
    filename: str = Field(description="File name ending in .pdf")
    title: str = Field(description="Report title shown at the top of page one.")
    body_markdown: str = Field(
        description="Report body. Supports # headings, - bullets, | tables | and **bold**."
    )


# ---- implementations -----------------------------------------------------

def _web_search(query: str, max_results: int = 5) -> str:
    return web.search_and_summarize(query, min(max_results, settings.search_results))


def _web_fetch(url: str) -> str:
    return web.fetch(url)


def _rag_search(query: str, k: int = 4) -> str:
    from ..vectorstore import search_documents

    try:
        hits = search_documents(query, k)
    except Exception as exc:
        return f"Document search unavailable: {exc}"
    if not hits:
        return "No documents in the knowledge base match that query."
    return "\n\n".join(
        f"[{h['source']} #{h['chunk']} score={h['score']}]\n{h['text']}" for h in hits
    )


def _write_file(filename: str, content: str) -> str:
    path = files_tool.write_file(filename, content, context()["run_id"])
    _record(path)
    return f"Wrote {len(content)} characters to {filename}"


def _read_file(filename: str) -> str:
    return files_tool.read_file(filename, context()["run_id"])


def _write_xlsx(filename: str, title: str, rows: List[Dict[str, Any]]) -> str:
    path = office.write_xlsx(filename, title, rows, context()["run_id"])
    _record(path)
    return f"Wrote {len(rows)} rows to {filename}"


def _write_pdf(filename: str, title: str, body_markdown: str) -> str:
    path = office.write_pdf(filename, title, body_markdown, run_id=context()["run_id"])
    _record(path)
    return f"Wrote PDF {filename}"


# ---- registry ------------------------------------------------------------

_SPECS = [
    ("web_search", _web_search, SearchArgs,
     "Search the public web with DuckDuckGo. Returns titles, URLs and snippets. "
     "Use several differently worded searches rather than one broad one."),
    ("web_fetch", _web_fetch, FetchArgs,
     "Download one web page and return its readable text. Use this on the most "
     "promising search results, because snippets alone are not evidence."),
    ("rag_search", _rag_search, RagArgs,
     "Search the uploaded internal document corpus. Use for anything that should "
     "come from company documents rather than the open web."),
    ("write_file", _write_file, WriteFileArgs,
     "Save text to a file in this run's workspace, for notes or a Markdown deliverable."),
    ("read_file", _read_file, ReadFileArgs,
     "Read back a file written earlier in this run."),
    ("write_xlsx", _write_xlsx, WriteXlsxArgs,
     "Write a styled Excel worksheet from a list of row objects."),
    ("write_pdf", _write_pdf, WritePdfArgs,
     "Render a Markdown report body as a formatted PDF."),
]

ALL_TOOL_NAMES = [name for name, *_ in _SPECS]

DEFAULT_TOOLS = ["web_search", "web_fetch", "rag_search", "write_file", "read_file"]
WRITER_TOOLS = ["write_file", "write_xlsx", "write_pdf", "read_file"]


def build(allowed: Optional[List[str]] = None) -> List[StructuredTool]:
    """
    Build the tool objects for one agent step.

    `allowed` is enforced here in code. A skill file can request tools, but it
    cannot grant itself any beyond this list.
    """
    names = set(allowed) if allowed else set(ALL_TOOL_NAMES)
    tools: List[StructuredTool] = []
    for name, fn, schema, description in _SPECS:
        if name not in names:
            continue
        tools.append(
            StructuredTool.from_function(
                func=fn, name=name, description=description, args_schema=schema
            )
        )
    return tools


def normalize_allowed(raw: str | None, skill_tools: Optional[List[str]] = None) -> List[str]:
    """
    Resolve the effective tool list for a task.

    Spreadsheet column wins, then the selected skills' declared tools, then the
    default set. Unknown names are dropped rather than raising, so a typo in a
    task sheet degrades gracefully.
    """
    if raw and str(raw).strip():
        wanted = [t.strip() for t in str(raw).replace(";", ",").split(",") if t.strip()]
    elif skill_tools:
        wanted = list(skill_tools)
    else:
        wanted = list(DEFAULT_TOOLS)

    valid = [t for t in wanted if t in ALL_TOOL_NAMES]
    return valid or list(DEFAULT_TOOLS)
