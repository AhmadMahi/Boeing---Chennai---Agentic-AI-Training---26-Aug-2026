"""
SQLite persistence layer.

One file, no ORM. Every write goes through a short-lived connection so the
FastAPI threadpool and the background worker never share a handle.

Tables
    runs        one uploaded task sheet
    tasks       one row of that sheet, plus its plan and result
    events      append-only agent trace, streamed to the browser over SSE
    deliveries  every email / telegram send attempt
    documents   files ingested into the ChromaDB corpus
    skills      installed skill manifests
"""

from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Any, Dict, Iterator, List, Optional

from .config import DB_PATH

SCHEMA = """
CREATE TABLE IF NOT EXISTS runs (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    name          TEXT NOT NULL,
    source_file   TEXT,
    provider      TEXT,
    status        TEXT NOT NULL DEFAULT 'pending',
    tasks_total   INTEGER DEFAULT 0,
    tasks_done    INTEGER DEFAULT 0,
    created_at    TEXT NOT NULL,
    finished_at   TEXT
);

CREATE TABLE IF NOT EXISTS tasks (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id          INTEGER NOT NULL REFERENCES runs(id) ON DELETE CASCADE,
    task_key        TEXT NOT NULL,
    title           TEXT NOT NULL,
    description     TEXT,
    priority        TEXT,
    due_date        TEXT,
    skill_hint      TEXT,
    tools_allowed   TEXT,
    output_format   TEXT DEFAULT 'pdf',
    notify_email    TEXT,
    notify_telegram TEXT,
    depends_on      TEXT,
    status          TEXT NOT NULL DEFAULT 'pending',
    plan_json       TEXT,
    findings_md     TEXT,
    result_md       TEXT,
    review_json     TEXT,
    guardrails_json TEXT,
    artifacts_json  TEXT,
    skills_used     TEXT,
    tokens          INTEGER DEFAULT 0,
    error           TEXT,
    started_at      TEXT,
    finished_at     TEXT
);

CREATE TABLE IF NOT EXISTS events (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id    INTEGER,
    task_id   INTEGER,
    ts        TEXT NOT NULL,
    agent     TEXT,
    kind      TEXT,
    message   TEXT,
    data_json TEXT
);

CREATE TABLE IF NOT EXISTS deliveries (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id INTEGER,
    run_id  INTEGER,
    channel TEXT,
    target  TEXT,
    status  TEXT,
    detail  TEXT,
    ts      TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS documents (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    filename   TEXT NOT NULL,
    chunks     INTEGER DEFAULT 0,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS skills (
    name         TEXT PRIMARY KEY,
    version      TEXT,
    description  TEXT,
    keywords     TEXT,
    tools        TEXT,
    path         TEXT,
    source       TEXT,
    enabled      INTEGER DEFAULT 1,
    installed_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_tasks_run   ON tasks(run_id);
CREATE INDEX IF NOT EXISTS idx_events_run  ON events(run_id);
CREATE INDEX IF NOT EXISTS idx_events_id   ON events(id);
"""


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


@contextmanager
def connect() -> Iterator[sqlite3.Connection]:
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


# Columns added after the first release, applied on every startup.
MIGRATIONS = [
    ("tasks", "guardrails_json", "TEXT"),
]


def init_db() -> None:
    with connect() as conn:
        conn.executescript(SCHEMA)
        for table, column, coltype in MIGRATIONS:
            existing = {r["name"] for r in conn.execute(f"PRAGMA table_info({table})")}
            if column not in existing:
                conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {coltype}")


def _rows(cur: sqlite3.Cursor) -> List[Dict[str, Any]]:
    return [dict(r) for r in cur.fetchall()]


# ---------------------------------------------------------------- runs ----

def create_run(name: str, source_file: str, provider: str, total: int) -> int:
    with connect() as conn:
        cur = conn.execute(
            "INSERT INTO runs (name, source_file, provider, status, tasks_total, created_at) "
            "VALUES (?,?,?,'pending',?,?)",
            (name, source_file, provider, total, now()),
        )
        return int(cur.lastrowid)


def update_run(run_id: int, **fields: Any) -> None:
    if not fields:
        return
    sets = ", ".join(f"{k}=?" for k in fields)
    with connect() as conn:
        conn.execute(f"UPDATE runs SET {sets} WHERE id=?", (*fields.values(), run_id))


def get_run(run_id: int) -> Optional[Dict[str, Any]]:
    with connect() as conn:
        row = conn.execute("SELECT * FROM runs WHERE id=?", (run_id,)).fetchone()
        return dict(row) if row else None


def list_runs(limit: int = 50) -> List[Dict[str, Any]]:
    with connect() as conn:
        return _rows(conn.execute("SELECT * FROM runs ORDER BY id DESC LIMIT ?", (limit,)))


def bump_run_progress(run_id: int) -> None:
    with connect() as conn:
        conn.execute("UPDATE runs SET tasks_done = tasks_done + 1 WHERE id=?", (run_id,))


# --------------------------------------------------------------- tasks ----

TASK_COLUMNS = (
    "task_key", "title", "description", "priority", "due_date", "skill_hint",
    "tools_allowed", "output_format", "notify_email", "notify_telegram", "depends_on",
)


def create_task(run_id: int, task: Dict[str, Any]) -> int:
    cols = ", ".join(TASK_COLUMNS)
    marks = ", ".join("?" for _ in TASK_COLUMNS)
    values = [task.get(c) for c in TASK_COLUMNS]
    with connect() as conn:
        cur = conn.execute(
            f"INSERT INTO tasks (run_id, {cols}) VALUES (?, {marks})", (run_id, *values)
        )
        return int(cur.lastrowid)


def update_task(task_id: int, **fields: Any) -> None:
    if not fields:
        return
    sets = ", ".join(f"{k}=?" for k in fields)
    with connect() as conn:
        conn.execute(f"UPDATE tasks SET {sets} WHERE id=?", (*fields.values(), task_id))


def get_task(task_id: int) -> Optional[Dict[str, Any]]:
    with connect() as conn:
        row = conn.execute("SELECT * FROM tasks WHERE id=?", (task_id,)).fetchone()
        return dict(row) if row else None


def list_tasks(run_id: int) -> List[Dict[str, Any]]:
    with connect() as conn:
        return _rows(conn.execute("SELECT * FROM tasks WHERE run_id=? ORDER BY id", (run_id,)))


def completed_task_keys(run_id: int) -> List[str]:
    with connect() as conn:
        cur = conn.execute(
            "SELECT task_key FROM tasks WHERE run_id=? AND status='done'", (run_id,)
        )
        return [r["task_key"] for r in cur.fetchall()]


# -------------------------------------------------------------- events ----

def log_event(
    run_id: Optional[int],
    task_id: Optional[int],
    agent: str,
    kind: str,
    message: str,
    data: Any = None,
) -> int:
    with connect() as conn:
        cur = conn.execute(
            "INSERT INTO events (run_id, task_id, ts, agent, kind, message, data_json) "
            "VALUES (?,?,?,?,?,?,?)",
            (run_id, task_id, now(), agent, kind, message,
             json.dumps(data, default=str) if data is not None else None),
        )
        return int(cur.lastrowid)


def events_after(event_id: int, run_id: Optional[int] = None, limit: int = 200) -> List[Dict[str, Any]]:
    sql = "SELECT * FROM events WHERE id > ?"
    args: List[Any] = [event_id]
    if run_id is not None:
        sql += " AND run_id = ?"
        args.append(run_id)
    sql += " ORDER BY id LIMIT ?"
    args.append(limit)
    with connect() as conn:
        return _rows(conn.execute(sql, args))


def last_event_id() -> int:
    with connect() as conn:
        row = conn.execute("SELECT COALESCE(MAX(id), 0) AS m FROM events").fetchone()
        return int(row["m"])


# ---------------------------------------------------------- deliveries ----

def log_delivery(
    run_id: Optional[int], task_id: Optional[int],
    channel: str, target: str, status: str, detail: str = "",
) -> None:
    with connect() as conn:
        conn.execute(
            "INSERT INTO deliveries (task_id, run_id, channel, target, status, detail, ts) "
            "VALUES (?,?,?,?,?,?,?)",
            (task_id, run_id, channel, target, status, detail[:2000], now()),
        )


def list_deliveries(limit: int = 50) -> List[Dict[str, Any]]:
    with connect() as conn:
        return _rows(conn.execute("SELECT * FROM deliveries ORDER BY id DESC LIMIT ?", (limit,)))


# ----------------------------------------------------------- documents ----

def add_document(filename: str, chunks: int) -> None:
    with connect() as conn:
        conn.execute(
            "INSERT INTO documents (filename, chunks, created_at) VALUES (?,?,?)",
            (filename, chunks, now()),
        )


def list_documents() -> List[Dict[str, Any]]:
    with connect() as conn:
        return _rows(conn.execute("SELECT * FROM documents ORDER BY id DESC"))


# -------------------------------------------------------------- skills ----

def upsert_skill(meta: Dict[str, Any]) -> None:
    with connect() as conn:
        conn.execute(
            "INSERT INTO skills (name, version, description, keywords, tools, path, source, "
            "enabled, installed_at) VALUES (?,?,?,?,?,?,?,?,?) "
            "ON CONFLICT(name) DO UPDATE SET version=excluded.version, "
            "description=excluded.description, keywords=excluded.keywords, "
            "tools=excluded.tools, path=excluded.path, source=excluded.source",
            (
                meta["name"], meta.get("version", "1.0"), meta.get("description", ""),
                json.dumps(meta.get("keywords", [])), json.dumps(meta.get("tools_allowed", [])),
                meta.get("path", ""), meta.get("source", "local"), 1, now(),
            ),
        )


def list_skills(enabled_only: bool = False) -> List[Dict[str, Any]]:
    sql = "SELECT * FROM skills"
    if enabled_only:
        sql += " WHERE enabled=1"
    sql += " ORDER BY name"
    with connect() as conn:
        return _rows(conn.execute(sql))


def set_skill_enabled(name: str, enabled: bool) -> None:
    with connect() as conn:
        conn.execute("UPDATE skills SET enabled=? WHERE name=?", (1 if enabled else 0, name))


def delete_skill(name: str) -> None:
    with connect() as conn:
        conn.execute("DELETE FROM skills WHERE name=?", (name,))


def stats() -> Dict[str, int]:
    with connect() as conn:
        def one(sql: str) -> int:
            return int(conn.execute(sql).fetchone()[0])
        return {
            "runs": one("SELECT COUNT(*) FROM runs"),
            "tasks": one("SELECT COUNT(*) FROM tasks"),
            "tasks_done": one("SELECT COUNT(*) FROM tasks WHERE status='done'"),
            "tasks_failed": one("SELECT COUNT(*) FROM tasks WHERE status='failed'"),
            "skills": one("SELECT COUNT(*) FROM skills WHERE enabled=1"),
            "documents": one("SELECT COUNT(*) FROM documents"),
            "deliveries": one("SELECT COUNT(*) FROM deliveries WHERE status='sent'"),
        }
