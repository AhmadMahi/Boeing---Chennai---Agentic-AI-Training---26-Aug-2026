"""
Model provider switch: OpenAI or BCAI.

Both branches return real LangChain runnables, so every agent node calls the
same `.bind_tools(...).invoke(messages)` surface and nothing downstream cares
which backend is live.

    OpenAI  ->  ChatOpenAI / OpenAIEmbeddings   (langchain-openai)
    BCAI    ->  BoeingChatModel / BoeingEmbeddings (vendored in app/bcai/)

The BCAI wrappers are copied verbatim from the Boeing folder so this app is
self-contained. BoeingChatModel already implements bind_tools() against the
/conversation endpoint, including the "auto" | "none" | "required" tool_choice
restriction, which is why tool calling works identically on both providers.
"""

from __future__ import annotations

from typing import Any, List

from langchain_core.embeddings import Embeddings
from langchain_core.language_models.chat_models import BaseChatModel

from .config import settings


class ProviderError(RuntimeError):
    """Raised when the selected provider is missing a credential."""


def active_provider() -> str:
    return (settings.provider or "openai").lower().strip()


def provider_label() -> str:
    return "BCAI (Boeing)" if active_provider() == "bcai" else "OpenAI"


def check_ready() -> tuple[bool, str]:
    """Return (ready, reason) so the UI can show a red banner instead of a 500."""
    if active_provider() == "bcai":
        if not settings.udal_pat:
            return False, "UDAL_PAT is not set. Add it in Settings before running tasks."
        return True, ""
    if not settings.openai_api_key:
        return False, "OPENAI_API_KEY is not set. Add it in Settings before running tasks."
    return True, ""


def get_chat_model(temperature: float | None = None, **kwargs: Any) -> BaseChatModel:
    """Build a chat model for the currently selected provider."""
    temp = settings.temperature if temperature is None else temperature

    if active_provider() == "bcai":
        if not settings.udal_pat:
            raise ProviderError("UDAL_PAT is not set.")
        from .bcai.boeing_chat_model import BoeingChatModel

        return BoeingChatModel(
            api_url=settings.bcai_chat_url,
            udal_pat=settings.udal_pat,
            model=settings.bcai_chat_model,
            temperature=temp,
            **kwargs,
        )

    if not settings.openai_api_key:
        raise ProviderError("OPENAI_API_KEY is not set.")
    from langchain_openai import ChatOpenAI

    return ChatOpenAI(
        api_key=settings.openai_api_key,
        model=settings.openai_chat_model,
        temperature=temp,
        **kwargs,
    )


def get_embeddings() -> Embeddings:
    """Build an embeddings client for the currently selected provider."""
    if active_provider() == "bcai":
        if not settings.udal_pat:
            raise ProviderError("UDAL_PAT is not set.")
        from .bcai.boeing_embeddings import BoeingEmbeddings

        return BoeingEmbeddings(
            api_url=settings.bcai_embed_url,
            udal_pat=settings.udal_pat,
            model=settings.bcai_embed_model,
        )

    if not settings.openai_api_key:
        raise ProviderError("OPENAI_API_KEY is not set.")
    from langchain_openai import OpenAIEmbeddings

    return OpenAIEmbeddings(
        api_key=settings.openai_api_key,
        model=settings.openai_embed_model,
    )


def usage_of(message: Any) -> int:
    """
    Pull a total token count off an AIMessage regardless of provider.

    BoeingChatModel stashes it in response_metadata["usage"]; ChatOpenAI uses
    the standard usage_metadata field.
    """
    meta = getattr(message, "response_metadata", None) or {}
    usage = meta.get("usage") or meta.get("token_usage") or {}
    if usage.get("total_tokens"):
        return int(usage["total_tokens"])
    std = getattr(message, "usage_metadata", None) or {}
    return int(std.get("total_tokens", 0) or 0)


def embed_texts(texts: List[str]) -> List[List[float]]:
    return get_embeddings().embed_documents(texts)
