"""
FastAPI application: HTTP surface for the Autonomous Task Desk.

Route groups
    /                     the single-page UI
    /api/state            settings, stats, provider and worker status
    /api/settings         read and update runtime settings
    /api/tasks            upload a task sheet, download the sample
    /api/runs             start, watch, cancel and inspect runs
    /api/events           server-sent events, the live agent trace
    /api/documents        RAG corpus ingestion
    /api/skills           discover, upload, download and remove skills
    /api/telegram         start and stop the polling worker

Long work never happens in a request handler. Uploading a sheet only parses
it; execution runs in the orchestrator's background thread and the browser
follows along over SSE.
"""

from __future__ import annotations

import asyncio
import json
import shutil
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import Body, FastAPI, File, HTTPException, Query, Request, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, Response, StreamingResponse
from fastapi.staticfiles import StaticFiles

from . import db, orchestrator, skills as skills_mod, telegram_bot
from .tools import ALL_TOOL_NAMES
from .config import (
    FRONTEND_DIR, SAMPLES_DIR, UPLOAD_DIR, set_runtime, settings,
)
from .providers import check_ready, provider_label
from .tools import files as files_tool
from .tools import notify, office

app = FastAPI(title="Autonomous Task Desk", version="1.0")

MAX_UPLOAD_BYTES = 25 * 1024 * 1024

# Set on shutdown so open SSE streams end instead of blocking the exit.
_shutting_down = asyncio.Event()


@app.on_event("startup")
def _startup() -> None:
    db.init_db()
    try:
        skills_mod.discover(reindex=False)
    except Exception as exc:
        db.log_event(None, None, "system", "warn", f"Skill discovery failed: {exc}")
    sample = SAMPLES_DIR / "sample_tasks.xlsx"
    if not sample.exists():
        office.write_task_template(sample)
    if settings.telegram_polling and settings.telegram_token:
        telegram_bot.start()


@app.on_event("shutdown")
def _shutdown() -> None:
    """Release open SSE streams so the process can actually exit."""
    _shutting_down.set()
    telegram_bot.stop()


# ------------------------------------------------------------------- UI ----

if FRONTEND_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(FRONTEND_DIR)), name="static")


@app.get("/", response_class=HTMLResponse)
def index() -> HTMLResponse:
    page = FRONTEND_DIR / "index.html"
    if not page.exists():
        return HTMLResponse("<h1>Frontend not found</h1>", status_code=500)
    return HTMLResponse(page.read_text(encoding="utf-8"))


# ---------------------------------------------------------------- state ----

@app.get("/api/state")
def get_state() -> Dict[str, Any]:
    ready, reason = check_ready()
    run_id = orchestrator.active_run()
    return {
        "settings": settings.public(),
        "provider": provider_label(),
        "provider_ready": ready,
        "provider_reason": reason,
        "busy": orchestrator.is_busy(),
        "active_run": run_id,
        "stats": db.stats(),
        "telegram": telegram_bot.status(),
        "last_event_id": db.last_event_id(),
        "tool_names": ALL_TOOL_NAMES,
    }


@app.post("/api/settings")
def post_settings(payload: Dict[str, Any] = Body(...)) -> Dict[str, Any]:
    set_runtime(payload)
    ready, reason = check_ready()
    return {"ok": True, "settings": settings.public(),
            "provider": provider_label(), "provider_ready": ready, "provider_reason": reason}


@app.post("/api/settings/test/{channel}")
def test_channel(channel: str) -> Dict[str, Any]:
    if channel == "smtp":
        ok, detail = notify.smtp_test()
    elif channel == "telegram":
        ok, detail = notify.telegram_test()
    elif channel == "provider":
        ok, detail = _provider_ping()
    else:
        raise HTTPException(400, f"Unknown test channel {channel!r}")
    return {"ok": ok, "detail": detail}


def _provider_ping() -> tuple[bool, str]:
    """One tiny completion, to prove the credentials and endpoint work."""
    ready, reason = check_ready()
    if not ready:
        return False, reason
    try:
        from langchain_core.messages import HumanMessage

        from .providers import get_chat_model

        reply = get_chat_model(temperature=0).invoke(
            [HumanMessage(content="Reply with the single word: ready")]
        )
        text = reply.content if isinstance(reply.content, str) else str(reply.content)
        return True, f"{provider_label()} responded: {text.strip()[:60]}"
    except Exception as exc:
        return False, str(exc)[:400]


# ---------------------------------------------------------------- tasks ----

@app.get("/api/tasks/sample")
def download_sample() -> FileResponse:
    path = SAMPLES_DIR / "sample_tasks.xlsx"
    if not path.exists():
        office.write_task_template(path)
    return FileResponse(
        path, filename="sample_tasks.xlsx",
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )


@app.post("/api/tasks/upload")
async def upload_tasks(file: UploadFile = File(...)) -> Dict[str, Any]:
    if not (file.filename or "").lower().endswith((".xlsx", ".xlsm")):
        raise HTTPException(400, "Upload an .xlsx task sheet. Start from the sample if unsure.")

    dest = UPLOAD_DIR / Path(file.filename).name
    await _save_upload(file, dest)

    try:
        result = orchestrator.ingest_sheet(str(dest), Path(file.filename).stem)
    except Exception as exc:
        raise HTTPException(400, str(exc)) from exc

    result["tasks_detail"] = db.list_tasks(result["run_id"])
    return result


async def _save_upload(file: UploadFile, dest: Path) -> None:
    size = 0
    with dest.open("wb") as out:
        while chunk := await file.read(1024 * 1024):
            size += len(chunk)
            if size > MAX_UPLOAD_BYTES:
                out.close()
                dest.unlink(missing_ok=True)
                raise HTTPException(413, "File is larger than 25 MB.")
            out.write(chunk)


# ----------------------------------------------------------------- runs ----

@app.get("/api/runs")
def list_runs() -> Dict[str, Any]:
    return {"runs": db.list_runs(30), "active": orchestrator.active_run()}


@app.get("/api/runs/{run_id}")
def get_run(run_id: int) -> Dict[str, Any]:
    run = db.get_run(run_id)
    if not run:
        raise HTTPException(404, "No such run")
    tasks = db.list_tasks(run_id)
    for task in tasks:
        task["plan"] = _loads(task.get("plan_json"))
        task["review"] = _loads(task.get("review_json"))
        task["artifacts"] = _loads(task.get("artifacts_json")) or []
        task["skills"] = _loads(task.get("skills_used")) or []
        task["guardrails"] = _loads(task.get("guardrails_json")) or {}
    return {"run": run, "tasks": tasks, "files": files_tool.list_files(run_id)}


@app.post("/api/runs/{run_id}/start")
def start_run(run_id: int) -> Dict[str, Any]:
    if not db.get_run(run_id):
        raise HTTPException(404, "No such run")
    ready, reason = check_ready()
    if not ready:
        raise HTTPException(400, reason)
    if not orchestrator.start(run_id):
        raise HTTPException(409, "Another run is already executing.")
    return {"ok": True, "run_id": run_id}


@app.post("/api/runs/cancel")
def cancel_run() -> Dict[str, Any]:
    return {"ok": orchestrator.cancel()}


@app.get("/api/runs/{run_id}/files/{name}")
def download_artifact(run_id: int, name: str) -> FileResponse:
    try:
        path = files_tool.safe_path(name, run_id)
    except files_tool.UnsafePath as exc:
        raise HTTPException(400, str(exc)) from exc
    if not path.exists():
        raise HTTPException(404, "No such file")
    return FileResponse(path, filename=path.name)


# --------------------------------------------------------------- events ----

@app.get("/api/events")
async def events(request: Request, after: int = Query(0),
                 run_id: Optional[int] = Query(None)) -> StreamingResponse:
    """
    Server-sent events.

    Polls the events table rather than holding an in-process queue, so a page
    reload can resume from any event id and nothing is lost between refreshes.

    The loop must be able to end. It exits when the browser disconnects and
    when the process is shutting down; without both checks uvicorn waits
    forever for the generator on SIGTERM, the port is never released, and the
    next start silently leaves an orphan behind holding it.
    """
    async def stream():
        cursor = after
        idle = 0
        while not _shutting_down.is_set():
            if await request.is_disconnected():
                break

            rows = await asyncio.to_thread(db.events_after, cursor, run_id, 200)
            if rows:
                idle = 0
                for row in rows:
                    cursor = row["id"]
                    row["data"] = _loads(row.pop("data_json", None))
                    yield f"id: {cursor}\ndata: {json.dumps(row, default=str)}\n\n"
            else:
                idle += 1
                if idle % 15 == 0:
                    yield ": keepalive\n\n"
            await asyncio.sleep(0.7)

    return StreamingResponse(
        stream(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no",
                 "Connection": "keep-alive"},
    )


# ----------------------------------------------------------- guardrails ----

@app.post("/api/guardrails/test")
def guardrails_test(payload: Dict[str, Any] = Body(...)) -> Dict[str, Any]:
    """
    Screen arbitrary text through the deterministic guardrails.

    Deliberately synchronous and model-free so the panel responds instantly and
    costs nothing. It exercises the exact scanners the graph nodes use, which
    makes it a truthful demonstration rather than a mock.
    """
    from . import guardrails as gr

    text = str(payload.get("text", ""))[:20000]
    stage = str(payload.get("stage", "input"))
    untrusted = bool(payload.get("untrusted", False))

    report = gr.screen(
        text, stage,
        redact_pii=settings.guard_redact_pii,
        block_toxicity=settings.guard_block_on_toxicity,
        untrusted=untrusted,
        live_secrets=[settings.openai_api_key, settings.udal_pat,
                      settings.smtp_password, settings.telegram_token],
    )
    return {"report": report.to_dict(), "cleaned": report.text}


@app.get("/api/guardrails")
def guardrails_config() -> Dict[str, Any]:
    """The active guardrail configuration, for the Settings panel."""
    return {
        "enabled": settings.guardrails_enabled,
        "stages": {
            "input": settings.guard_input,
            "tools": settings.guard_tools,
            "output": settings.guard_output,
        },
        "llm_check": settings.guard_llm_check,
        "redact_pii": settings.guard_redact_pii,
        "block_on_toxicity": settings.guard_block_on_toxicity,
        "checks": [
            {"name": "pii", "does": "Emails, phones, SSNs, card numbers, IPs, IBANs, passports"},
            {"name": "toxicity", "does": "Threats, harassment, demeaning language, profanity"},
            {"name": "injection", "does": "Instruction-override attempts in untrusted content"},
            {"name": "secrets", "does": "API keys, tokens, private keys, this app's own credentials"},
            {"name": "overclaim", "does": "Guaranteed jobs, certifications, ROI and other promises"},
            {"name": "semantic", "does": "LLM review for what pattern matching cannot see"},
        ],
    }


# ------------------------------------------------------------ documents ----

@app.get("/api/documents")
def list_documents() -> Dict[str, Any]:
    from .vectorstore import document_count

    try:
        chunks = document_count()
    except Exception:
        chunks = 0
    return {"documents": db.list_documents(), "chunks": chunks}


@app.post("/api/documents")
async def add_document(file: UploadFile = File(...)) -> Dict[str, Any]:
    dest = UPLOAD_DIR / Path(file.filename or "document").name
    await _save_upload(file, dest)

    text = files_tool.read_upload(dest)
    if text.startswith("[") and len(text) < 200:
        raise HTTPException(400, text.strip("[]"))

    try:
        from .vectorstore import add_document as index_document

        chunks = await asyncio.to_thread(index_document, dest.name, text)
    except Exception as exc:
        raise HTTPException(500, f"Indexing failed: {exc}") from exc

    db.add_document(dest.name, chunks)
    db.log_event(None, None, "system", "info", f"Indexed {dest.name} into {chunks} chunks")
    return {"ok": True, "filename": dest.name, "chunks": chunks}


@app.delete("/api/documents/{filename}")
def delete_document(filename: str) -> Dict[str, Any]:
    from .vectorstore import delete_document as drop

    try:
        drop(Path(filename).name)
    except Exception as exc:
        raise HTTPException(500, str(exc)) from exc
    return {"ok": True}


# --------------------------------------------------------------- skills ----

@app.get("/api/skills")
def list_skills() -> Dict[str, Any]:
    rows = db.list_skills()
    for row in rows:
        row["keywords"] = _loads(row.get("keywords")) or []
        row["tools"] = _loads(row.get("tools")) or []
    return {"skills": rows, "allow_code": settings.allow_skill_code}


@app.post("/api/skills/rescan")
def rescan_skills() -> Dict[str, Any]:
    found = skills_mod.discover(reindex=True)
    return {"ok": True, "count": len(found)}


@app.post("/api/skills/upload")
async def upload_skill(file: UploadFile = File(...)) -> Dict[str, Any]:
    if not (file.filename or "").lower().endswith(".zip"):
        raise HTTPException(400, "Upload a .zip containing skill.yaml and SKILL.md")
    data = await file.read()
    try:
        meta = skills_mod.install_zip(data, source=f"upload:{file.filename}")
    except skills_mod.SkillError as exc:
        raise HTTPException(400, str(exc)) from exc
    return {"ok": True, "skill": meta}


@app.post("/api/skills/install-url")
def install_skill_url(payload: Dict[str, str] = Body(...)) -> Dict[str, Any]:
    url = (payload.get("url") or "").strip()
    try:
        meta = skills_mod.install_from_url(url)
    except skills_mod.SkillError as exc:
        raise HTTPException(400, str(exc)) from exc
    return {"ok": True, "skill": meta}


@app.get("/api/skills/registry")
def skill_registry(url: str = Query("")) -> Dict[str, Any]:
    try:
        return {"skills": skills_mod.registry(url)}
    except skills_mod.SkillError as exc:
        raise HTTPException(400, str(exc)) from exc


@app.get("/api/skills/{name}/download")
def download_skill(name: str) -> Response:
    try:
        filename, blob = skills_mod.export_zip(name)
    except skills_mod.SkillError as exc:
        raise HTTPException(404, str(exc)) from exc
    return Response(
        blob, media_type="application/zip",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@app.post("/api/skills/{name}/toggle")
def toggle_skill(name: str, payload: Dict[str, Any] = Body(default={})) -> Dict[str, Any]:
    db.set_skill_enabled(name, bool(payload.get("enabled", True)))
    return {"ok": True}


@app.delete("/api/skills/{name}")
def remove_skill(name: str) -> Dict[str, Any]:
    skills_mod.remove(name)
    return {"ok": True}


# ------------------------------------------------------------- telegram ----

@app.post("/api/telegram/start")
def telegram_start() -> Dict[str, Any]:
    return telegram_bot.start()


@app.post("/api/telegram/stop")
def telegram_stop() -> Dict[str, Any]:
    return telegram_bot.stop()


@app.get("/api/deliveries")
def deliveries() -> Dict[str, Any]:
    return {"deliveries": db.list_deliveries(30)}


# --------------------------------------------------------------- helpers ---

def _loads(raw: Any) -> Any:
    if not raw:
        return None
    try:
        return json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        return None
