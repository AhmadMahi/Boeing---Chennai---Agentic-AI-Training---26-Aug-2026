"""
LangGraph task graph.

    guard_input -> plan -> research -> analyze -> write -> review
         |                                    ^            |
         |                                    +-- revise --+
         |                                                 v
         +-------------> halt <-------------------- guard_output
                          |                              |
                         END                          deliver -> END

Nodes are thin: each delegates to its agent module and returns a partial state
update. The conditional edges are the only control flow, which keeps the graph
readable while still allowing a review-driven rewrite loop.

Guardrails are graph nodes, not helper calls, so screening is part of the
execution path rather than something a future edit can forget to invoke. Input
screening happens before any model call is spent, and output screening happens
on the exact text that will be emailed and attached.

Research and analysis are not skipped by edges but by the agents themselves,
so the plan's needs_research / needs_analysis flags stay visible in the trace
rather than silently rerouting the graph.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, TypedDict

from langgraph.graph import END, START, StateGraph

from . import db, tools as tool_registry
from .agents import analyst, guardian, planner, researcher, reviewer, writer
from .agents.base import emit
from .config import settings
from .tools import notify


class TaskState(TypedDict, total=False):
    """State passed between graph nodes for a single task."""
    run_id: int
    task_id: int
    task: Dict[str, Any]
    skills: List[Dict[str, Any]]
    tools_allowed: List[str]
    dependency_context: str

    plan: Dict[str, Any]
    findings: str
    analysis: str
    draft: str
    review: Dict[str, Any]

    artifacts: List[str]
    attempts: int
    tokens: int
    delivery: List[str]

    guard_input: Dict[str, Any]
    guard_output: Dict[str, Any]
    guard_blocked: bool


# ------------------------------------------------------------------ nodes --

def guard_input_node(state: TaskState) -> Dict[str, Any]:
    """Screen the task instruction before the Planner, and before any spend."""
    update = guardian.check_input(state)
    _save_guardrails(state, input_report=update.get("guard_input"))
    return update


def guard_output_node(state: TaskState) -> Dict[str, Any]:
    """Screen the deliverable on its way out, including the files on disk."""
    update = guardian.check_output(state)
    _save_guardrails(state, output_report=update.get("guard_output"))
    if update.get("draft"):
        db.update_task(state["task_id"], result_md=update["draft"])
    return update


def halt_node(state: TaskState) -> Dict[str, Any]:
    """
    Terminal node for content a guardrail blocked.

    The work stays on disk for a human to inspect. Nothing is emailed or
    posted, and the reason is recorded on the task rather than buried in the
    trace, because a blocked task must be explainable after the fact.
    """
    stage = "input" if (state.get("guard_input") or {}).get("verdict") == "BLOCK" else "output"
    report = state.get(f"guard_{stage}") or {}
    reasons = [c["detail"] for c in report.get("checks", []) if c.get("verdict") == "BLOCK"]
    reason = " ".join(reasons) or "Blocked by a guardrail."

    emit(state, "guardian", "guard_block", f"Task halted at the {stage} guardrail. {reason}")
    db.update_task(
        state["task_id"], status="blocked", error=f"Guardrail block ({stage}): {reason}"[:2000],
        finished_at=db.now(), tokens=int(state.get("tokens", 0)),
    )
    db.log_delivery(state.get("run_id"), state.get("task_id"), "none", "-", "skipped",
                    f"Delivery withheld: guardrail block at {stage}.")
    return {}


def plan_node(state: TaskState) -> Dict[str, Any]:
    update = planner.run(state)
    db.update_task(state["task_id"], plan_json=_json(update["plan"]), status="running")
    return update


def research_node(state: TaskState) -> Dict[str, Any]:
    update = researcher.run(state)
    if update.get("findings"):
        db.update_task(state["task_id"], findings_md=update["findings"])
    return update


def analyze_node(state: TaskState) -> Dict[str, Any]:
    return analyst.run(state)


def write_node(state: TaskState) -> Dict[str, Any]:
    update = writer.run(state)
    update["artifacts"] = tool_registry.artifacts()
    db.update_task(
        state["task_id"],
        result_md=update.get("draft", ""),
        artifacts_json=_json(update["artifacts"]),
    )
    return update


def review_node(state: TaskState) -> Dict[str, Any]:
    update = reviewer.run(state)
    db.update_task(state["task_id"], review_json=_json(update["review"]))
    return update


def deliver_node(state: TaskState) -> Dict[str, Any]:
    """
    Send the completion notice.

    Delivery is a graph node rather than an agent tool on purpose: an agent
    should never be able to decide, mid-reasoning, to email someone. Failures
    are recorded and never fail the task, because the work is already done.
    """
    task = state.get("task", {})
    review = state.get("review", {})
    artifacts = state.get("artifacts", [])
    results: List[str] = []

    subject = f"Task complete: {task.get('task_key', '')} {task.get('title', '')}".strip()[:180]
    body = _delivery_body(state)

    recipient = (task.get("notify_email") or settings.notify_email or "").strip()
    if recipient:
        ok, detail = notify.send_email(recipient, subject, body, artifacts)
        db.log_delivery(state.get("run_id"), state.get("task_id"), "email", recipient,
                        "sent" if ok else "failed", detail)
        emit(state, "delivery", "email" if ok else "warn", f"Email: {detail}")
        results.append(f"email:{'sent' if ok else 'failed'}")
    else:
        emit(state, "delivery", "skip", "No email recipient configured for this task.")

    chat_id = (task.get("notify_telegram") or settings.telegram_chat_id or "").strip()
    if chat_id and settings.telegram_token:
        ok, detail = notify.send_telegram(f"{subject}\n\n{body}", chat_id)
        db.log_delivery(state.get("run_id"), state.get("task_id"), "telegram", chat_id,
                        "sent" if ok else "failed", detail)
        emit(state, "delivery", "telegram" if ok else "warn", f"Telegram: {detail}")
        results.append(f"telegram:{'sent' if ok else 'failed'}")

        for path in artifacts[:3]:
            notify.send_telegram_document(path, task.get("title", ""), chat_id)
    else:
        emit(state, "delivery", "skip", "Telegram not configured for this task.")

    status = "done" if review.get("passed", True) else "done_with_issues"
    db.update_task(state["task_id"], status=status, finished_at=db.now(),
                   tokens=int(state.get("tokens", 0)))
    emit(state, "delivery", "done", f"Task finished as {status}")
    return {"delivery": results}


# ------------------------------------------------------------ conditionals --

def after_input_guard(state: TaskState) -> str:
    return "halt" if state.get("guard_blocked") else "plan"


def after_output_guard(state: TaskState) -> str:
    return "halt" if state.get("guard_blocked") else "deliver"


def after_review(state: TaskState) -> str:
    """Send the draft back to the writer once when the review fails."""
    review = state.get("review", {})
    attempts = int(state.get("attempts", 0))
    if not review.get("passed", True) and attempts <= settings.max_review_retries:
        emit(state, "graph", "retry",
             f"Review failed, revision {attempts} of {settings.max_review_retries}")
        return "revise"
    return "deliver"


# -------------------------------------------------------------- assembly ---

_compiled = None


def build_graph():
    """Compile the task graph. Cached, because compilation is not free."""
    global _compiled
    if _compiled is not None:
        return _compiled

    graph = StateGraph(TaskState)
    graph.add_node("guard_input", guard_input_node)
    graph.add_node("guard_output", guard_output_node)
    graph.add_node("halt", halt_node)
    graph.add_node("plan", plan_node)
    graph.add_node("research", research_node)
    graph.add_node("analyze", analyze_node)
    graph.add_node("write", write_node)
    graph.add_node("review", review_node)
    graph.add_node("deliver", deliver_node)

    graph.add_edge(START, "guard_input")
    graph.add_conditional_edges("guard_input", after_input_guard,
                                {"halt": "halt", "plan": "plan"})
    graph.add_edge("plan", "research")
    graph.add_edge("research", "analyze")
    graph.add_edge("analyze", "write")
    graph.add_edge("write", "review")
    graph.add_conditional_edges("review", after_review,
                                {"revise": "write", "deliver": "guard_output"})
    graph.add_conditional_edges("guard_output", after_output_guard,
                                {"halt": "halt", "deliver": "deliver"})
    graph.add_edge("deliver", END)
    graph.add_edge("halt", END)

    _compiled = graph.compile()
    return _compiled


def _delivery_body(state: TaskState) -> str:
    """Plain-text completion notice used for both email and Telegram."""
    task = state.get("task", {})
    review = state.get("review", {})
    plan = state.get("plan", {})
    artifacts = state.get("artifacts", [])

    lines = [
        f"Task {task.get('task_key', '')}: {task.get('title', '')}",
        "",
        f"Objective: {plan.get('objective', '')}",
        f"Review: {'passed' if review.get('passed') else 'completed with issues'}"
        f" (score {review.get('score', '?')}/10)",
        "",
        review.get("summary", "") or "",
    ]
    if review.get("problems"):
        lines += ["", "Open issues:"] + [f"- {p}" for p in review["problems"][:5]]
    if artifacts:
        lines += ["", "Attached files:"] + [f"- {a.split('/')[-1]}" for a in artifacts]

    summary = (state.get("draft") or "").strip()
    if summary:
        lines += ["", "Summary of the deliverable:", summary[:1500]]

    lines += ["", "Sent automatically by the Autonomous Task Desk."]
    return "\n".join(lines)


def _save_guardrails(state: TaskState, input_report: Any = None,
                     output_report: Any = None) -> None:
    """Merge one stage's report into the task's stored guardrail record."""
    import json

    existing = {}
    row = db.get_task(state["task_id"])
    if row and row.get("guardrails_json"):
        try:
            existing = json.loads(row["guardrails_json"])
        except (json.JSONDecodeError, TypeError):
            existing = {}

    if input_report:
        existing["input"] = input_report
    if output_report:
        existing["output"] = output_report
    db.update_task(state["task_id"], guardrails_json=json.dumps(existing, default=str))


def _json(value: Any) -> str:
    import json

    return json.dumps(value, default=str)
