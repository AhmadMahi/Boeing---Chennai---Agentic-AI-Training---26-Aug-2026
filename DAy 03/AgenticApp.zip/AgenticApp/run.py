"""
Launcher.

    python run.py                 start on http://127.0.0.1:8100
    python run.py --port 9000     pick a port
    python run.py --sample        regenerate samples/sample_tasks.xlsx and exit

Reload is off by default because the orchestrator runs work in a background
thread; a reload mid-run would abandon it.
"""

from __future__ import annotations

import argparse
import webbrowser
from threading import Timer

import uvicorn


def main() -> None:
    parser = argparse.ArgumentParser(description="Autonomous Task Desk")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8100)
    parser.add_argument("--reload", action="store_true", help="Dev auto-reload.")
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--sample", action="store_true",
                        help="Regenerate the sample task sheet and exit.")
    args = parser.parse_args()

    if args.sample:
        from app.config import SAMPLES_DIR
        from app.tools.office import write_task_template

        print("Wrote", write_task_template(SAMPLES_DIR / "sample_tasks.xlsx"))
        return

    url = f"http://{args.host}:{args.port}"
    print(f"Autonomous Task Desk on {url}")
    if not args.no_browser:
        Timer(1.5, lambda: webbrowser.open(url)).start()

    uvicorn.run("app.main:app", host=args.host, port=args.port,
                reload=args.reload, log_level="info")


if __name__ == "__main__":
    main()
