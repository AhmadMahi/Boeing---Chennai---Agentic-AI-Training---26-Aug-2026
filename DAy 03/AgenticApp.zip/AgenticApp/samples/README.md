# Sample task sheet

`sample_tasks.xlsx` is a working example you can upload as is. It has two
sheets:

- **Tasks** four example rows covering research, document analysis, a
  dependent comparison task, and a training roadmap.
- **How to fill this in** every column documented, with which are required.

Regenerate it at any time:

```bash
./.venv/bin/python run.py --sample
```

## The four examples

| Row | Demonstrates |
|---|---|
| T001 | Web research with an explicit skill and tool list, PDF output |
| T002 | Internal document retrieval through `rag_search`, Markdown output |
| T003 | `depends_on: T001`, so it receives T001's output as context |
| T004 | Longer-form design task with `output_format: all` |

## Minimum viable sheet

Only two columns are actually required:

| title | description |
|---|---|
| Competitor scan | Find the five most visible vendors in X and compare them. Cite sources. |

Everything else has a sensible default: priority `medium`, output `pdf`, skill
chosen automatically by semantic match, tools taken from that skill.

## Writing good descriptions

The Planner reads the `description` column and nothing else about intent, so
put the specifics there.

- Say what "done" looks like. "Compare on price, labs and enterprise
  readiness" beats "look into vendors".
- Name the shape you want: a table, a roadmap, a one page brief.
- Say if you want sources cited. The research skills do it by default, but
  saying it makes the Reviewer check for it.
- Keep one deliverable per row. Split multi-part work across rows and wire
  them together with `depends_on`.
