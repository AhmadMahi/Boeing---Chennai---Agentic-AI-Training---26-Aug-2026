"""Generate the three-page Autonomous Task Desk overview PDF."""

from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.pdfgen.canvas import Canvas
from reportlab.platypus import (
    Flowable, KeepTogether, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle,
)

# ----------------------------------------------------------------- palette --
NAVY   = colors.HexColor("#17304F")
INK    = colors.HexColor("#1B2735")
SLATE  = colors.HexColor("#5A6B7F")
MUTED  = colors.HexColor("#8496A8")
ACCENT = colors.HexColor("#1F6FEB")
GREEN  = colors.HexColor("#0F7B4F")
AMBER  = colors.HexColor("#B57500")
RED    = colors.HexColor("#B3261E")
LINE   = colors.HexColor("#C9D6E4")
TINT   = colors.HexColor("#EEF3F9")
TINT2  = colors.HexColor("#F7FAFD")
WHITE  = colors.white

PAGE_W, PAGE_H = A4
MARGIN = 15 * mm
CONTENT_W = PAGE_W - 2 * MARGIN

base = getSampleStyleSheet()
S = {
    "h1": ParagraphStyle("h1", parent=base["Normal"], fontName="Helvetica-Bold",
                         fontSize=14, leading=17, textColor=NAVY, spaceBefore=2, spaceAfter=5),
    "h2": ParagraphStyle("h2", parent=base["Normal"], fontName="Helvetica-Bold",
                         fontSize=10, leading=13, textColor=ACCENT, spaceBefore=9, spaceAfter=3),
    "body": ParagraphStyle("body", parent=base["Normal"], fontName="Helvetica",
                           fontSize=8.4, leading=11.6, textColor=INK, alignment=TA_LEFT,
                           spaceAfter=4),
    "small": ParagraphStyle("small", parent=base["Normal"], fontName="Helvetica",
                            fontSize=7.4, leading=10, textColor=SLATE),
    "cap": ParagraphStyle("cap", parent=base["Normal"], fontName="Helvetica-Oblique",
                          fontSize=7, leading=9.5, textColor=MUTED, spaceBefore=3),
    "th": ParagraphStyle("th", parent=base["Normal"], fontName="Helvetica-Bold",
                         fontSize=7.6, leading=10, textColor=WHITE),
    "td": ParagraphStyle("td", parent=base["Normal"], fontName="Helvetica",
                         fontSize=7.6, leading=10.2, textColor=INK),
    "tdb": ParagraphStyle("tdb", parent=base["Normal"], fontName="Helvetica-Bold",
                          fontSize=7.6, leading=10.2, textColor=NAVY),
    "mono": ParagraphStyle("mono", parent=base["Normal"], fontName="Courier",
                           fontSize=7.2, leading=9.6, textColor=NAVY),
}


def P(text, style="body"):
    return Paragraph(text, S[style])


# =============================================================== diagrams ====

def _rounded(c, x, y, w, h, fill, stroke, radius=4, lw=0.9):
    c.setFillColor(fill)
    c.setStrokeColor(stroke)
    c.setLineWidth(lw)
    c.roundRect(x, y, w, h, radius, stroke=1, fill=1)


def _label(c, x, y, w, h, top, bottom, top_color=WHITE, bottom_color=None, top_size=7.8):
    c.setFillColor(top_color)
    c.setFont("Helvetica-Bold", top_size)
    c.drawCentredString(x + w / 2, y + h - (11 if bottom else h / 2 + 3), top)
    if bottom:
        c.setFillColor(bottom_color or colors.HexColor("#BBD0E8"))
        c.setFont("Helvetica", 6.1)
        c.drawCentredString(x + w / 2, y + 7, bottom)


def _arrow(c, points, color=SLATE, lw=1.0, head=4.2, dashed=False):
    """Draw an orthogonal polyline with an arrowhead on the final segment."""
    c.setStrokeColor(color)
    c.setLineWidth(lw)
    c.setDash(2, 2) if dashed else c.setDash()
    path = c.beginPath()
    path.moveTo(*points[0])
    for pt in points[1:]:
        path.lineTo(*pt)
    c.drawPath(path)
    c.setDash()

    (x1, y1), (x2, y2) = points[-2], points[-1]
    c.setFillColor(color)
    if abs(x2 - x1) > abs(y2 - y1):          # horizontal
        d = head if x2 > x1 else -head
        p = c.beginPath()
        p.moveTo(x2, y2); p.lineTo(x2 - d, y2 + head * 0.62); p.lineTo(x2 - d, y2 - head * 0.62)
    else:                                     # vertical
        d = head if y2 > y1 else -head
        p = c.beginPath()
        p.moveTo(x2, y2); p.lineTo(x2 + head * 0.62, y2 - d); p.lineTo(x2 - head * 0.62, y2 - d)
    p.close()
    c.drawPath(p, stroke=0, fill=1)


def _tag(c, x, y, text, color=MUTED, size=5.9, bg=None):
    c.setFont("Helvetica-Bold", size)
    if bg:
        w = c.stringWidth(text, "Helvetica-Bold", size) + 7
        c.setFillColor(bg)
        c.roundRect(x - w / 2, y - 2.4, w, size + 4, 2, stroke=0, fill=1)
    c.setFillColor(color)
    c.drawCentredString(x, y, text)


class WorkflowDiagram(Flowable):
    """The LangGraph execution path for one task, including both guard nodes."""

    W, H = CONTENT_W, 208

    def wrap(self, *_):
        return self.W, self.H

    def draw(self):
        c = self.canv
        gut, bw, bh = 30, 112, 36
        xs = [gut, gut + 127, gut + 254, gut + 381]
        r1, r2 = 158, 92                      # row bottoms
        halt_x, halt_y, halt_w, halt_h = 196, 10, 126, 30

        row1 = [("guard_input", "screen instruction", GREEN),
                ("plan", "Planner", NAVY),
                ("research", "Researcher", NAVY),
                ("analyze", "Analyst", NAVY)]
        row2 = [("write", "Writer", NAVY),
                ("review", "Reviewer", NAVY),
                ("guard_output", "screen deliverable", GREEN),
                ("deliver", "email + Telegram", ACCENT)]

        for x, (top, sub, col) in zip(xs, row1):
            _rounded(c, x, r1, bw, bh, col, col)
            _label(c, x, r1, bw, bh, top, sub)
        for x, (top, sub, col) in zip(xs, row2):
            _rounded(c, x, r2, bw, bh, col, col)
            _label(c, x, r2, bw, bh, top, sub)

        _rounded(c, halt_x, halt_y, halt_w, halt_h, colors.HexColor("#FBEBEA"), RED)
        c.setFillColor(RED)
        c.setFont("Helvetica-Bold", 7.8)
        c.drawCentredString(halt_x + halt_w / 2, halt_y + 17, "halt")
        c.setFont("Helvetica", 6.1)
        c.drawCentredString(halt_x + halt_w / 2, halt_y + 8, "blocked, nothing sent")

        # forward edges within each row
        for i in range(3):
            _arrow(c, [(xs[i] + bw, r1 + bh / 2), (xs[i + 1], r1 + bh / 2)])
            _arrow(c, [(xs[i] + bw, r2 + bh / 2), (xs[i + 1], r2 + bh / 2)])

        # start marker
        _arrow(c, [(gut - 17, r1 + bh / 2), (gut, r1 + bh / 2)], color=ACCENT)
        _tag(c, gut - 22, r1 + bh / 2 + 8, "START", ACCENT)

        # row wrap: analyze -> write
        _arrow(c, [(xs[3] + bw / 2, r1), (xs[3] + bw / 2, 142),
                   (xs[0] + bw / 2, 142), (xs[0] + bw / 2, r2 + bh)])

        # revise loop: review -> write
        _arrow(c, [(xs[1] + bw / 2, r2), (xs[1] + bw / 2, 72),
                   (xs[0] + bw / 2, 72), (xs[0] + bw / 2, r2)], color=AMBER)
        _tag(c, (xs[0] + xs[1]) / 2 + bw / 2, 65, "revise once if review fails", AMBER)

        # blocked branches into halt
        _arrow(c, [(gut, r1 + bh / 2), (12, r1 + bh / 2), (12, 25), (halt_x, 25)],
               color=RED, dashed=True)
        _arrow(c, [(xs[2] + bw / 2, r2), (xs[2] + bw / 2, 25), (halt_x + halt_w, 25)],
               color=RED, dashed=True)

        # end marker
        _arrow(c, [(xs[3] + bw / 2, r2), (xs[3] + bw / 2, 30)], color=ACCENT)
        _tag(c, xs[3] + bw / 2, 21, "END", ACCENT)

        c.setFillColor(MUTED)
        c.setFont("Helvetica-Oblique", 6.2)
        c.drawString(0, 200, "Every node is a LangGraph node. Guardrails sit on the execution "
                             "path, not beside it.")


class ArchitectureDiagram(Flowable):
    """Layered runtime view, top to bottom."""

    BANDS, BAND_H, GAP = 10, 26, 4.5
    W = CONTENT_W
    H = BANDS * BAND_H + (BANDS - 1) * GAP      # keep in step with draw()

    def wrap(self, *_):
        return self.W, self.H

    def draw(self):
        c = self.canv
        band_h, gap = self.BAND_H, self.GAP
        y = self.H - band_h

        def band(label, cells, accent, sub_h=band_h):
            nonlocal y
            c.setFillColor(SLATE)
            c.setFont("Helvetica-Bold", 6.2)
            c.drawRightString(56, y + sub_h / 2 - 2, label.upper())

            x0, avail = 64, self.W - 64
            n = len(cells)
            cw = (avail - (n - 1) * 5) / n
            for i, text in enumerate(cells):
                x = x0 + i * (cw + 5)
                _rounded(c, x, y, cw, sub_h, TINT2 if accent is not NAVY else NAVY,
                         accent, radius=3, lw=0.8)
                c.setFillColor(WHITE if accent is NAVY else INK)
                c.setFont("Helvetica-Bold", 6.9)
                lines = text.split("|")
                if len(lines) == 1:
                    c.drawCentredString(x + cw / 2, y + sub_h / 2 - 2.4, lines[0])
                else:
                    c.drawCentredString(x + cw / 2, y + sub_h - 10, lines[0])
                    c.setFillColor(colors.HexColor("#BBD0E8") if accent is NAVY else SLATE)
                    c.setFont("Helvetica", 5.9)
                    c.drawCentredString(x + cw / 2, y + 6, lines[1])
            y -= sub_h + gap

        band("interface", ["Single page UI|HTML, CSS, JS with live SSE trace"], ACCENT)
        band("api", ["FastAPI + uvicorn|routes, uploads, SSE stream, settings, skill registry"], ACCENT)
        band("control", ["Orchestrator|ordering, dependencies, run report",
                         "Telegram worker|long polling, no public URL"], ACCENT)
        band("graph", ["LangGraph StateGraph|guard_input to plan to research to analyze to write to review to guard_output to deliver"], NAVY)
        band("agents", ["Guardian", "Planner", "Researcher", "Analyst", "Writer", "Reviewer"], NAVY)
        band("tools", ["web_search", "web_fetch", "rag_search", "write_file",
                       "read_file", "write_xlsx", "write_pdf"], ACCENT)
        band("guardrails", ["pii", "toxicity", "injection", "secrets", "overclaim", "semantic"], GREEN)
        band("providers", ["OpenAI|gpt-4o-mini + text-embedding-3-small",
                           "BCAI|gpt-4.1-mini + text-embedding-3-small"], ACCENT)
        band("storage", ["SQLite|runs, tasks, events, deliveries",
                         "ChromaDB|documents + skills vectors",
                         "Workspace|data/outputs/run_id"], ACCENT)
        band("delivery", ["Resend SMTP|per task and per run, with attachments",
                          "Telegram Bot API|messages, documents, commands"], ACCENT)

        c.setStrokeColor(LINE)
        c.setLineWidth(0.7)
        c.setDash(1.5, 2)
        c.line(60, 2, 60, self.H - 1)
        c.setDash()


# ================================================================= tables ====

def table(rows, widths, header=True, zebra=True, align_left_col=True):
    data = []
    for i, row in enumerate(rows):
        style = "th" if (header and i == 0) else "td"
        cells = []
        for j, cell in enumerate(row):
            st = style
            if style == "td" and align_left_col and j == 0:
                st = "tdb"
            cells.append(Paragraph(cell, S[st]))
        data.append(cells)

    t = Table(data, colWidths=widths, repeatRows=1 if header else 0, hAlign="LEFT")
    cmds = [
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 5),
        ("RIGHTPADDING", (0, 0), (-1, -1), 5),
        ("TOPPADDING", (0, 0), (-1, -1), 3.2),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3.2),
        ("LINEBELOW", (0, 0), (-1, -1), 0.4, LINE),
        ("BOX", (0, 0), (-1, -1), 0.6, LINE),
    ]
    if header:
        cmds += [("BACKGROUND", (0, 0), (-1, 0), NAVY),
                 ("LINEBELOW", (0, 0), (-1, 0), 0.8, NAVY)]
        if zebra:
            cmds.append(("ROWBACKGROUNDS", (0, 1), (-1, -1), [WHITE, TINT2]))
    t.setStyle(TableStyle(cmds))
    return t


def rule(space_before=6, space_after=5):
    from reportlab.platypus import HRFlowable
    return HRFlowable(width="100%", thickness=0.7, color=LINE,
                      spaceBefore=space_before, spaceAfter=space_after)


# ================================================================== chrome ===

def decorate(c: Canvas, doc):
    page = c.getPageNumber()
    c.saveState()

    if page == 1:
        c.setFillColor(NAVY)
        c.rect(0, PAGE_H - 74, PAGE_W, 74, stroke=0, fill=1)
        c.setFillColor(ACCENT)
        c.rect(0, PAGE_H - 77, PAGE_W, 3, stroke=0, fill=1)

        # neutral geometric mark
        c.setFillColor(colors.HexColor("#4E9BFF"))
        c.roundRect(MARGIN, PAGE_H - 56, 26, 26, 6, stroke=0, fill=1)
        c.setFillColor(WHITE)
        c.circle(MARGIN + 9, PAGE_H - 43, 3.4, stroke=0, fill=1)
        c.circle(MARGIN + 18, PAGE_H - 37, 2.4, stroke=0, fill=1)
        c.circle(MARGIN + 18, PAGE_H - 49, 2.4, stroke=0, fill=1)
        c.setStrokeColor(WHITE)
        c.setLineWidth(0.9)
        c.line(MARGIN + 11.8, PAGE_H - 41.5, MARGIN + 16.2, PAGE_H - 38.5)
        c.line(MARGIN + 11.8, PAGE_H - 44.5, MARGIN + 16.2, PAGE_H - 47.5)

        c.setFillColor(WHITE)
        c.setFont("Helvetica-Bold", 17)
        c.drawString(MARGIN + 36, PAGE_H - 40, "Autonomous Task Desk")
        c.setFillColor(colors.HexColor("#9EC1EC"))
        c.setFont("Helvetica", 8.4)
        c.drawString(MARGIN + 36, PAGE_H - 53,
                     "Multi-agent task execution on LangGraph, with guardrails at every boundary")
        c.setFont("Helvetica", 7)
        c.drawRightString(PAGE_W - MARGIN, PAGE_H - 40, "Capability overview")
        c.drawRightString(PAGE_W - MARGIN, PAGE_H - 51, "Version 1.0")
    else:
        c.setFillColor(NAVY)
        c.setFont("Helvetica-Bold", 8.4)
        c.drawString(MARGIN, PAGE_H - 26, "Autonomous Task Desk")
        c.setFillColor(MUTED)
        c.setFont("Helvetica", 7)
        c.drawRightString(PAGE_W - MARGIN, PAGE_H - 26, "Capability overview")
        c.setStrokeColor(LINE)
        c.setLineWidth(0.7)
        c.line(MARGIN, PAGE_H - 31, PAGE_W - MARGIN, PAGE_H - 31)

    c.setStrokeColor(LINE)
    c.setLineWidth(0.7)
    c.line(MARGIN, 26, PAGE_W - MARGIN, 26)
    c.setFillColor(MUTED)
    c.setFont("Helvetica", 6.6)
    c.drawString(MARGIN, 18, "FastAPI + uvicorn | LangGraph | ChromaDB | SQLite | ReportLab")
    c.drawRightString(PAGE_W - MARGIN, 18, f"Page {page} of 3")
    c.restoreState()


# ================================================================== story ====

story = []

# ------------------------------------------------------------------ PAGE 1 --
story.append(Spacer(1, 36))          # clear the page-one banner
story.append(P("What it does", "h1"))
story.append(P(
    "Upload a spreadsheet of tasks. Six agents plan each one, gather evidence, structure it, "
    "write the deliverable, review it against the plan, and deliver the result by email and "
    "Telegram. Work that would take an analyst a day of searching and formatting runs "
    "unattended, and every step is recorded."))

summary = [
    ["Input", "Processing", "Output"],
    ["An .xlsx task sheet, one task per row. Column order is free and unknown columns are "
     "ignored. Two columns are genuinely required: <b>title</b> and <b>description</b>.",
     "Six agents on a LangGraph state machine. Skills are selected semantically per task, "
     "tools are permission-scoped, and dependencies between tasks are resolved automatically.",
     "PDF, Excel and Markdown artifacts per task, plus a run report and summary workbook. "
     "Emailed with attachments and pushed to Telegram."],
]
story.append(Spacer(1, 3))
story.append(table(summary, [CONTENT_W / 3] * 3, align_left_col=False))

story.append(P("Execution workflow", "h1"))
story.append(WorkflowDiagram())
story.append(P(
    "Research and analysis skip themselves when the plan says they are not needed, so a simple "
    "task does not pay for a research pass it never uses. A failed review returns the draft to "
    "the Writer once, with the specific problems attached. A guardrail block halts the task "
    "before delivery and keeps the work on disk for inspection.", "small"))

story.append(P("The six agents", "h1"))
agents = [
    ["Agent", "Responsibility", "Tools it may call"],
    ["Guardian", "Screens the instruction, every tool result, and the finished deliverable",
     "none, by design"],
    ["Planner", "Breaks the row into two to six steps and sets the success criteria", "none"],
    ["Researcher", "Gathers evidence from the open web and the internal corpus",
     "web_search, web_fetch, rag_search"],
    ["Analyst", "Builds comparisons, scored rubrics and ranked tables", "write_xlsx"],
    ["Writer", "Produces the PDF, Excel or Markdown deliverable",
     "write_pdf, write_xlsx, write_file"],
    ["Reviewer", "Checks the draft against the plan, can send it back once", "none"],
]
story.append(table(agents, [62, 258, 173]))

story.append(P("The task sheet", "h1"))
sheet = [
    ["Column", "Meaning", "Column", "Meaning"],
    ["title", "<b>Required.</b> Short task name", "output_format", "pdf, xlsx, md or all"],
    ["description", "<b>Required.</b> The instruction the Planner reads",
     "notify_email", "Per-task recipient"],
    ["priority", "high, medium or low. High runs first", "notify_telegram", "Per-task chat id"],
    ["skill_hint", "Force a skill. Blank means auto discovery",
     "depends_on", "task_id that must finish first"],
    ["tools_allowed", "Restrict the tool list for this row", "due_date", "Reported, not enforced"],
]
w = CONTENT_W / 2
story.append(table(sheet, [66, w - 66, 74, w - 74], align_left_col=False))
story.append(P(
    "Only title and description are required. Everything else defaults: priority medium, output "
    "pdf, skill chosen by semantic match, tools taken from that skill.", "small"))

# ------------------------------------------------------------------ PAGE 2 --
story.append(PageBreak())
story.append(P("System architecture", "h1"))
story.append(ArchitectureDiagram())
story.append(P(
    "Long work never runs inside a request handler. Uploading a sheet only parses it; execution "
    "happens in a background thread while the browser follows the trace over server-sent events. "
    "The trace is written to SQLite rather than held in memory, so a page reload resumes from any "
    "event without losing history.", "small"))

story.append(P("Capabilities", "h1"))
caps = [
    ["Area", "What it can do"],
    ["Task intake",
     "Excel sheets with loose header matching, priority ordering, and <b>depends_on</b> chains. "
     "A dependent task receives the full output of what it depends on. Circular or missing "
     "dependencies cannot deadlock a run."],
    ["Research",
     "DuckDuckGo search with no API key, full page fetch with boilerplate stripped, and semantic "
     "retrieval over an uploaded document corpus in ChromaDB."],
    ["Documents",
     "Styled Excel workbooks via openpyxl and paginated PDF reports via ReportLab, with headings, "
     "bullets, tables and page furniture rendered from the writer's Markdown."],
    ["Skills",
     "A skill is a folder holding skill.yaml and SKILL.md. Five ship built in. Descriptions are "
     "embedded into ChromaDB so the Planner discovers the right one by meaning. Upload a zip, "
     "install from a URL, browse a registry, or export any skill back out."],
    ["Provider switch",
     "OpenAI or Boeing BCAI from one dropdown. Both return real LangChain runnables, so every "
     "agent uses the same bind_tools surface. Both embed with text-embedding-3-small, so one "
     "vector collection stays valid across a switch."],
    ["Delivery",
     "Resend SMTP by default, and any other SMTP provider by changing the host. Telegram uses "
     "long polling, so no public URL, tunnel or certificate is needed. Failures are logged and "
     "never fail the task that produced the work."],
    ["Telegram control",
     "/status, /runs, /report, /skills, /cancel, and /task to launch an ad-hoc task from a chat "
     "message through the same reviewed pipeline."],
    ["Observability",
     "Per-agent live trace, token accounting per task, delivery log, and a run report that "
     "records what each task produced and what the reviewer thought of it."],
]
story.append(table(caps, [74, CONTENT_W - 74]))

story.append(P("Operational behaviour", "h1"))
ops = [
    ["Concurrency", "One run executes at a time in a background thread, so provider rate limits "
                    "stay predictable and the API stays responsive."],
    ["Recovery", "The trace lives in SQLite, so a page reload resumes from any event id. "
                 "Credentials entered in Settings stay in server memory and are never written "
                 "back to disk."],
    ["Isolation", "Every path an agent supplies is resolved inside that run's workspace and "
                  "rejected if it escapes. Skill archives are path-checked, size-capped, and "
                  "never executed."],
    ["Failure policy", "A delivery failure is logged and never fails the task that produced the "
                       "work. A tool failure is returned to the model as text rather than raised."],
]
story.append(table(ops, [74, CONTENT_W - 74], header=False))

# ------------------------------------------------------------------ PAGE 3 --
story.append(PageBreak())
story.append(P("Guardrails", "h1"))
story.append(P(
    "Six checks run at three boundaries. Every check reports a verdict on every pass, "
    "<b>including when the content is clean</b>, so a run shows what was inspected rather than "
    "only what was caught."))

guards = [
    ["Check", "What it catches", "On a finding"],
    ["pii", "Emails, phones, SSNs, Luhn-verified card numbers, IPs, IBANs, passport numbers",
     "Redacts in place"],
    ["toxicity", "Threats, harassment, demeaning language, profanity",
     "<font color='#B3261E'><b>Blocks</b></font> on threats"],
    ["injection", "Instruction-override attempts inside retrieved content",
     "Neutralizes by framing"],
    ["secrets", "API keys, tokens, private keys, and this app's own credentials",
     "Redacts in place"],
    ["overclaim", "Guaranteed jobs, certifications, ROI and similar promises", "Flags for rewording"],
    ["semantic", "An LLM pass for what pattern matching cannot see",
     "Can raise severity, never lower it"],
]
story.append(table(guards, [58, 330, 105]))

story.append(P("Three boundaries", "h2"))
stages = [
    ["Stage", "Where it sits", "Why there"],
    ["guard_input", "Before the Planner", "Blocks before a single model call is spent"],
    ["tool screening", "Inside the agent loop", "Web and document content is cleaned before the "
                                                "model reads it"],
    ["guard_output", "After review, before delivery",
     "Redactions are rewritten into the PDF and Markdown on disk, not just the email body"],
]
story.append(table(stages, [72, 148, CONTENT_W - 220]))
story.append(P(
    "Only toxicity can stop a task. Personal data is redacted before the model sees it, injection "
    "in retrieved content is neutralized, and an overclaim is a wording problem for the Reviewer. "
    "Letting any of those block would discard work that has already been made safe.", "small"))

story.append(rule())
story.append(P("Further improvements", "h1"))
improve = [
    ["Priority", "Improvement", "Why it matters"],
    ["High", "Parallel task execution with a concurrency cap",
     "Runs are serial today. Independent tasks in one sheet could execute together, cutting "
     "wall-clock time on a large sheet by most of its length."],
    ["High", "Resume a run after a restart",
     "Settings and run state live in memory. Checkpointing the graph with a LangGraph saver "
     "would let an interrupted run continue from the last completed node."],
    ["High", "Human approval gate before delivery",
     "A review-and-release step for sensitive tasks, so a person confirms the deliverable before "
     "any email leaves."],
    ["Medium", "Cost and token budget per run",
     "A ceiling that stops a run before it overspends, with a per-task cost shown in the report."],
    ["Medium", "Scheduled and triggered runs",
     "Cron-style recurring sheets, and a webhook so another system can drop a task in."],
    ["Medium", "Richer source grounding",
     "Store retrieved pages as evidence so a claim in a report links back to the exact passage "
     "that supports it."],
    ["Medium", "Guardrail policy packs",
     "Per-domain rule sets, for example an export-control or safety-critical pack, selectable "
     "per run rather than one global configuration."],
    ["Low", "Skill signing and a trusted registry",
     "Publisher signatures on downloaded skills, so provenance is verified rather than assumed."],
    ["Low", "Multi-user workspaces and audit export",
     "Per-user runs, role-based access, and a signed audit trail export for compliance review."],
]
story.append(table(improve, [42, 150, CONTENT_W - 192]))

story.append(Spacer(1, 5))
story.append(P(
    "Current state: fully working end to end on OpenAI, with the BCAI path wired to the vendored "
    "Boeing wrappers and awaiting endpoint confirmation. Approximately 4,000 lines across 27 "
    "Python modules, a single-page front end, and five built-in skills.", "cap"))

# ==================================================================== build ==
OUT = "/Users/shukranaahmed/Downloads/Boeing/AgenticApp/Autonomous_Task_Desk_Overview.pdf"
doc = SimpleDocTemplate(
    OUT, pagesize=A4,
    leftMargin=MARGIN, rightMargin=MARGIN,
    topMargin=46, bottomMargin=32,
    title="Autonomous Task Desk - Capability Overview",
    author="Autonomous Task Desk",
)


doc.build(story, onFirstPage=decorate, onLaterPages=decorate)
print("wrote", OUT)
