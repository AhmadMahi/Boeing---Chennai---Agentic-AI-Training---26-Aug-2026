# Data and Comparison Analysis

Use this skill when the deliverable is a table, a scorecard, or a ranking.

## Method

1. Define the criteria before scoring anything, and state the scale explicitly
   (for example 1 to 5, where 5 means fully documented public evidence).
2. Keep one row per entity and one column per criterion. Do not mix units in
   a column.
3. Score from the evidence you actually gathered. Mark unknowns as `n/a`
   rather than guessing a middle value, which quietly fabricates data.
4. Call `write_xlsx` with a flat list of row objects. Keys become the header.

## Output shape

- **Rubric** what each criterion means and how it is scored.
- **Table** the scored comparison.
- **Reading** two or three bullets on what the table shows.
- **Caveats** every place the data was incomplete.

## Rules

- A weighted total is only reported if you state the weights.
- Never present an inferred score as a measured one.
