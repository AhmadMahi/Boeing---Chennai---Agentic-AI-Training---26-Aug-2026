# Document Analysis

Use this skill when the answer should come from documents that were uploaded
to the knowledge base rather than from the open web.

## Method

1. Query `rag_search` two or three times with different phrasings. Retrieval
   is semantic, so a rephrase often surfaces a passage the first query missed.
2. Read the retrieved passages before writing anything.
3. If retrieval returns nothing relevant, say so plainly. Do not fill the gap
   from general knowledge, and do not search the web unless the task says to.

## Output shape

- **Answer** direct response in the first two sentences.
- **Evidence** the specific passages that support it, each tagged with its
  source filename.
- **Gaps** what the corpus does not cover.

## Rules

- Cite the source filename for every claim, like `[policy_v3.pdf]`.
- Quote at most one sentence per source. Paraphrase the rest.
- If two documents conflict, show both and flag the conflict rather than
  resolving it yourself.
