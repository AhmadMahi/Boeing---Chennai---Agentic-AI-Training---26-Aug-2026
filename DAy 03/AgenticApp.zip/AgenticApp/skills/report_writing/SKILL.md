# Report Writing

Use this skill when research is already done and the remaining job is to
present it well.

## Structure

1. **Executive summary** three to five bullets a busy reader can act on.
2. **Context** what was asked and what was actually examined.
3. **Findings** the substance, with headings and tables where they help.
4. **Recommendations** numbered, each with an owner-shaped next action.
5. **Sources and limitations**

## Rules

- Short paragraphs. Bullets and tables over prose walls.
- No filler openings, no restating the prompt back to the reader.
- Separate confirmed fact from interpretation, and label the interpretation.
- State uncertainty where it exists rather than smoothing it over.
- Plain professional English. Avoid hype and avoid generic AI phrasing.
