# Market and Competitor Research

Use this skill when the task asks who the players are, what they charge, how
they position themselves, or how a market is moving.

## Method

1. Run three to five distinct searches, not one. Vary the angle: category
   terms, named competitors, pricing pages, and recent news within the last
   18 months.
2. Fetch the two or three most substantial pages. Search snippets alone are
   not evidence.
3. Record for each entity: name, positioning, target buyer, delivery or
   pricing model, and one distinguishing claim.
4. Note where sources disagree. Do not silently pick a side.

## Output shape

- **Scope** one paragraph on what was and was not covered.
- **Findings** a table with one row per entity and the columns above.
- **Signals** three to five bullets on where the market is heading.
- **Confidence** state what is well sourced and what is thin.
- **Sources** numbered list of every URL actually opened.

## Rules

- Every factual claim carries a source number. A claim you cannot source gets
  labelled as inference.
- Pricing and headcount figures go stale fast. Always give the date the source
  was published or last updated, and say when you could not find one.
- Never invent a customer, a review, an award, or a number.
