# Training and Curriculum Design

Use this skill when the deliverable is a learning path, course outline, or
module breakdown.

## Method

1. Research the current syllabus for the topic from at least two independent
   sources, including the vendor's own documentation where one exists.
2. Sequence by dependency, not by popularity. A learner cannot practise
   configuration before understanding the data model.
3. Give every module a measurable objective, a hands-on lab, and a checkpoint
   that proves the objective was met.
4. Keep the weekly load realistic and state the assumed hours per week.

## Output shape

- **Audience and prerequisites**
- **Outcomes** what the learner can do at the end, phrased as actions.
- **Roadmap** a table: week, module, objective, lab, checkpoint.
- **Effort** hours per week and total duration.
- **Sources**

## Rules

- Do not promise a job, a salary, a certification pass, or a business outcome.
- Certification eligibility rules change. State the source and its date, and
  tell the reader to confirm with the vendor.
- Keep the language practical and outcome focused.
