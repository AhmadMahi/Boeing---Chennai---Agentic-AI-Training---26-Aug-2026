# Industry-Standard Software Project Planning

Use this skill **before development starts** when the user asks for a software,
AI, agentic-AI, data, API, platform, or enterprise application development plan.

The purpose of this skill is to turn an ambiguous development idea into a
**build-ready, reviewable project plan** before implementation begins.

This is a planning skill, not a coding skill. It must resist the temptation to
jump directly into framework selection or implementation. The output should
make the project sufficiently understood that engineering can begin with
controlled scope, explicit requirements, architecture decisions, measurable
quality targets, security controls, delivery milestones, risks, dependencies,
and acceptance criteria.

## Industry alignment

Use the following as reference frameworks rather than claiming that the plan
is formally compliant with them:

- ISO/IEC/IEEE 12207:2026 — software life-cycle processes.
- ISO/IEC/IEEE 29148:2018 — requirements engineering. A 2026 third edition is
  currently under development, so verify the current edition/status when the
  plan depends on it.
- ISO/IEC 25010:2023 — product quality model.
- NIST SP 800-218 SSDF — secure software development practices.
- ISO/IEC/IEEE 24748-3:2020 — guidance for applying 12207 life-cycle processes.

Where relevant, also consider organization-specific governance, privacy,
regulatory, cloud, accessibility, reliability, AI governance, and security
requirements.

Do not state that a project is "ISO compliant", "NIST compliant", or
"industry-standard certified" merely because this planning method references
these frameworks. Identify alignment, gaps, assumptions, and items requiring
formal organizational review.

## Core principle

**Do not start implementation until the plan has enough evidence to answer:**

1. What problem are we solving?
2. Who has the problem?
3. What outcome defines success?
4. What is in scope and explicitly out of scope?
5. What requirements must the system satisfy?
6. How will requirements be verified?
7. What architecture is appropriate and why?
8. What data enters, leaves, and moves through the system?
9. What security, privacy, compliance, and safety controls are required?
10. What are the major technical and delivery risks?
11. What is the smallest useful release?
12. How will we test, deploy, operate, monitor, and support it?
13. What decisions are still unresolved?
14. What evidence is required before development can begin?

If important answers are unavailable, do not invent them. Mark them as
**Open Questions**, **Assumptions**, or **Decisions Required** and explain
their impact.

---

# Planning Method

Follow these phases in order. Iteration is allowed, but do not silently skip
a phase.

## Phase 0 — Project Intake and Classification

First understand the request.

Capture:

- project name
- problem statement
- business/user context
- requested outcome
- stakeholders
- target users
- project type
- existing system or greenfield status
- expected delivery environment
- known constraints
- deadline or target date
- budget/resource constraints if supplied
- geographic/data-residency constraints
- technology constraints
- regulatory or contractual constraints
- AI involvement, if any

Classify the project:

- web application
- mobile application
- API/platform
- data/analytics system
- AI/ML system
- agentic AI system
- internal enterprise tool
- customer-facing product
- integration/migration
- infrastructure/platform
- other

If classification is uncertain, state the uncertainty.

### Intake checkpoint

Produce an **Intake Summary** containing:

- confirmed facts
- assumptions
- missing information
- immediate risks
- decisions required before discovery continues

---

# Phase 1 — Problem and Outcome Definition

Do not begin with features.

Define:

### Problem

What problem exists today?

### Users

Who experiences it?

### Current state

How is the work performed today?

### Pain points

What is slow, expensive, risky, error-prone, manual, fragmented, or
impossible?

### Desired future state

What should become materially better?

### Business/user outcomes

Define measurable outcomes where possible.

Examples:

- reduce processing time from X to Y
- increase successful completion rate from X% to Y%
- reduce manual review effort
- reduce incident rate
- improve response time
- improve task completion accuracy

Avoid vague goals such as "make it intelligent" or "use AI".

### Non-goals

Explicitly state what the project will not attempt to solve.

### Success metrics

Separate:

- business metrics
- user metrics
- technical metrics
- quality metrics
- security metrics
- operational metrics

---

# Phase 2 — Stakeholder and User Discovery

Identify:

- sponsor
- product owner
- business owner
- end users
- engineering
- architecture
- security
- privacy/legal
- data owners
- operations/SRE
- QA
- support
- compliance
- external vendors
- affected third parties

Create a stakeholder matrix:

| Stakeholder | Role | Interest | Influence | Responsibility | Decision rights |
|---|---|---|---|---|---|

Identify conflicts between stakeholder needs.

For user-facing systems, define representative personas and their primary
journeys.

Do not create fictional personas as facts. Label them as assumptions when they
have not been validated.

---

# Phase 3 — Requirements Engineering

Use requirements engineering discipline rather than converting every request
directly into a feature list.

Separate:

- business requirements
- user requirements
- functional requirements
- non-functional requirements
- interface/integration requirements
- data requirements
- security requirements
- privacy requirements
- operational requirements
- compliance requirements
- AI-specific requirements where applicable

## Functional requirements

Write each requirement as a testable statement.

Preferred format:

**FR-001:** The system shall [observable behavior].

Avoid:

- "The system should be fast."
- "The system should be intelligent."
- "The system should have a good UI."

## Non-functional requirements

Quantify where practical:

- latency
- throughput
- availability
- scalability
- recovery objectives
- storage
- concurrency
- accessibility
- compatibility
- maintainability
- observability
- auditability

## Requirement quality check

For every important requirement ask:

- Is it unambiguous?
- Is it necessary?
- Is it feasible?
- Is it testable?
- Is it traceable to a business/user outcome?
- Does it have an owner?
- Does it have acceptance criteria?

Flag requirements that fail these tests.

---

# Phase 4 — Scope, MVP and Release Strategy

Create:

### In scope

What the first release will contain.

### Out of scope

What is intentionally excluded.

### MVP

The smallest release that can validate the intended outcome.

### Release increments

Break the work into logical increments such as:

- foundation
- vertical slice
- MVP
- beta/pilot
- production
- post-launch

Avoid defining MVP merely as "the simplest version". It should be the
smallest version capable of validating the key hypothesis or delivering the
minimum useful outcome.

---

# Phase 5 — Use Cases and User Journeys

For each critical journey define:

- actor
- trigger
- preconditions
- main flow
- alternate flow
- failure flow
- expected result
- security/privacy considerations
- acceptance criteria

For complex systems, create a use-case inventory.

For API systems, translate journeys into API operations.

For AI systems, explicitly document:

- user intent
- model interaction
- tools
- retrieved context
- state/memory
- model output
- validation
- human approval
- side effects

---

# Phase 6 — Architecture Discovery

Do not choose technologies merely because they are popular.

First derive architectural needs from:

- requirements
- scale
- latency
- availability
- security
- data
- integration
- team capability
- operational constraints
- cost
- vendor constraints

Produce:

### Context diagram

System, users, external systems and trust boundaries.

### Container/component view

Major services/modules and their responsibilities.

### Data flow

How information moves through the system.

### Deployment view

Where components run and how environments are separated.

### Integration map

External APIs, databases, identity providers, queues, storage, third-party
services, model providers, etc.

### Architecture decisions

For every significant decision record:

- decision
- context
- options considered
- selected option
- rationale
- trade-offs
- consequences
- assumptions

Recommend Architecture Decision Records (ADRs) for significant decisions.

---

# Phase 7 — Technology Evaluation

Only after architectural needs are understood, evaluate technologies.

For each major technology decision compare realistic alternatives.

Consider:

- functional fit
- performance
- scalability
- reliability
- security
- ecosystem
- maintainability
- team expertise
- vendor lock-in
- licensing
- cost
- operational complexity
- maturity
- community/vendor support

Do not recommend a technology without explaining the decision criteria.

Distinguish:

- requirement
- evidence
- recommendation
- opinion
- assumption

---

# Phase 8 — Data Architecture

Identify:

- data sources
- data owners
- data classification
- schemas
- entities
- relationships
- storage
- retention
- archival
- deletion
- backup
- synchronization
- lineage
- data quality
- access controls

Create a data inventory:

| Data | Source | Owner | Classification | Storage | Retention | Access |
|---|---|---|---|---|---|---|

For sensitive data, explicitly consider:

- collection minimization
- masking
- encryption
- access controls
- logging
- retention
- deletion
- residency
- consent/legal basis where applicable

Do not invent regulatory obligations. Identify the jurisdiction and ask for
legal/compliance confirmation where necessary.

---

# Phase 9 — AI / Agentic AI Planning

If AI is involved, add an AI-specific architecture and risk assessment.

Document:

### Model

- provider
- model candidates
- capabilities
- context limits
- latency
- cost
- fallback strategy

### Prompting

- system instructions
- task prompts
- structured output
- prompt versioning
- evaluation

### RAG

- source documents
- ingestion
- chunking
- embedding
- retrieval
- reranking
- citation/provenance
- freshness
- access control

### Agents

For each agent define:

- responsibility
- inputs
- outputs
- tools
- permissions
- state
- termination condition
- failure behavior
- escalation path

### Tool governance

For every tool specify:

- purpose
- allowed agent
- input validation
- authorization
- side effects
- rate limits
- audit logging
- failure behavior

### Guardrails

Plan controls at:

- input
- retrieved/tool content
- model interaction
- tool execution
- output
- delivery/side-effect boundaries

### AI evaluation

Define tests for:

- correctness
- groundedness
- hallucination
- instruction following
- robustness
- prompt injection
- sensitive data leakage
- unsafe outputs
- tool misuse
- regression

Never treat "the model responded correctly once" as sufficient validation.

---

# Phase 10 — Security Threat Modeling

Security must begin during planning, not after implementation.

Perform a lightweight threat model.

Identify:

- assets
- actors
- trust boundaries
- entry points
- sensitive operations
- attack surfaces
- threats
- mitigations

Consider relevant categories such as:

- authentication
- authorization
- privilege escalation
- injection
- secrets exposure
- insecure dependencies
- data leakage
- SSRF
- insecure file handling
- API abuse
- supply-chain risk
- logging exposure
- denial of service
- misconfiguration

For AI systems additionally consider:

- prompt injection
- indirect prompt injection
- excessive agency
- tool abuse
- model manipulation
- retrieval poisoning
- sensitive information disclosure
- insecure agent-to-agent communication

Map security work to the development lifecycle rather than creating a
separate "security phase" that happens only at the end.

---

# Phase 11 — Quality Engineering Strategy

Use a test pyramid / layered validation strategy appropriate to the project.

Plan:

- unit tests
- component tests
- integration tests
- API tests
- contract tests
- end-to-end tests
- regression tests
- performance tests
- security tests
- accessibility tests
- reliability/failure tests
- user acceptance testing

For AI systems additionally plan:

- deterministic guardrail tests
- model evaluation datasets
- adversarial tests
- prompt regression tests
- tool-use tests
- RAG retrieval tests
- groundedness tests
- output schema tests
- human evaluation where appropriate

Define what must pass before:

- merge
- release candidate
- pilot
- production

---

# Phase 12 — DevSecOps and Delivery

Define the intended delivery pipeline:

```text
Plan
 ↓
Develop
 ↓
Lint / Static Analysis
 ↓
Unit Tests
 ↓
Build
 ↓
Security / Dependency Checks
 ↓
Integration Tests
 ↓
Deploy to Test
 ↓
Acceptance / Evaluation
 ↓
Production Approval
 ↓
Production
 ↓
Monitor
```

Plan:

- source control strategy
- branching model
- pull-request checks
- CI/CD
- artifact management
- dependency management
- secret management
- environment separation
- infrastructure as code where appropriate
- database migration strategy
- rollback strategy
- release approval

Do not mandate a specific Git workflow unless the project requires it.

---

# Phase 13 — Observability and Operations

Define before development:

### Logs

What must be logged?

### Metrics

What must be measured?

### Traces

Which transactions need distributed tracing?

### Alerts

What constitutes an operational incident?

### Dashboards

What does engineering/support need to see?

For AI systems include:

- model latency
- token usage
- model cost
- tool calls
- retrieval quality
- guardrail events
- evaluation scores
- failed runs
- human escalations

Never log secrets or sensitive information merely for convenience.

---

# Phase 14 — Reliability and Failure Engineering

For each critical dependency define:

- timeout
- retry behavior
- backoff
- circuit breaking where appropriate
- fallback
- idempotency
- queueing
- dead-letter behavior
- recovery
- user-visible failure behavior

Define:

- availability target
- RTO
- RPO
- backup strategy
- disaster recovery expectations

Only specify numeric targets when they are supplied or can be justified.

---

# Phase 15 — Cost and Capacity Planning

Estimate major cost drivers.

Consider:

- infrastructure
- databases
- storage
- networking
- third-party APIs
- model inference
- embeddings
- observability
- support
- licenses
- human review

For AI applications estimate:

- requests/day
- tokens/request
- retrieval calls
- tool calls
- model calls/task
- expected retries
- peak load
- monthly model spend

Present assumptions separately from confirmed costs.

Use ranges when precision is unavailable.

---

# Phase 16 — Delivery Planning

Break implementation into vertical, testable increments.

For every milestone define:

- objective
- deliverables
- dependencies
- owner
- entry criteria
- exit criteria
- acceptance criteria
- risks

Avoid plans consisting only of technical activities such as:

> "Build API → build frontend → integrate database."

Prefer outcome-oriented slices such as:

> "A user can create a task, execute the complete workflow, receive a
> validated result, and recover from a failed dependency."

---

# Phase 17 — Estimation

Estimate work using explicit assumptions.

Separate:

- engineering effort
- QA effort
- architecture
- security
- DevOps
- data work
- design
- documentation
- project management
- external dependencies

Use ranges where uncertainty is high.

Do not present an estimate as a commitment.

Identify the assumptions that could materially change the estimate.

---

# Phase 18 — Risk Management

Create a risk register:

| ID | Risk | Probability | Impact | Exposure | Mitigation | Owner | Trigger | Contingency |
|---|---|---|---|---|---|---|---|---|

Include technical, product, security, operational, vendor, schedule, data,
compliance and adoption risks.

For AI projects additionally consider:

- model availability
- model behavior changes
- hallucination
- evaluation gaps
- prompt injection
- data leakage
- provider outages
- cost volatility
- model/provider lock-in

---

# Phase 19 — Traceability

Create a lightweight traceability chain:

```text
Business Outcome
      ↓
Requirement
      ↓
Use Case
      ↓
Architecture Component
      ↓
Implementation Item
      ↓
Test Case
      ↓
Acceptance Evidence
```

Every critical requirement should have a planned verification method.

Use IDs such as:

- BR-001 — Business Requirement
- UR-001 — User Requirement
- FR-001 — Functional Requirement
- NFR-001 — Non-Functional Requirement
- SEC-001 — Security Requirement
- AI-001 — AI Requirement
- TC-001 — Test Case
- ADR-001 — Architecture Decision
- RSK-001 — Risk

---

# Phase 20 — Definition of Ready for Development

Do not recommend "start coding" until the following have been assessed.

## Development Readiness Gate

### Product

- [ ] Problem is clearly defined.
- [ ] Target users are identified.
- [ ] Success metrics exist.
- [ ] MVP scope is defined.
- [ ] Out-of-scope items are documented.

### Requirements

- [ ] Critical requirements are testable.
- [ ] Acceptance criteria exist.
- [ ] Major requirements have owners.
- [ ] Open questions are visible.
- [ ] Requirement conflicts are resolved or explicitly accepted.

### Architecture

- [ ] System context is understood.
- [ ] Major components are identified.
- [ ] Data flows are understood.
- [ ] External dependencies are known.
- [ ] Significant architecture decisions have rationale.

### Security / Privacy

- [ ] Threat model is performed.
- [ ] Sensitive data is identified.
- [ ] Authentication/authorization approach is defined.
- [ ] Secret management is defined.
- [ ] Security-critical dependencies are identified.
- [ ] Privacy/compliance questions have owners.

### Quality

- [ ] Quality attributes are identified.
- [ ] Test strategy exists.
- [ ] Acceptance criteria are measurable.
- [ ] Performance/reliability targets are defined where required.
- [ ] AI evaluation strategy exists where applicable.

### Delivery

- [ ] Environments are defined.
- [ ] CI/CD strategy is defined.
- [ ] Deployment strategy is known.
- [ ] Rollback strategy exists.
- [ ] Observability requirements exist.

### Operations

- [ ] Ownership after launch is identified.
- [ ] Monitoring requirements exist.
- [ ] Incident/support expectations exist.
- [ ] Backup/recovery needs are known.

### Planning

- [ ] Dependencies are mapped.
- [ ] Risks are recorded.
- [ ] Milestones have exit criteria.
- [ ] Estimates include assumptions.
- [ ] Unresolved decisions are explicitly listed.

---

# Phase 21 — Final Planning Review

Before producing the final plan, perform a contradiction and completeness pass.

Check for:

- requirement conflicts
- architecture contradicting requirements
- impossible timelines
- missing dependencies
- missing security controls
- missing operational ownership
- unrealistic performance expectations
- unsupported technology claims
- unverified costs
- unvalidated assumptions
- missing acceptance criteria
- missing failure scenarios
- missing rollback strategy
- missing AI evaluation where AI is present

Do not hide uncertainty.

---

# Required Output

The final project-planning deliverable must contain the following sections.

## 1. Executive Summary

Explain:

- problem
- proposed solution
- expected outcome
- major constraints
- recommendation
- major unresolved questions

## 2. Problem Statement

State the problem independently of the proposed technology.

## 3. Goals and Non-Goals

Use measurable goals where possible.

## 4. Stakeholders and Users

Include stakeholder matrix and user personas/journeys where appropriate.

## 5. Current State

Explain the existing workflow/system and pain points.

## 6. Future State

Explain the intended operating model.

## 7. Scope

Include:

- in scope
- out of scope
- MVP
- future phases

## 8. Requirements

Include a numbered requirements table:

| ID | Requirement | Type | Priority | Source | Acceptance Criteria | Verification |
|---|---|---|---|---|---|---|

## 9. Use Cases / User Stories

Include critical flows and failure paths.

## 10. Quality Attributes

Cover relevant ISO/IEC 25010-style quality concerns such as functional
suitability, performance efficiency, compatibility, interaction capability,
reliability, security, maintainability, flexibility and safety as applicable
to the project.

Do not mechanically include irrelevant attributes.

## 11. Architecture

Include:

- context
- components
- data flow
- integrations
- deployment
- trust boundaries
- key decisions

Use diagrams when the output format supports them.

## 12. Technology Evaluation

Show alternatives, criteria, trade-offs and recommendation.

## 13. Data Architecture

Include data sources, ownership, classification, storage, lifecycle and
access.

## 14. Security and Privacy

Include threat model, security requirements, controls and unresolved
compliance/privacy questions.

## 15. AI / Agent Architecture

Only when applicable. Include model, prompts, RAG, agents, tools, guardrails,
evaluation and human oversight.

## 16. Test and Quality Strategy

Include testing layers, environments, acceptance testing and release gates.

## 17. DevSecOps / Delivery Strategy

Include CI/CD, environments, deployment, migrations, rollback and release
controls.

## 18. Observability and Operations

Include logs, metrics, traces, dashboards, alerts and ownership.

## 19. Reliability / DR

Include availability, failure modes, backup, RTO/RPO and recovery strategy
where applicable.

## 20. Cost and Capacity

Show assumptions and ranges.

## 21. Delivery Roadmap

Use:

| Phase | Objective | Deliverables | Dependencies | Exit Criteria |
|---|---|---|---|---|

## 22. Work Breakdown Structure

Break the project into implementation-ready work packages.

## 23. Estimates

Show effort ranges and assumptions.

## 24. Risk Register

Use the standard risk table.

## 25. Decision Log / ADR Candidates

List important decisions that need explicit approval.

## 26. Traceability Matrix

Map critical outcomes → requirements → components → tests.

## 27. Development Readiness Gate

Show the checklist and mark each item:

- READY
- PARTIAL
- BLOCKED
- NOT APPLICABLE

## 28. Open Questions

List unresolved questions with:

- question
- why it matters
- owner
- required-by phase
- impact if unresolved

## 29. Recommended Next Steps

End with concrete actions required before development begins.

---

# Research Rules

When current external information matters:

1. Search at least two independent authoritative sources for major technology,
   standards, pricing, regulatory or vendor claims.
2. Prefer primary sources for technical capabilities and standards.
3. For standards, verify the current edition/status before citing it.
4. Distinguish current facts from recommendations and assumptions.
5. Record source dates for time-sensitive information.
6. Do not claim compliance merely because a framework was referenced.
7. If the user supplies project documents, treat those as primary project
   context and do not silently replace their requirements with web research.
8. Cite external evidence next to the claim it supports.

---

# Decision Rules

## Never invent missing project facts

If the user has not specified:

- budget
- team size
- deadline
- traffic
- compliance requirements
- data volume
- availability target
- user count

do not fabricate values.

Use:

**Assumption:** ...

or

**Decision required:** ...

## Do not over-engineer

Recommend complexity only when justified by:

- scale
- risk
- requirements
- reliability
- security
- maintainability
- organizational constraints

A small internal tool does not automatically require microservices,
Kubernetes, event-driven architecture, or multiple databases.

## Do not overfit to a technology

Do not start with:

> "We should use LangGraph."

Start with:

> "The system requires durable stateful orchestration with conditional
> execution, retries, human approval and observable workflow transitions."

Then evaluate technologies against those needs.

## Prefer vertical slices

A development plan should produce end-to-end usable increments rather than
large disconnected layers.

## Make quality measurable

Replace vague statements with measurable acceptance criteria wherever possible.

## Make security continuous

Security, privacy and supply-chain controls must appear throughout the plan,
not only as a final phase.

## Treat AI as probabilistic

For AI systems, never assume deterministic correctness. Define evaluation,
fallback, guardrails, observability and human escalation.

---

# Final Response Style

Write for an engineering/product audience.

Be:

- structured
- evidence-based
- practical
- explicit about assumptions
- explicit about uncertainty
- implementation-oriented
- measurable

Avoid:

- marketing language
- unsupported certainty
- technology hype
- arbitrary estimates
- unexplained acronyms
- "best practice" claims without context

The final deliverable should be detailed enough that a technical lead can use it
as the starting point for architecture, backlog creation, estimation and
implementation planning without having to rediscover the problem from scratch.
