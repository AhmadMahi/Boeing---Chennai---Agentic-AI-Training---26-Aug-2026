# Running in Docker

## Quick start

```bash
docker compose up -d --build
```

Open http://localhost:8100

Nothing else is required. The app boots with no configuration and the Settings
panel accepts every credential at runtime.

## With pre-filled settings

Values in `.env` only pre-fill the Settings panel on startup. They are optional.

```bash
cp .env.example .env
# edit .env, then
docker compose up -d --build
```

## Without compose

```bash
docker build -t autonomous-task-desk:1.0 .

docker run -d --name task-desk \
  -p 8100:8100 \
  -v task-desk-data:/app/data \
  -v "$PWD/skills:/app/skills" \
  autonomous-task-desk:1.0
```

Add `--env-file .env` to pre-fill settings.

## What persists

| Path | Holds | Mount |
|---|---|---|
| `/app/data/app.db` | Runs, tasks, the event trace, deliveries, skill registry | named volume |
| `/app/data/chroma` | Document and skill vectors | named volume |
| `/app/data/uploads` | Uploaded task sheets and documents | named volume |
| `/app/data/outputs` | Generated PDFs, spreadsheets and Markdown per run | named volume |
| `/app/skills` | Skill folders | bind mount to the host |

Skills are bind mounted on purpose, so you can add or edit a skill folder on
the host and it survives an image rebuild. Everything else lives in the named
volume `task-desk-data`.

Copy artifacts out without a shell:

```bash
docker cp task-desk:/app/data/outputs ./outputs
```

## Image design

Two stages. The builder installs `build-essential` and compiles wheels for the
C extensions in ChromaDB's dependency tree. The runtime stage installs from
those wheels with `--no-index`, so no compiler ships in the final image and a
missing wheel fails at build time rather than silently reaching PyPI.

The container runs as the non-root user `desk` (uid 10001) and
`no-new-privileges` is set in compose. The app processes untrusted retrieved
web content, so it never needs to escalate.

`ca-certificates` is installed deliberately: outbound TLS is needed twice, once
for the model provider and once for Resend SMTP. Missing CAs is what caused the
`CERTIFICATE_VERIFY_FAILED` on the host install.

## Health

```bash
docker compose ps          # STATUS shows healthy once /api/state responds
docker compose logs -f
```

The healthcheck has a 40 second start period because ChromaDB warms after the
port is already listening.

## Networking notes

- The app binds `0.0.0.0` inside the container. `run.py` defaults to
  `127.0.0.1`, which would be unreachable from outside, so the host is passed
  explicitly in the `CMD`.
- Telegram uses long polling, so no inbound port, tunnel or public URL is
  needed for the bot to work from inside the container.
- Outbound SMTP on port 587 must be permitted by your network. Some hosts
  block it; SMTP2GO on 2525 is the usual fallback.

## Rebuild after a code change

```bash
docker compose up -d --build
```

Data survives, because it lives in the volume rather than the image.

## Reset everything

```bash
docker compose down -v
```

This deletes the volume: all runs, artifacts and indexed documents. Skills
survive, since they are bind mounted from the host.
