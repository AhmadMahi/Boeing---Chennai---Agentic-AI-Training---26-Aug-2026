"""
FastAPI server for the Advanced RAG app.

Credential handling: the UDAL PAT or OpenAI key is posted once from the UI,
held in server memory keyed by an opaque session id, and never written to
disk or echoed back in full. Closing the session drops it.

Run:  uvicorn app.main:app --reload --port 8000
"""

from __future__ import annotations

import os
import secrets
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from .pipeline import (
    RagIndex,
    SemanticCache,
    build_index,
    cross_encoder_available,
    run_query,
)
from .providers import (
    PROVIDERS,
    BaseProvider,
    ProviderError,
    build_provider,
    mask_secret,
)

STATIC_DIR = Path(__file__).parent / "static"

# Deliberately small so the app stays quick and predictable.
MAX_FILES = 5
MAX_FILE_BYTES = 2 * 1024 * 1024
MAX_TOTAL_CHARS = 200_000
MAX_CHUNKS = 400
SESSION_IDLE_SECONDS = 4 * 60 * 60

SAMPLE_DOCS: List[Dict[str, Any]] = [
    {
        "source": "langchain-overview.txt",
        "text": """LangChain is a framework designed to simplify the creation of applications using large language models (LLMs).
It provides tools for chaining prompts, managing memory, integrating with external data sources, and building agents.

LangGraph is a library built on top of LangChain that enables building stateful, multi-actor applications with LLMs.
It uses a graph-based architecture where nodes represent computation steps and edges represent transitions.
LangGraph is particularly useful for building complex agent workflows that require cycles and branching logic.

LangSmith is a developer platform for debugging, testing, evaluating, and monitoring LLM applications.
It provides tracing capabilities that allow developers to see every step of an LLM chain or agent run.
LangSmith integrates seamlessly with LangChain and LangGraph.

RAG stands for Retrieval-Augmented Generation. It is a technique where relevant documents are retrieved
from a knowledge base and provided to the LLM as context before generating a response.
RAG helps reduce hallucinations and allows the model to answer questions about private or recent data.

Embeddings are numerical vector representations of text. Similar texts produce similar embedding vectors.
This property allows us to find semantically similar documents using distance metrics like cosine similarity.
Models such as text-embedding-3-small are commonly used to produce these vectors.

Vector stores are databases optimized for storing and searching embedding vectors.
FAISS (Facebook AI Similarity Search) is a popular open-source vector store for fast nearest-neighbor search.
Other vector stores include Chroma, Pinecone, Weaviate, and Qdrant.

Agents are LLM-powered systems that can use tools to accomplish tasks.
A tool is a function that the agent can call, such as a web search, calculator, or API call.
Agents decide which tools to use and in what order based on the user's query.""",
    },
    {
        "source": "advanced-retrieval-notes.txt",
        "text": """BM25 is a sparse, bag-of-words ranking function. It scores a document from term frequency and
inverse document frequency, with a length normalization term. Because it matches literal tokens, BM25 reliably
catches part numbers, error codes, and rare proper nouns that dense embedding search often misses.

Dense retrieval embeds the query and every chunk into the same vector space and ranks chunks by cosine
similarity. It captures paraphrase and synonym overlap, so it answers questions whose wording never appears
in the source text. Its weakness is the mirror image of BM25: exact identifiers get blurred into their neighbours.

Hybrid retrieval runs both and merges the results. Reciprocal Rank Fusion, or RRF, merges any number of ranked
lists without needing to normalize scores between them. Each list contributes 1 divided by the sum of a constant
k and the rank of the document in that list. The constant is normally set to 60. A document that appears near the
top of several lists accumulates the highest fused score, which makes RRF robust to one retriever failing badly.

HyDE stands for Hypothetical Document Embeddings. The model first writes a short passage that would answer the
question, then that passage is embedded and used as the search vector. A generated answer sits closer to real
document passages in embedding space than a short question does, so HyDE bridges the vocabulary gap between
terse queries and long-form text.

Reranking is the second half of the retrieve-then-rerank pattern. A cross-encoder scores the query and one
candidate together in a single forward pass, so it can model fine-grained interaction between query and document
tokens. That is far more accurate than cosine similarity but too slow to run over a whole corpus, so it is applied
only to the small candidate set that fusion produced. An LLM reranker achieves the same effect by asking the model
to score each candidate directly.

A semantic cache stores previous answers keyed by the question. Lookup tries an exact string match first, which
costs nothing, then falls back to cosine similarity between the new question's embedding and the stored ones.
A hit is accepted only above a similarity threshold, typically around 0.92. Each entry carries a timestamp and a
time-to-live, and entries past their TTL are evicted on access so stale answers cannot be served indefinitely.""",
    },
]


# ------------------------------------------------------------------ sessions


@dataclass
class Session:
    id: str
    provider: BaseProvider
    cache: SemanticCache = field(default_factory=SemanticCache)
    index: Optional[RagIndex] = None
    created_at: float = field(default_factory=time.time)
    last_seen: float = field(default_factory=time.time)


SESSIONS: Dict[str, Session] = {}
LOCK = threading.Lock()


def _reap_sessions() -> None:
    cutoff = time.time() - SESSION_IDLE_SECONDS
    for sid in [s for s, v in SESSIONS.items() if v.last_seen < cutoff]:
        SESSIONS.pop(sid, None)


def get_session(session_id: str) -> Session:
    with LOCK:
        _reap_sessions()
        session = SESSIONS.get(session_id)
        if session is None:
            raise HTTPException(
                status_code=401,
                detail="Session not found or expired. Connect a provider again.",
            )
        session.last_seen = time.time()
        return session


# -------------------------------------------------------------------- models


class ConnectRequest(BaseModel):
    provider: str = Field(..., description="boeing or openai")
    credential: str = ""
    use_env: bool = False


class QueryRequest(BaseModel):
    session_id: str
    question: str
    use_cache: bool = True
    use_rewrite: bool = True
    use_bm25: bool = True
    use_dense: bool = True
    use_hyde: bool = True
    rerank_mode: str = "llm"          # llm | cross_encoder | off
    top_k_retrieval: int = 8
    top_k_context: int = 4
    cache_ttl: Optional[int] = None
    cache_threshold: Optional[float] = None


class SessionRef(BaseModel):
    session_id: str


class CacheConfig(BaseModel):
    session_id: str
    ttl_seconds: Optional[int] = None
    threshold: Optional[float] = None


# ----------------------------------------------------------------------- app

app = FastAPI(title="Advanced RAG", version="1.0.0")

if STATIC_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


@app.get("/")
def index() -> FileResponse:
    return FileResponse(str(STATIC_DIR / "index.html"))


@app.get("/api/health")
def health() -> Dict[str, Any]:
    return {"ok": True, "sessions": len(SESSIONS)}


@app.get("/api/bootstrap")
def bootstrap() -> Dict[str, Any]:
    return {
        "providers": [
            {
                "key": "boeing",
                "label": "Boeing BCAI",
                "credential_label": "UDAL PAT",
                "placeholder": "Paste your UDAL Personal Access Token",
                "chat_model": "gpt-4o-mini",
                "embed_model": "text-embedding-3-small",
                "env_available": bool(os.getenv("UDAL_PAT")),
                "note": "Internal BCAI endpoints. TLS verification is relaxed for the Boeing chain.",
            },
            {
                "key": "openai",
                "label": "OpenAI",
                "credential_label": "API key",
                "placeholder": "sk-...",
                "chat_model": "gpt-4o-mini",
                "embed_model": "text-embedding-3-small",
                "env_available": bool(os.getenv("OPENAI_API_KEY")),
                "note": "api.openai.com, billed to your own key.",
            },
        ],
        "cross_encoder_available": cross_encoder_available(),
        "limits": {
            "max_files": MAX_FILES,
            "max_file_mb": MAX_FILE_BYTES // (1024 * 1024),
            "max_chunks": MAX_CHUNKS,
            "max_total_chars": MAX_TOTAL_CHARS,
        },
        "sample_sources": [d["source"] for d in SAMPLE_DOCS],
    }


@app.post("/api/connect")
def connect(req: ConnectRequest) -> Dict[str, Any]:
    kind = (req.provider or "").lower().strip()
    if kind not in PROVIDERS:
        raise HTTPException(400, f"Unknown provider '{req.provider}'.")

    credential = (req.credential or "").strip()
    if req.use_env or not credential:
        env_name = "UDAL_PAT" if kind == "boeing" else "OPENAI_API_KEY"
        credential = (os.getenv(env_name) or "").strip()
        if not credential:
            raise HTTPException(
                400,
                f"No credential supplied and {env_name} is not set in the environment.",
            )

    try:
        provider = build_provider(kind, credential)
        ping = provider.ping()
    except ProviderError as exc:
        raise HTTPException(502, str(exc)) from exc

    session_id = secrets.token_urlsafe(24)
    with LOCK:
        _reap_sessions()
        SESSIONS[session_id] = Session(id=session_id, provider=provider)

    return {
        "session_id": session_id,
        "provider": {
            "key": provider.key,
            "label": provider.label,
            "chat_model": provider.chat_model,
            "embed_model": provider.embed_model,
            "credential_masked": mask_secret(credential),
        },
        "check": ping,
    }


@app.post("/api/disconnect")
def disconnect(req: SessionRef) -> Dict[str, Any]:
    with LOCK:
        existed = SESSIONS.pop(req.session_id, None) is not None
    return {"closed": existed}


def _read_upload(upload: UploadFile) -> List[Dict[str, Any]]:
    """Turn one uploaded file into one or more documents. PDFs become one
    document per page so citations can report a page number."""
    raw = upload.file.read(MAX_FILE_BYTES + 1)
    if len(raw) > MAX_FILE_BYTES:
        raise HTTPException(
            413,
            f"{upload.filename} is larger than {MAX_FILE_BYTES // (1024 * 1024)} MB.",
        )

    name = upload.filename or "upload"
    suffix = Path(name).suffix.lower()

    if suffix == ".pdf":
        try:
            import io

            from pypdf import PdfReader
        except ImportError as exc:
            raise HTTPException(
                400, "PDF upload needs pypdf. Install it, or upload .txt / .md instead."
            ) from exc

        reader = PdfReader(io.BytesIO(raw))
        docs = []
        for page_no, page in enumerate(reader.pages, start=1):
            text = (page.extract_text() or "").strip()
            if text:
                docs.append({"source": name, "text": text, "page": page_no})
        if not docs:
            raise HTTPException(400, f"No extractable text in {name}.")
        return docs

    if suffix not in {".txt", ".md", ".markdown", ".csv", ".json", ""}:
        raise HTTPException(
            400, f"Unsupported file type '{suffix}'. Use .pdf, .txt, .md, .csv or .json."
        )

    text = raw.decode("utf-8", errors="replace").strip()
    if not text:
        raise HTTPException(400, f"{name} is empty.")
    return [{"source": name, "text": text, "page": None}]


@app.post("/api/ingest")
def ingest(
    session_id: str = Form(...),
    text: str = Form(""),
    use_sample: bool = Form(False),
    chunk_size: int = Form(300),
    chunk_overlap: int = Form(60),
    files: List[UploadFile] = File(default=[]),
) -> Dict[str, Any]:
    session = get_session(session_id)

    files = [f for f in files if f and f.filename]
    if len(files) > MAX_FILES:
        raise HTTPException(400, f"At most {MAX_FILES} files per index.")

    documents: List[Dict[str, Any]] = []
    if use_sample:
        documents.extend({**d, "page": None} for d in SAMPLE_DOCS)
    if text.strip():
        documents.append(
            {"source": "pasted-text", "text": text.strip(), "page": None}
        )
    for upload in files:
        documents.extend(_read_upload(upload))

    if not documents:
        raise HTTPException(
            400, "Nothing to index. Upload a file, paste text, or use the sample corpus."
        )

    total_chars = sum(len(d["text"]) for d in documents)
    if total_chars > MAX_TOTAL_CHARS:
        raise HTTPException(
            413,
            f"{total_chars:,} characters exceeds the {MAX_TOTAL_CHARS:,} character limit. "
            "Trim the input or split it across sessions.",
        )

    chunk_size = max(120, min(1500, int(chunk_size)))
    chunk_overlap = max(0, min(chunk_size - 20, int(chunk_overlap)))

    started = time.time()
    try:
        session.index = build_index(
            documents,
            session.provider,
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
            max_chunks=MAX_CHUNKS,
        )
    except ProviderError as exc:
        raise HTTPException(502, str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc

    session.cache.clear()

    return {
        "index": session.index.summary(),
        "documents": [
            {"source": d["source"], "page": d.get("page"), "chars": len(d["text"])}
            for d in documents
        ],
        "total_chars": total_chars,
        "build_ms": round((time.time() - started) * 1000, 1),
        "cache_reset": True,
    }


@app.post("/api/query")
def query(req: QueryRequest) -> Dict[str, Any]:
    session = get_session(req.session_id)

    question = (req.question or "").strip()
    if not question:
        raise HTTPException(400, "Ask a question first.")
    if session.index is None:
        raise HTTPException(409, "No index yet. Build the knowledge base first.")

    session.cache.configure(req.cache_ttl, req.cache_threshold)

    rerank_mode = req.rerank_mode if req.rerank_mode in {"llm", "cross_encoder", "off"} else "llm"
    if rerank_mode == "cross_encoder" and not cross_encoder_available():
        rerank_mode = "llm"

    try:
        return run_query(
            question=question,
            index=session.index,
            provider=session.provider,
            cache=session.cache,
            use_cache=req.use_cache,
            use_rewrite=req.use_rewrite,
            use_bm25=req.use_bm25,
            use_dense=req.use_dense,
            use_hyde=req.use_hyde,
            rerank_mode=rerank_mode,
            top_k_retrieval=max(2, min(20, req.top_k_retrieval)),
            top_k_context=max(1, min(10, req.top_k_context)),
        )
    except ProviderError as exc:
        raise HTTPException(502, str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


@app.get("/api/cache")
def cache_stats(session_id: str) -> Dict[str, Any]:
    return get_session(session_id).cache.stats()


@app.post("/api/cache/clear")
def cache_clear(req: SessionRef) -> Dict[str, Any]:
    session = get_session(req.session_id)
    removed = session.cache.clear()
    return {"removed": removed, "stats": session.cache.stats()}


@app.post("/api/cache/config")
def cache_config(req: CacheConfig) -> Dict[str, Any]:
    session = get_session(req.session_id)
    session.cache.configure(req.ttl_seconds, req.threshold)
    return session.cache.stats()


@app.get("/api/index")
def index_summary(session_id: str) -> Dict[str, Any]:
    session = get_session(session_id)
    if session.index is None:
        return {"built": False}
    return {"built": True, **session.index.summary()}


@app.get("/api/chunks")
def chunks(session_id: str) -> Dict[str, Any]:
    session = get_session(session_id)
    if session.index is None:
        return {"chunks": []}
    return {"chunks": [c.to_dict() for c in session.index.chunks]}


@app.exception_handler(ProviderError)
def provider_error_handler(_request: Any, exc: ProviderError) -> JSONResponse:
    return JSONResponse(status_code=502, content={"detail": str(exc)})
