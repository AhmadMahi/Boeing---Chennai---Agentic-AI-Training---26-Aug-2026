"""
Model providers for the Advanced RAG app.

Two interchangeable backends, both exposing the same tiny surface:

    provider.chat(messages, max_tokens=..., temperature=...) -> (text, usage)
    provider.embed(texts)                                    -> list[list[float]]

BoeingProvider mirrors the attached LangChain wrappers
(boeing_chat_model.py / boeing_embeddings.py) exactly:

    chat      POST /bcai-public-api/conversation
              headers: Authorization: basic <UDAL_PAT>
              payload: messages, model, stream=False, conversation_guid,
                       temperature, response_max_tokens
    embed     POST /bcai-public-api/embedding
              payload: {"input": [...], "model": ...}
              response data[] carries .index and .embedding and is re-sorted,
              because BCAI does not guarantee response order.
    tokens    POST /bcai-public-api/countTokens

It speaks HTTP directly instead of importing the wrappers so the app has no
LangChain dependency. Swap in the wrappers by replacing the two methods below
if your environment already has langchain-core installed.

OpenAIProvider uses gpt-4o-mini for chat and text-embedding-3-small for
embeddings, matching the Boeing model pair used in the notebook.
"""

from __future__ import annotations

import time
import uuid
from typing import Any, Dict, List, Sequence, Tuple

import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

Usage = Dict[str, int]
Message = Dict[str, str]


class ProviderError(RuntimeError):
    """Raised when a provider call fails after all retries."""


def _empty_usage() -> Usage:
    return {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}


def mask_secret(secret: str) -> str:
    """Render a credential for display without leaking it."""
    if not secret:
        return ""
    secret = secret.strip()
    if len(secret) <= 8:
        return "*" * len(secret)
    return f"{secret[:4]}{'*' * 6}{secret[-4:]}"


class BaseProvider:
    key: str = ""
    label: str = ""
    chat_model: str = ""
    embed_model: str = ""
    embed_batch_size: int = 128
    max_retries: int = 3
    timeout: float = 120.0
    verify_tls: bool = True

    def __init__(self, credential: str) -> None:
        credential = (credential or "").strip()
        if not credential:
            raise ProviderError("A credential is required.")
        self.credential = credential

    # ---------------------------------------------------------------- helpers

    def _headers(self) -> Dict[str, str]:
        raise NotImplementedError

    def _post(self, url: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        """POST with exponential backoff, mirroring the wrappers' retry loop."""
        last_error: str = ""
        for attempt in range(self.max_retries):
            try:
                response = requests.post(
                    url,
                    headers=self._headers(),
                    json=payload,
                    timeout=self.timeout,
                    verify=self.verify_tls,
                )
                if response.status_code == 200:
                    return response.json()

                body = (response.text or "")[:400]
                last_error = f"HTTP {response.status_code}: {body}"

                # Auth and payload errors will not fix themselves on retry.
                if response.status_code in (400, 401, 403, 404, 422):
                    break
            except requests.RequestException as exc:  # network / TLS / timeout
                last_error = f"{type(exc).__name__}: {exc}"

            if attempt < self.max_retries - 1:
                time.sleep(2 ** attempt)

        raise ProviderError(f"{self.label} request failed. {last_error}")

    # ------------------------------------------------------------------- api

    def chat(
        self,
        messages: Sequence[Message],
        max_tokens: int = 700,
        temperature: float = 0.2,
    ) -> Tuple[str, Usage]:
        raise NotImplementedError

    def embed(self, texts: Sequence[str]) -> List[List[float]]:
        raise NotImplementedError

    def ping(self) -> Dict[str, Any]:
        """Cheap round trip against both endpoints so bad keys fail loudly."""
        started = time.time()
        text, _ = self.chat(
            [{"role": "user", "content": "Reply with the single word: ready"}],
            max_tokens=8,
            temperature=0.0,
        )
        vector = self.embed(["connection check"])[0]
        return {
            "provider": self.key,
            "label": self.label,
            "chat_model": self.chat_model,
            "embed_model": self.embed_model,
            "chat_reply": (text or "").strip()[:40],
            "embedding_dim": len(vector),
            "latency_ms": round((time.time() - started) * 1000, 1),
        }


# --------------------------------------------------------------------- Boeing


class BoeingProvider(BaseProvider):
    key = "boeing"
    label = "Boeing BCAI"
    chat_model = "gpt-4o-mini"
    embed_model = "text-embedding-3-small"
    embed_batch_size = 250          # matches BoeingEmbeddings.batch_size
    max_retries = 3
    timeout = 300.0
    verify_tls = False              # Boeing internal TLS chain

    BASE = "https://bcai-test.web.boeing.com/bcai-public-api"
    CHAT_URL = f"{BASE}/conversation"
    EMBED_URL = f"{BASE}/embedding"
    TOKEN_URL = f"{BASE}/countTokens"

    def _headers(self) -> Dict[str, str]:
        return {
            "accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": f"basic {self.credential}",
        }

    def chat(
        self,
        messages: Sequence[Message],
        max_tokens: int = 700,
        temperature: float = 0.2,
    ) -> Tuple[str, Usage]:
        payload: Dict[str, Any] = {
            "messages": list(messages),
            "model": self.chat_model,
            "stream": False,
            "conversation_guid": str(uuid.uuid4()),
            "temperature": temperature,
            "response_max_tokens": max_tokens,
        }
        data = self._post(self.CHAT_URL, payload)

        choices = data.get("choices") or []
        if not choices:
            raise ProviderError("Boeing BCAI returned no choices.")
        content = (choices[0].get("message") or {}).get("content") or ""

        raw = data.get("usage") or {}
        usage: Usage = {
            "prompt_tokens": int(raw.get("prompt_tokens", 0) or 0),
            "completion_tokens": int(raw.get("completion_tokens", 0) or 0),
            "total_tokens": int(raw.get("total_tokens", 0) or 0),
        }
        return content, usage

    def embed(self, texts: Sequence[str]) -> List[List[float]]:
        out: List[List[float]] = []
        texts = list(texts)
        for start in range(0, len(texts), self.embed_batch_size):
            batch = texts[start : start + self.embed_batch_size]
            data = self._post(
                self.EMBED_URL, {"input": batch, "model": self.embed_model}
            )
            # Re-sort by index. BCAI does not guarantee response order.
            slots: List[Any] = [None] * len(batch)
            for item in data.get("data", []):
                idx = item.get("index")
                if isinstance(idx, int) and 0 <= idx < len(slots):
                    slots[idx] = item.get("embedding")
            if any(v is None for v in slots):
                raise ProviderError(
                    "Boeing embedding response had an index gap."
                )
            out.extend(slots)  # type: ignore[arg-type]
        return out  # type: ignore[return-value]


# --------------------------------------------------------------------- OpenAI


class OpenAIProvider(BaseProvider):
    key = "openai"
    label = "OpenAI"
    chat_model = "gpt-4o-mini"
    embed_model = "text-embedding-3-small"
    embed_batch_size = 128
    max_retries = 3
    timeout = 120.0
    verify_tls = True

    CHAT_URL = "https://api.openai.com/v1/chat/completions"
    EMBED_URL = "https://api.openai.com/v1/embeddings"

    def _headers(self) -> Dict[str, str]:
        return {
            "accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.credential}",
        }

    def chat(
        self,
        messages: Sequence[Message],
        max_tokens: int = 700,
        temperature: float = 0.2,
    ) -> Tuple[str, Usage]:
        payload = {
            "model": self.chat_model,
            "messages": list(messages),
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
        data = self._post(self.CHAT_URL, payload)

        choices = data.get("choices") or []
        if not choices:
            raise ProviderError("OpenAI returned no choices.")
        content = (choices[0].get("message") or {}).get("content") or ""

        raw = data.get("usage") or {}
        usage: Usage = {
            "prompt_tokens": int(raw.get("prompt_tokens", 0) or 0),
            "completion_tokens": int(raw.get("completion_tokens", 0) or 0),
            "total_tokens": int(raw.get("total_tokens", 0) or 0),
        }
        return content, usage

    def embed(self, texts: Sequence[str]) -> List[List[float]]:
        out: List[List[float]] = []
        texts = list(texts)
        for start in range(0, len(texts), self.embed_batch_size):
            batch = texts[start : start + self.embed_batch_size]
            data = self._post(
                self.EMBED_URL, {"input": batch, "model": self.embed_model}
            )
            rows = sorted(data.get("data", []), key=lambda r: r.get("index", 0))
            if len(rows) != len(batch):
                raise ProviderError("OpenAI embedding response was incomplete.")
            out.extend(row["embedding"] for row in rows)
        return out


PROVIDERS = {
    BoeingProvider.key: BoeingProvider,
    OpenAIProvider.key: OpenAIProvider,
}


def build_provider(kind: str, credential: str) -> BaseProvider:
    cls = PROVIDERS.get((kind or "").strip().lower())
    if cls is None:
        raise ProviderError(
            f"Unknown provider '{kind}'. Expected one of: {', '.join(PROVIDERS)}."
        )
    return cls(credential)
