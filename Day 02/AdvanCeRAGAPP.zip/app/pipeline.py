"""
Advanced RAG pipeline, ported from Advanced_RAG_Pipeline_Boeing_VSCode.ipynb.

Stages
------
0  Semantic cache lookup   exact string match, then cosine similarity with TTL
1  LLM query rewrite       cleaner, self-contained retrieval query
2  BM25                    sparse keyword retrieval over the rewritten query
3  Dense                   cosine similarity over provider embeddings
4  HyDE                    hypothetical passage, embedded and searched
5  RRF                     reciprocal rank fusion of the three ranked lists
6  Rerank                  LLM reranker, or sentence-transformers cross-encoder
7  Generation              grounded answer with inline [n] citations
8  Cache store             answer plus citations saved under a fresh timestamp

Dependency notes: BM25 and the recursive splitter are implemented here rather
than pulled from rank_bm25 / langchain-text-splitters, and the dense index is
an in-memory numpy matrix rather than ChromaDB. Same behaviour, no heavy
install, works on current Python.
"""

from __future__ import annotations

import json
import math
import re
import time
from collections import Counter
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np

from .providers import BaseProvider, ProviderError

RRF_K = 60
TOKEN_RE = re.compile(r"[a-z0-9]+")
CITE_RE = re.compile(r"\[(\d{1,2})\]")


# ---------------------------------------------------------------- chunking


def tokenize(text: str) -> List[str]:
    return TOKEN_RE.findall(text.lower())


def recursive_split(
    text: str,
    chunk_size: int = 300,
    chunk_overlap: int = 60,
    separators: Sequence[str] = ("\n\n", "\n", ". ", " ", ""),
) -> List[str]:
    """Recursive character splitter: split on the coarsest separator that fits,
    then merge the pieces back up to chunk_size with a trailing overlap."""

    def split(fragment: str, seps: Sequence[str]) -> List[str]:
        if len(fragment) <= chunk_size:
            return [fragment] if fragment.strip() else []

        sep, rest = "", ()
        for i, candidate in enumerate(seps):
            if candidate == "":
                break
            if candidate in fragment:
                sep, rest = candidate, seps[i + 1 :]
                break

        if sep == "":
            return [
                fragment[i : i + chunk_size]
                for i in range(0, len(fragment), chunk_size)
            ]

        pieces: List[str] = []
        parts = fragment.split(sep)
        for j, part in enumerate(parts):
            piece = part + (sep if j < len(parts) - 1 else "")
            if not piece.strip():
                continue
            if len(piece) > chunk_size:
                pieces.extend(split(piece, rest))
            else:
                pieces.append(piece)
        return pieces

    atoms = split(text, tuple(separators))

    # Merge atoms up to chunk_size, carrying a tail of at most chunk_overlap
    # characters into the next chunk. Dropping whole atoms off the front (rather
    # than slicing the joined string) keeps every emitted chunk <= chunk_size.
    chunks: List[str] = []
    window: List[str] = []
    total = 0
    for atom in atoms:
        if window and total + len(atom) > chunk_size:
            chunks.append("".join(window).strip())
            while window and (
                total > chunk_overlap or total + len(atom) > chunk_size
            ):
                total -= len(window[0])
                window.pop(0)
        window.append(atom)
        total += len(atom)
    if window:
        chunks.append("".join(window).strip())

    return [c for c in chunks if c.strip()]


@dataclass
class Chunk:
    id: int
    text: str
    source: str
    page: Optional[int] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "chunk_id": self.id,
            "source": self.source,
            "page": self.page,
            "chars": len(self.text),
            "text": self.text,
        }


# -------------------------------------------------------------------- BM25


class BM25:
    """BM25 Okapi. Same scoring function as rank_bm25's BM25Okapi."""

    def __init__(self, corpus: Sequence[Sequence[str]], k1: float = 1.5, b: float = 0.75):
        self.k1, self.b = k1, b
        self.corpus = [list(doc) for doc in corpus]
        self.n = len(self.corpus)
        self.doc_len = np.array([len(doc) for doc in self.corpus], dtype=float)
        self.avgdl = float(self.doc_len.mean()) if self.n else 0.0
        self.tf: List[Counter] = [Counter(doc) for doc in self.corpus]

        df: Counter = Counter()
        for terms in self.tf:
            df.update(terms.keys())
        self.idf = {
            term: math.log(1 + (self.n - freq + 0.5) / (freq + 0.5))
            for term, freq in df.items()
        }

    @property
    def vocab_size(self) -> int:
        return len(self.idf)

    def scores(self, query_tokens: Sequence[str]) -> np.ndarray:
        out = np.zeros(self.n, dtype=float)
        if not self.n:
            return out
        for term in query_tokens:
            idf = self.idf.get(term)
            if idf is None:
                continue
            freqs = np.array([tf.get(term, 0) for tf in self.tf], dtype=float)
            denom = freqs + self.k1 * (
                1 - self.b + self.b * self.doc_len / (self.avgdl or 1.0)
            )
            out += idf * (freqs * (self.k1 + 1)) / np.where(denom == 0, 1, denom)
        return out


# ------------------------------------------------------------- vector store


def l2_normalize(matrix: np.ndarray) -> np.ndarray:
    norms = np.linalg.norm(matrix, axis=1, keepdims=True)
    return matrix / np.where(norms == 0, 1.0, norms)


def cosine(a: np.ndarray, b: np.ndarray) -> float:
    denom = float(np.linalg.norm(a) * np.linalg.norm(b))
    return float(np.dot(a, b) / denom) if denom else 0.0


# ------------------------------------------------------------ semantic cache


@dataclass
class CacheEntry:
    question: str
    payload: Dict[str, Any]
    embedding: np.ndarray
    timestamp: float = field(default_factory=time.time)
    hits: int = 0

    def age(self) -> float:
        return time.time() - self.timestamp


class SemanticCache:
    """In-memory cache with TTL eviction, exact-match then cosine lookup."""

    def __init__(self, ttl_seconds: int = 300, threshold: float = 0.92):
        self.ttl = ttl_seconds
        self.threshold = threshold
        self._store: Dict[str, CacheEntry] = {}
        self.hits_exact = 0
        self.hits_semantic = 0
        self.misses = 0
        self.evictions = 0
        self.last_lookup: Dict[str, Any] = {"status": "none"}

    @staticmethod
    def _normalize(text: str) -> str:
        return " ".join(text.strip().lower().split())

    def configure(self, ttl_seconds: Optional[int], threshold: Optional[float]) -> None:
        if ttl_seconds is not None:
            self.ttl = max(5, int(ttl_seconds))
        if threshold is not None:
            self.threshold = min(0.999, max(0.5, float(threshold)))

    def evict_expired(self) -> List[str]:
        expired = [k for k, v in self._store.items() if v.age() > self.ttl]
        for key in expired:
            del self._store[key]
            self.evictions += 1
        return expired

    def get(
        self, question: str, provider: Optional[BaseProvider]
    ) -> Tuple[Optional[Dict[str, Any]], Dict[str, Any]]:
        evicted = self.evict_expired()
        norm = self._normalize(question)

        # 1. exact string match, no embedding call needed
        entry = self._store.get(norm)
        if entry is not None:
            entry.hits += 1
            self.hits_exact += 1
            detail = {
                "status": "exact_hit",
                "cache_type": "exact_string",
                "age_seconds": round(entry.age(), 1),
                "ttl_seconds": self.ttl,
                "matched_question": entry.question,
                "similarity": 1.0,
                "threshold": self.threshold,
                "evicted": evicted,
                "entry_hits": entry.hits,
            }
            self.last_lookup = detail
            return entry.payload, detail

        # 2. cosine similarity over stored question embeddings
        best_key, best_score = None, -1.0
        if self._store and provider is not None:
            try:
                query_vec = np.asarray(provider.embed([question])[0], dtype=float)
                for key, candidate in self._store.items():
                    score = cosine(query_vec, candidate.embedding)
                    if score > best_score:
                        best_key, best_score = key, score
            except ProviderError:
                best_key, best_score = None, -1.0

        if best_key is not None and best_score >= self.threshold:
            entry = self._store[best_key]
            entry.hits += 1
            self.hits_semantic += 1
            detail = {
                "status": "semantic_hit",
                "cache_type": "semantic_cosine",
                "age_seconds": round(entry.age(), 1),
                "ttl_seconds": self.ttl,
                "matched_question": entry.question,
                "similarity": round(best_score, 4),
                "threshold": self.threshold,
                "evicted": evicted,
                "entry_hits": entry.hits,
            }
            self.last_lookup = detail
            return entry.payload, detail

        self.misses += 1
        detail = {
            "status": "miss",
            "cache_type": None,
            "ttl_seconds": self.ttl,
            "similarity": round(best_score, 4) if best_score >= 0 else None,
            "threshold": self.threshold,
            "evicted": evicted,
            "matched_question": None,
        }
        self.last_lookup = detail
        return None, detail

    def put(
        self,
        question: str,
        payload: Dict[str, Any],
        provider: BaseProvider,
        embedding: Optional[np.ndarray] = None,
    ) -> None:
        if embedding is None:
            embedding = np.asarray(provider.embed([question])[0], dtype=float)
        self._store[self._normalize(question)] = CacheEntry(
            question=question, payload=payload, embedding=embedding
        )

    def clear(self) -> int:
        count = len(self._store)
        self._store.clear()
        self.last_lookup = {"status": "cleared"}
        return count

    def stats(self) -> Dict[str, Any]:
        self.evict_expired()
        total = self.hits_exact + self.hits_semantic + self.misses
        hits = self.hits_exact + self.hits_semantic
        return {
            "ttl_seconds": self.ttl,
            "threshold": self.threshold,
            "hits_exact": self.hits_exact,
            "hits_semantic": self.hits_semantic,
            "misses": self.misses,
            "evictions": self.evictions,
            "lookups": total,
            "hit_rate": round(hits / total * 100, 1) if total else 0.0,
            "live_entries": len(self._store),
            "last_lookup": self.last_lookup,
            "entries": [
                {
                    "question": entry.question,
                    "age_seconds": round(entry.age(), 1),
                    "expires_in": round(max(0.0, self.ttl - entry.age()), 1),
                    "hits": entry.hits,
                    "answer_preview": (entry.payload.get("answer") or "")[:160],
                }
                for entry in sorted(
                    self._store.values(), key=lambda e: e.timestamp, reverse=True
                )
            ],
        }


# ------------------------------------------------------------------- index


class RagIndex:
    """Chunks plus the two retrieval structures built over them."""

    def __init__(self, chunks: List[Chunk], embeddings: np.ndarray, meta: Dict[str, Any]):
        self.chunks = chunks
        self.matrix = l2_normalize(np.asarray(embeddings, dtype=float))
        self.bm25 = BM25([tokenize(c.text) for c in chunks])
        self.meta = meta

    # -- retrievers -------------------------------------------------------

    def bm25_retrieve(self, query: str, top_k: int) -> List[Tuple[Chunk, float]]:
        scores = self.bm25.scores(tokenize(query))
        order = np.argsort(-scores)[:top_k]
        return [(self.chunks[i], float(scores[i])) for i in order if scores[i] > 0]

    def dense_retrieve(
        self, query_vector: Sequence[float], top_k: int
    ) -> List[Tuple[Chunk, float]]:
        vec = np.asarray(query_vector, dtype=float)
        norm = np.linalg.norm(vec)
        if norm:
            vec = vec / norm
        scores = self.matrix @ vec
        order = np.argsort(-scores)[:top_k]
        return [(self.chunks[i], float(scores[i])) for i in order]

    def summary(self) -> Dict[str, Any]:
        by_source: Dict[str, int] = {}
        for chunk in self.chunks:
            by_source[chunk.source] = by_source.get(chunk.source, 0) + 1
        return {
            **self.meta,
            "chunks": len(self.chunks),
            "vector_dim": int(self.matrix.shape[1]) if self.matrix.size else 0,
            "bm25_vocab": self.bm25.vocab_size,
            "sources": [{"name": k, "chunks": v} for k, v in by_source.items()],
        }


def build_index(
    documents: Sequence[Dict[str, Any]],
    provider: BaseProvider,
    chunk_size: int = 300,
    chunk_overlap: int = 60,
    max_chunks: int = 400,
) -> RagIndex:
    """documents: [{"source": str, "text": str, "page": int | None}, ...]"""
    chunks: List[Chunk] = []
    for doc in documents:
        for piece in recursive_split(doc["text"], chunk_size, chunk_overlap):
            if len(chunks) >= max_chunks:
                break
            chunks.append(
                Chunk(
                    id=len(chunks),
                    text=piece,
                    source=doc.get("source", "document"),
                    page=doc.get("page"),
                )
            )

    if not chunks:
        raise ValueError("No text found to index.")

    started = time.time()
    vectors = provider.embed([c.text for c in chunks])
    meta = {
        "chunk_size": chunk_size,
        "chunk_overlap": chunk_overlap,
        "embed_model": provider.embed_model,
        "provider": provider.key,
        "embed_ms": round((time.time() - started) * 1000, 1),
        "built_at": time.time(),
    }
    return RagIndex(chunks, np.asarray(vectors, dtype=float), meta)


# ------------------------------------------------------------------- RRF


def reciprocal_rank_fusion(
    ranked_lists: Sequence[Tuple[str, List[Tuple[Chunk, float]]]],
    k_constant: int = RRF_K,
    top_k: int = 15,
) -> List[Dict[str, Any]]:
    """Fuse named ranked lists. Returns candidate records carrying the rank and
    raw score each retriever gave them, which is what the UI cites."""
    fused: Dict[int, Dict[str, Any]] = {}

    for name, ranked in ranked_lists:
        for rank, (chunk, score) in enumerate(ranked, start=1):
            record = fused.setdefault(
                chunk.id,
                {"chunk": chunk, "rrf_score": 0.0, "retrievers": {}},
            )
            record["rrf_score"] += 1.0 / (k_constant + rank)
            record["retrievers"][name] = {"rank": rank, "score": round(score, 5)}

    ordered = sorted(fused.values(), key=lambda r: r["rrf_score"], reverse=True)
    return ordered[:top_k]


# ---------------------------------------------------------------- reranking

_CROSS_ENCODER: Any = None
_CROSS_ENCODER_STATE = "unloaded"
CROSS_ENCODER_MODEL = "cross-encoder/ms-marco-MiniLM-L-6-v2"


def cross_encoder_available() -> bool:
    try:
        import sentence_transformers  # noqa: F401
        return True
    except Exception:
        return False


def _load_cross_encoder() -> Any:
    global _CROSS_ENCODER, _CROSS_ENCODER_STATE
    if _CROSS_ENCODER is not None or _CROSS_ENCODER_STATE == "unavailable":
        return _CROSS_ENCODER
    try:
        from sentence_transformers import CrossEncoder

        _CROSS_ENCODER = CrossEncoder(CROSS_ENCODER_MODEL)
        _CROSS_ENCODER_STATE = "ready"
    except Exception:
        _CROSS_ENCODER_STATE = "unavailable"
    return _CROSS_ENCODER


RERANK_PROMPT = """You are a retrieval reranker.

Score how useful each passage is for answering the question, from 0 (useless)
to 10 (directly answers it). Judge each passage on its own.

Question: {question}

Passages:
{passages}

Return ONLY a JSON array, one object per passage, no prose:
[{{"id": <passage id>, "score": <number 0-10>}}]"""


def _llm_rerank(
    provider: BaseProvider,
    question: str,
    candidates: List[Dict[str, Any]],
    top_k: int,
) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    listing = "\n\n".join(
        f"[id {i}] {c['chunk'].text[:700]}" for i, c in enumerate(candidates)
    )
    prompt = RERANK_PROMPT.format(question=question, passages=listing)

    text, usage = provider.chat(
        [{"role": "user", "content": prompt}], max_tokens=400, temperature=0.0
    )

    match = re.search(r"\[.*\]", text, re.S)
    if not match:
        raise ValueError("reranker returned no JSON array")
    scored = json.loads(match.group(0))

    lookup: Dict[int, float] = {}
    for row in scored:
        try:
            lookup[int(row["id"])] = float(row["score"])
        except (KeyError, TypeError, ValueError):
            continue
    if not lookup:
        raise ValueError("reranker returned no usable scores")

    for i, candidate in enumerate(candidates):
        candidate["rerank_score"] = lookup.get(i)

    ranked = sorted(
        candidates,
        key=lambda c: (c.get("rerank_score") is not None, c.get("rerank_score") or 0.0),
        reverse=True,
    )
    meta = {
        "reranker": "llm",
        "model": provider.chat_model,
        "scored": len(lookup),
        "usage": usage,
    }
    return ranked[:top_k], meta


def _cross_encoder_rerank(
    question: str, candidates: List[Dict[str, Any]], top_k: int
) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    model = _load_cross_encoder()
    if model is None:
        raise ValueError("sentence-transformers is not installed")

    pairs = [(question, c["chunk"].text) for c in candidates]
    scores = model.predict(pairs)
    for candidate, score in zip(candidates, scores):
        candidate["rerank_score"] = round(float(score), 4)

    ranked = sorted(candidates, key=lambda c: c["rerank_score"], reverse=True)
    return ranked[:top_k], {"reranker": "cross_encoder", "model": CROSS_ENCODER_MODEL}


# --------------------------------------------------------------- prompts

REWRITE_PROMPT = """You are an expert at improving search queries for document retrieval.

Rewrite the user question below into a clear, specific, standalone search query.
Remove conversational filler, expand obvious abbreviations, and make the query
self-contained. Return ONLY the rewritten query, with no explanation.

Original question: {question}

Rewritten query:"""

HYDE_PROMPT = """Write a short, factual passage of 2 to 4 sentences that would
directly answer the following question. Do not reference the question itself.
Write as if you are the document being retrieved.

Question: {question}

Hypothetical passage:"""

ANSWER_PROMPT = """You are a precise and helpful assistant.

Answer the question using ONLY the context passages below.
Cite every claim with the bracketed passage number it came from, like [1] or [2][3].
If the passages do not contain enough information, reply exactly:
"I cannot answer based on the provided context."
Never invent facts and never cite a passage number that is not listed.

Context passages, most relevant first:
{context}

Question: {question}

Answer:"""


# ------------------------------------------------------------------ runner


class StageLog:
    def __init__(self) -> None:
        self.stages: List[Dict[str, Any]] = []

    def add(
        self,
        name: str,
        status: str,
        detail: str = "",
        ms: Optional[float] = None,
        extra: Optional[Dict[str, Any]] = None,
    ) -> None:
        self.stages.append(
            {
                "name": name,
                "status": status,
                "detail": detail,
                "ms": round(ms, 1) if ms is not None else None,
                **(extra or {}),
            }
        )


def run_query(
    *,
    question: str,
    index: RagIndex,
    provider: BaseProvider,
    cache: SemanticCache,
    use_cache: bool = True,
    use_rewrite: bool = True,
    use_bm25: bool = True,
    use_dense: bool = True,
    use_hyde: bool = True,
    rerank_mode: str = "llm",
    top_k_retrieval: int = 8,
    top_k_context: int = 4,
) -> Dict[str, Any]:
    """Run the full pipeline and return the answer plus a complete trace."""
    t_start = time.time()
    log = StageLog()
    usage_total = {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}

    def track(usage: Dict[str, int]) -> None:
        for key in usage_total:
            usage_total[key] += int(usage.get(key, 0) or 0)

    # -- Stage 0: cache -------------------------------------------------
    cache_detail: Dict[str, Any] = {"status": "disabled"}
    if use_cache:
        t0 = time.time()
        payload, cache_detail = cache.get(question, provider)
        log.add(
            "Semantic cache",
            "hit" if payload else "miss",
            {
                "exact_hit": "Exact string match",
                "semantic_hit": f"Cosine {float(cache_detail.get('similarity') or 0) * 100:.1f}% "
                                f"vs threshold {cache_detail.get('threshold')}",
                "miss": "No entry above threshold",
            }.get(cache_detail.get("status", ""), ""),
            (time.time() - t0) * 1000,
            {"cache": cache_detail},
        )
        if payload:
            result = dict(payload)
            result.update(
                {
                    "question": question,
                    "served_from_cache": True,
                    "cache": {**cache_detail, "stats": cache.stats()},
                    "stages": log.stages,
                    "usage": usage_total,
                    "total_ms": round((time.time() - t_start) * 1000, 1),
                }
            )
            # copy, so replaying a hit never mutates the stored payload
            result["citations"] = [
                {**c, "from_cache": True} for c in payload.get("citations", [])
            ]
            return result
    else:
        log.add("Semantic cache", "skipped", "Cache disabled for this query")

    # -- Stage 1: query rewrite -----------------------------------------
    retrieval_query = question
    rewritten: Optional[str] = None
    if use_rewrite:
        t0 = time.time()
        try:
            text, usage = provider.chat(
                [{"role": "user", "content": REWRITE_PROMPT.format(question=question)}],
                max_tokens=120,
                temperature=0.0,
            )
            track(usage)
            rewritten = text.strip().strip('"')
            if rewritten:
                retrieval_query = rewritten
            log.add("Query rewrite", "done", rewritten or "", (time.time() - t0) * 1000)
        except ProviderError as exc:
            log.add("Query rewrite", "error", str(exc), (time.time() - t0) * 1000)
    else:
        log.add("Query rewrite", "skipped", "Using the original question")

    ranked_lists: List[Tuple[str, List[Tuple[Chunk, float]]]] = []

    # -- Stage 2: BM25 ---------------------------------------------------
    if use_bm25:
        t0 = time.time()
        bm25_hits = index.bm25_retrieve(retrieval_query, top_k_retrieval)
        ranked_lists.append(("bm25", bm25_hits))
        log.add(
            "BM25 sparse retrieval",
            "done",
            f"{len(bm25_hits)} candidates over {index.bm25.vocab_size} terms",
            (time.time() - t0) * 1000,
        )
    else:
        log.add("BM25 sparse retrieval", "skipped", "Disabled")

    # -- Stage 3: dense --------------------------------------------------
    if use_dense:
        t0 = time.time()
        try:
            query_vec = provider.embed([retrieval_query])[0]
            dense_hits = index.dense_retrieve(query_vec, top_k_retrieval)
            ranked_lists.append(("dense", dense_hits))
            log.add(
                "Dense vector retrieval",
                "done",
                f"{len(dense_hits)} candidates, {provider.embed_model}",
                (time.time() - t0) * 1000,
            )
        except ProviderError as exc:
            log.add("Dense vector retrieval", "error", str(exc), (time.time() - t0) * 1000)
    else:
        log.add("Dense vector retrieval", "skipped", "Disabled")

    # -- Stage 4: HyDE ---------------------------------------------------
    hyde_passage: Optional[str] = None
    if use_hyde:
        t0 = time.time()
        try:
            text, usage = provider.chat(
                [{"role": "user", "content": HYDE_PROMPT.format(question=question)}],
                max_tokens=200,
                temperature=0.3,
            )
            track(usage)
            hyde_passage = text.strip()
            hyde_vec = provider.embed([hyde_passage])[0]
            hyde_hits = index.dense_retrieve(hyde_vec, top_k_retrieval)
            ranked_lists.append(("hyde", hyde_hits))
            log.add(
                "HyDE retrieval",
                "done",
                f"{len(hyde_hits)} candidates from a {len(hyde_passage)} char hypothetical passage",
                (time.time() - t0) * 1000,
                {"hypothetical_passage": hyde_passage},
            )
        except ProviderError as exc:
            log.add("HyDE retrieval", "error", str(exc), (time.time() - t0) * 1000)
    else:
        log.add("HyDE retrieval", "skipped", "Disabled")

    if not ranked_lists:
        raise ValueError("Every retriever is disabled. Enable at least one.")

    # -- Stage 5: RRF ----------------------------------------------------
    t0 = time.time()
    candidates = reciprocal_rank_fusion(
        ranked_lists, k_constant=RRF_K, top_k=max(top_k_context, top_k_retrieval)
    )
    log.add(
        "Reciprocal rank fusion",
        "done",
        f"{len(candidates)} unique candidates from {len(ranked_lists)} ranked lists, k={RRF_K}",
        (time.time() - t0) * 1000,
    )

    if not candidates:
        answer = "I cannot answer based on the provided context."
        return {
            "question": question,
            "rewritten_query": rewritten,
            "hypothetical_passage": hyde_passage,
            "answer": answer,
            "citations": [],
            "served_from_cache": False,
            "cache": {**cache_detail, "stats": cache.stats()},
            "stages": log.stages,
            "usage": usage_total,
            "rerank": {"reranker": "none"},
            "total_ms": round((time.time() - t_start) * 1000, 1),
        }

    # -- Stage 6: rerank -------------------------------------------------
    rerank_meta: Dict[str, Any] = {"reranker": "none"}
    t0 = time.time()
    if rerank_mode == "off":
        selected = candidates[:top_k_context]
        log.add("Rerank", "skipped", "Keeping RRF order", (time.time() - t0) * 1000)
    else:
        try:
            if rerank_mode == "cross_encoder":
                selected, rerank_meta = _cross_encoder_rerank(
                    question, candidates, top_k_context
                )
            else:
                selected, rerank_meta = _llm_rerank(
                    provider, question, candidates, top_k_context
                )
                track(rerank_meta.pop("usage", {}) or {})
            log.add(
                "Rerank",
                "done",
                f"{rerank_meta.get('reranker')} scored {len(candidates)} candidates, kept {len(selected)}",
                (time.time() - t0) * 1000,
                {"model": rerank_meta.get("model")},
            )
        except (ProviderError, ValueError, json.JSONDecodeError) as exc:
            selected = candidates[:top_k_context]
            rerank_meta = {"reranker": "rrf_fallback", "error": str(exc)}
            log.add(
                "Rerank",
                "error",
                f"Fell back to RRF order. {exc}",
                (time.time() - t0) * 1000,
            )

    # -- Stage 7: generation ---------------------------------------------
    context_text = "\n\n---\n\n".join(
        f"[{i}] (source: {c['chunk'].source}"
        + (f", page {c['chunk'].page}" if c["chunk"].page else "")
        + f")\n{c['chunk'].text}"
        for i, c in enumerate(selected, start=1)
    )

    t0 = time.time()
    answer, usage = provider.chat(
        [
            {
                "role": "system",
                "content": "You answer strictly from the supplied context and always cite passage numbers.",
            },
            {
                "role": "user",
                "content": ANSWER_PROMPT.format(
                    context=context_text, question=question
                ),
            },
        ],
        max_tokens=700,
        temperature=0.2,
    )
    track(usage)
    answer = answer.strip()
    log.add(
        "Augmented generation",
        "done",
        f"{provider.chat_model}, {len(selected)} passages in context",
        (time.time() - t0) * 1000,
    )

    cited = {int(n) for n in CITE_RE.findall(answer)}
    citations: List[Dict[str, Any]] = []
    for i, record in enumerate(selected, start=1):
        chunk: Chunk = record["chunk"]
        citations.append(
            {
                "n": i,
                **chunk.to_dict(),
                "rrf_score": round(record["rrf_score"], 5),
                "rerank_score": record.get("rerank_score"),
                "retrievers": record["retrievers"],
                "cited_in_answer": i in cited,
                "from_cache": False,
            }
        )

    result = {
        "question": question,
        "rewritten_query": rewritten,
        "hypothetical_passage": hyde_passage,
        "answer": answer,
        "citations": citations,
        "candidates_considered": len(candidates),
        "rerank": rerank_meta,
        "served_from_cache": False,
        "provider": {
            "key": provider.key,
            "label": provider.label,
            "chat_model": provider.chat_model,
            "embed_model": provider.embed_model,
        },
    }

    # -- Stage 8: cache store --------------------------------------------
    if use_cache:
        t0 = time.time()
        try:
            cache.put(question, dict(result), provider)
            log.add(
                "Cache store",
                "done",
                f"Stored with TTL {cache.ttl}s",
                (time.time() - t0) * 1000,
            )
        except ProviderError as exc:
            log.add("Cache store", "error", str(exc), (time.time() - t0) * 1000)

    result.update(
        {
            "cache": {**cache_detail, "stats": cache.stats()},
            "stages": log.stages,
            "usage": usage_total,
            "total_ms": round((time.time() - t_start) * 1000, 1),
        }
    )
    return result
