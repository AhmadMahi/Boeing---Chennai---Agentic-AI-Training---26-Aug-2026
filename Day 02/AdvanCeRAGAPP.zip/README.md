# Advanced RAG App

A single-page FastAPI app that runs the pipeline from
`Advanced_RAG_Pipeline_Boeing_VSCode.ipynb` interactively, with the credential
entered from the front end. Two backends are supported and switchable in the UI:

| Backend | Credential | Generation | Embeddings |
|---|---|---|---|
| Boeing BCAI | UDAL PAT | `gpt-4o-mini` | `text-embedding-3-small` |
| OpenAI | API key | `gpt-4o-mini` | `text-embedding-3-small` |

Every answer is returned with its **citations** (which passage, from which
source, and the rank plus raw score each retriever gave it) and the full
**cache detail** (hit type, cosine similarity, age against TTL, hit rate,
live entries with a TTL countdown).

## Pipeline

```
Question
  |
  0  Semantic cache      exact string match, then cosine similarity, TTL evicted
  1  LLM query rewrite   standalone retrieval query
  |
  +--2  BM25             sparse keyword retrieval on the rewritten query
  +--3  Dense            cosine over provider embeddings
  +--4  HyDE             hypothetical answer, embedded, then dense search
  |
  5  RRF fusion          1 / (60 + rank) summed across the three ranked lists
  6  Rerank              LLM reranker, or cross-encoder, or off
  7  Generation          grounded answer with inline [n] citations
  8  Cache store         answer and citations saved with a fresh timestamp
```

Each stage can be toggled from the sidebar, and every stage reports its status
and latency in the Pipeline tab, so you can see exactly what each technique
contributed to a given answer.

## Files

```
requirements.txt
.env.example            optional pre-filled keys
selftest.py             42 offline checks, no credential needed
app/providers.py        Boeing BCAI and OpenAI clients
app/pipeline.py         chunking, BM25, dense, HyDE, RRF, rerank, cache
app/main.py             FastAPI endpoints and session handling
app/static/index.html   the entire UI
```

## Install and run

Python 3.10 to 3.13 is recommended. On Python 3.14 the FastAPI and pydantic
wheels may not be available yet.

```bash
python3.13 -m venv .venv
.venv/bin/pip install -r requirements.txt
.venv/bin/uvicorn app.main:app --reload --port 8000
```

Then open http://127.0.0.1:8000

## Using it

1. **Provider and credentials.** Pick Boeing BCAI or OpenAI, paste the key, and
   press Connect. The app calls both the chat and the embedding endpoint before
   accepting the credential, so a wrong key fails immediately instead of at
   query time. If `UDAL_PAT` or `OPENAI_API_KEY` is set in the environment, a
   link appears to use it without typing anything.
2. **Knowledge base.** Keep the built-in sample corpus, and optionally add up to
   5 files (`.pdf`, `.txt`, `.md`, `.csv`, `.json`, 2 MB each) or pasted text.
   Set chunk size and overlap, then Build index. PDFs are split per page, so
   citations carry a page number.
3. **Retrieval pipeline.** Toggle rewrite, BM25, dense, and HyDE, choose the
   rerank stage, and set how many candidates each retriever returns and how many
   passages reach the model.
4. **Semantic cache.** Set TTL and the similarity threshold, or clear the cache.

Ask a question. The answer's `[1]` markers are clickable and jump to the
matching citation card.

## Where to look for what

- **Citations tab.** One card per passage sent to the model: source, page,
  chunk id, the text itself, the rank and raw score from BM25, dense and HyDE,
  the fused RRF score, the rerank score, and whether the answer actually cited
  it. A passage that was retrieved but not cited is labelled as such, which is
  the fastest way to spot retrieval that pulled in noise.
- **Pipeline tab.** The rewritten query, the HyDE hypothetical passage, and
  every stage with its status, detail line and latency bar, plus token usage.
- **Cache tab.** The last lookup as exact hit, semantic hit with its similarity
  percentage, or miss with the best similarity it found. Below that: hit rate,
  exact and semantic hit counts, misses, TTL evictions, live entries, and a
  table of cached questions with an age and expiry countdown.
- **Chunks tab.** Everything the retrievers search over.

## API

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/bootstrap` | Provider metadata, limits, cross-encoder availability |
| POST | `/api/connect` | Validate a credential, open a session |
| POST | `/api/ingest` | Multipart: files, pasted text, sample flag, chunk settings |
| POST | `/api/query` | Run the pipeline, return answer, citations, stages, cache |
| GET | `/api/cache` | Cache statistics and live entries |
| POST | `/api/cache/clear` | Drop all entries |
| POST | `/api/cache/config` | Change TTL and threshold |
| GET | `/api/index`, `/api/chunks` | Index summary, indexed chunks |
| POST | `/api/disconnect` | Drop the credential from memory |

## Credential handling

The key is posted once, held in server memory keyed by an opaque session id,
and never written to disk or logged. Responses only ever contain a masked form
such as `sk-a******7890`. Close session drops it immediately, and idle sessions
are reaped after 4 hours. Because the credential lives in process memory, run
one server per user rather than sharing an instance.

## Differences from the notebook, and why

| Notebook | This app | Reason |
|---|---|---|
| `BoeingChatModel` / `BoeingEmbeddings` LangChain wrappers | Direct HTTP in `app/providers.py` | Same endpoints, headers, payload keys, retry and backoff, and embedding index re-sort, without a LangChain dependency. Swap the wrappers back in by replacing `BoeingProvider.chat` and `.embed`. |
| ChromaDB | In-memory numpy matrix | The app indexes a few hundred chunks per session, so a persistent vector database adds install weight and no benefit. |
| `rank_bm25` | BM25 Okapi implemented in `app/pipeline.py` | Identical scoring function, one less dependency. |
| `langchain_text_splitters` | Recursive splitter in `app/pipeline.py` | Same separator cascade and overlap behaviour. Verified never to exceed the configured chunk size. |
| Cross-encoder rerank via `sentence-transformers` | LLM reranker by default | `sentence-transformers` pulls in torch, which has no wheel on recent Python. The cross-encoder option is still there and is used automatically if the package is importable. |

## Self-test

Runs the whole app against a deterministic mock provider, so no credential is
needed. It covers indexing, chunk size limits, the nine pipeline stages, per
retriever citation scores, exact and semantic cache hits, TTL countdown, stage
toggles, and session teardown.

```bash
.venv/bin/pip install httpx
.venv/bin/python selftest.py
```
