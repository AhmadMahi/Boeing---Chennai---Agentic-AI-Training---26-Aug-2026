"""
Offline self-test. Exercises the whole app with a deterministic mock provider,
so no UDAL PAT or OpenAI key is needed.

    .venv/bin/python selftest.py
"""

from __future__ import annotations

import hashlib
import json
import re
import sys
from typing import Any, Dict, List, Sequence, Tuple

from fastapi.testclient import TestClient

from app import main as srv
from app.providers import BaseProvider

DIM = 256


class MockProvider(BaseProvider):
    """Hashed bag-of-words embeddings and rule-based chat replies."""

    key = "boeing"
    label = "Mock BCAI"
    chat_model = "gpt-4o-mini"
    embed_model = "text-embedding-3-small"

    def __init__(self, credential: str = "mock") -> None:
        self.credential = credential
        self.calls: Dict[str, int] = {"chat": 0, "embed": 0}

    def embed(self, texts: Sequence[str]) -> List[List[float]]:
        self.calls["embed"] += 1
        out = []
        for text in texts:
            vec = [0.0] * DIM
            for token in re.findall(r"[a-z0-9]+", text.lower()):
                h = int(hashlib.md5(token.encode()).hexdigest(), 16)
                vec[h % DIM] += 1.0
            out.append(vec)
        return out

    def chat(self, messages, max_tokens=700, temperature=0.2) -> Tuple[str, Dict[str, int]]:
        self.calls["chat"] += 1
        prompt = "\n".join(m["content"] for m in messages)
        usage = {"prompt_tokens": 100, "completion_tokens": 20, "total_tokens": 120}

        if "Rewritten query:" in prompt:
            question = prompt.split("Original question:")[1].split("Rewritten query:")[0]
            return question.strip().rstrip("?") + " definition purpose", usage
        if "Hypothetical passage:" in prompt:
            return (
                "Retrieval augmented generation retrieves relevant passages from a "
                "knowledge base and gives them to the model as context before it answers.",
                usage,
            )
        if "retrieval reranker" in prompt:
            ids = [int(i) for i in re.findall(r"\[id (\d+)\]", prompt)]
            rows = [{"id": i, "score": round(10 - i * 0.7, 2)} for i in ids]
            return json.dumps(rows), usage
        if "Context passages" in prompt:
            n = len(re.findall(r"^\[\d+\] \(source:", prompt, re.M))
            cites = "".join(f"[{i}]" for i in range(1, min(n, 2) + 1))
            return f"Mock grounded answer drawn from the supplied context {cites}.", usage
        return "ready", usage

    def ping(self) -> Dict[str, Any]:
        return {
            "provider": self.key, "label": self.label,
            "chat_model": self.chat_model, "embed_model": self.embed_model,
            "chat_reply": "ready", "embedding_dim": DIM, "latency_ms": 1.0,
        }


MOCK = MockProvider()
srv.build_provider = lambda kind, credential: MOCK  # type: ignore[assignment]

client = TestClient(srv.app)
failures: List[str] = []


def check(label: str, condition: bool, detail: str = "") -> None:
    print(f"  {'PASS' if condition else 'FAIL'}  {label}" + (f"  ({detail})" if detail else ""))
    if not condition:
        failures.append(label)


print("\n[1] page and bootstrap")
r = client.get("/")
check("GET / serves the UI", r.status_code == 200 and "Advanced RAG" in r.text)
boot = client.get("/api/bootstrap").json()
check("bootstrap lists both providers", {p["key"] for p in boot["providers"]} == {"boeing", "openai"})
check("limits are exposed", boot["limits"]["max_files"] == srv.MAX_FILES)

print("\n[2] connect")
r = client.post("/api/connect", json={"provider": "boeing", "credential": "PAT-abcdef123456"})
check("connect returns 200", r.status_code == 200, r.text[:120])
sid = r.json()["session_id"]
check("credential is masked in the response", r.json()["provider"]["credential_masked"] == "PAT-******3456")
check("no session id leaks the credential", "abcdef" not in json.dumps(r.json()))
check("query without an index is rejected",
      client.post("/api/query", json={"session_id": sid, "question": "hi"}).status_code == 409)
check("bad session is rejected",
      client.post("/api/query", json={"session_id": "nope", "question": "hi"}).status_code == 401)

print("\n[3] ingest")
r = client.post("/api/ingest", data={"session_id": sid, "use_sample": "true", "chunk_size": "300", "chunk_overlap": "60"})
check("sample corpus indexes", r.status_code == 200, r.text[:160])
ix = r.json()["index"]
check("chunks were produced", ix["chunks"] > 10, f"{ix['chunks']} chunks")
check("vectors have the right dim", ix["vector_dim"] == DIM)
check("bm25 vocabulary built", ix["bm25_vocab"] > 100, f"{ix['bm25_vocab']} terms")
check("both sample sources present", len(ix["sources"]) == 2)
chunk_chars = [c["chars"] for c in client.get(f"/api/chunks?session_id={sid}").json()["chunks"]]
check("no chunk exceeds chunk_size", max(chunk_chars) <= 300, f"max {max(chunk_chars)} chars")

r = client.post("/api/ingest", data={"session_id": sid, "use_sample": "false", "text": "  "})
check("empty ingest is rejected", r.status_code == 400)

files = [("files", ("notes.txt", b"Torque the fitting to 42 newton metres before inspection.", "text/plain"))]
r = client.post("/api/ingest", data={"session_id": sid, "use_sample": "true"}, files=files)
check("uploaded file is merged in", r.status_code == 200 and any(s["name"] == "notes.txt" for s in r.json()["index"]["sources"]), r.text[:120])

print("\n[4] query, full pipeline")
body = {
    "session_id": sid, "question": "What is RAG and why is it useful?",
    "use_cache": True, "rerank_mode": "llm", "top_k_retrieval": 8, "top_k_context": 4,
    "cache_ttl": 300, "cache_threshold": 0.75,
}
r = client.post("/api/query", json=body)
check("query returns 200", r.status_code == 200, r.text[:200])
q1 = r.json()
names = [s["name"] for s in q1["stages"]]
check("all stages ran", names == [
    "Semantic cache", "Query rewrite", "BM25 sparse retrieval", "Dense vector retrieval",
    "HyDE retrieval", "Reciprocal rank fusion", "Rerank", "Augmented generation", "Cache store",
], str(names))
check("no stage errored", all(s["status"] != "error" for s in q1["stages"]),
      str([(s["name"], s["detail"]) for s in q1["stages"] if s["status"] == "error"]))
check("first lookup is a miss", q1["cache"]["status"] == "miss")
check("query was rewritten", bool(q1["rewritten_query"]))
check("hyde passage generated", bool(q1["hypothetical_passage"]))
check("citations returned", len(q1["citations"]) == 4, str(len(q1["citations"])))
check("citations carry per-retriever ranks",
      all("bm25" in c["retrievers"] or "dense" in c["retrievers"] or "hyde" in c["retrievers"] for c in q1["citations"]))
check("at least one retriever agreed on top passage", len(q1["citations"][0]["retrievers"]) >= 1)
check("rerank scores attached", all(c["rerank_score"] is not None for c in q1["citations"]))
check("answer cites passages", any(c["cited_in_answer"] for c in q1["citations"]))
check("token usage aggregated", q1["usage"]["total_tokens"] > 0, str(q1["usage"]))
check("provider metadata returned", q1["provider"]["chat_model"] == "gpt-4o-mini")

print("\n[5] cache behaviour")
r2 = client.post("/api/query", json=body).json()
check("identical question is an exact hit", r2["cache"]["status"] == "exact_hit", r2["cache"]["status"])
check("exact hit is served from cache", r2["served_from_cache"] is True)
check("exact hit replays citations", len(r2["citations"]) == 4 and all(c["from_cache"] for c in r2["citations"]))
check("exact hit is fast", r2["total_ms"] < q1["total_ms"], f'{r2["total_ms"]} vs {q1["total_ms"]} ms')
check("exact hit spends no tokens", r2["usage"]["total_tokens"] == 0)

para = dict(body, question="What is RAG and why is it valuable?")
r3 = client.post("/api/query", json=para).json()
check("paraphrase is a semantic hit", r3["cache"]["status"] == "semantic_hit", r3["cache"]["status"])
check("semantic hit reports similarity", 0.75 <= r3["cache"]["similarity"] < 1.0, str(r3["cache"].get("similarity")))
check("semantic hit names the matched question", r3["cache"]["matched_question"] == body["question"])

st = client.get(f"/api/cache?session_id={sid}").json()
check("stats count one exact and one semantic hit", st["hits_exact"] == 1 and st["hits_semantic"] == 1, str(st))
check("hit rate computed", st["hit_rate"] > 60, str(st["hit_rate"]))
check("entries expose TTL countdown", st["entries"] and st["entries"][0]["expires_in"] <= st["ttl_seconds"])

low = dict(body, question="Totally unrelated question about hydraulic actuator seals", cache_threshold=0.99)
r4 = client.post("/api/query", json=low).json()
check("below-threshold lookup misses", r4["cache"]["status"] == "miss")

r5 = client.post("/api/cache/clear", json={"session_id": sid}).json()
check("cache clears", r5["stats"]["live_entries"] == 0, str(r5["removed"]))

print("\n[6] toggles and edge cases")
off = dict(body, use_cache=False, use_hyde=False, use_rewrite=False, use_bm25=False, rerank_mode="off",
           question="Why combine BM25 with dense retrieval?")
r6 = client.post("/api/query", json=off).json()
stat = {s["name"]: s["status"] for s in r6["stages"]}
check("disabled stages report skipped",
      stat["Semantic cache"] == "skipped" and stat["Query rewrite"] == "skipped"
      and stat["BM25 sparse retrieval"] == "skipped" and stat["HyDE retrieval"] == "skipped"
      and stat["Rerank"] == "skipped", str(stat))
check("dense-only still answers", len(r6["citations"]) > 0 and bool(r6["answer"]))
rrf6 = [c["rrf_score"] for c in r6["citations"]]
check("rerank off keeps RRF order", rrf6 == sorted(rrf6, reverse=True), str(rrf6))
check("nothing cached when cache is off",
      client.get(f"/api/cache?session_id={sid}").json()["live_entries"] == 0)

all_off = dict(body, use_bm25=False, use_dense=False, use_hyde=False)
check("all retrievers off is a 400", client.post("/api/query", json=all_off).status_code == 400)
check("empty question is a 400", client.post("/api/query", json=dict(body, question="   ")).status_code == 400)
check("cross_encoder falls back when unavailable",
      client.post("/api/query", json=dict(body, rerank_mode="cross_encoder")).status_code == 200)
check("unknown provider is a 400",
      client.post("/api/connect", json={"provider": "acme", "credential": "x"}).status_code == 400)

print("\n[7] session teardown")
check("disconnect closes the session",
      client.post("/api/disconnect", json={"session_id": sid}).json()["closed"] is True)
check("closed session no longer answers",
      client.post("/api/query", json=body).status_code == 401)

print(f"\n{'=' * 58}")
if failures:
    print(f"  {len(failures)} FAILED: " + "; ".join(failures))
    sys.exit(1)
print("  ALL CHECKS PASSED")
print(f"  mock provider calls: {MOCK.calls}")
print("=" * 58)
